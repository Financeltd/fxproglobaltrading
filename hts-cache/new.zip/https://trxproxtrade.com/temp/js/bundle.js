<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Not Found - TRX TRADE</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:700,900" rel="stylesheet">

	<!-- Font Awesome Icon -->
	<link type="text/css" rel="stylesheet" href="https://trxproxtrade.com/error/css/font-awesome.min.css" />

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="https://trxproxtrade.com/error/css/style.css" />
</head>

<body>
	<div id="notfound">
		<div class="notfound-bg"></div>
		<div class="notfound">
			<div class="notfound-404">
				<h1> 404 </h1>
			</div>
			<h2>We could not find the page you were looking for.</h2>
			<a href="http://trxproxtrade.com/verify" class="home-btn">Go Back</a>
		</div>
	</div>
</body>
</html>


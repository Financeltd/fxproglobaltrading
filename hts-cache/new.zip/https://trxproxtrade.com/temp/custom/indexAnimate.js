(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
var rect; // used to reference frame bounds
lib.ssMetadata = [];


// symbols:



(lib._1 = function() {
	this.initialize(img._1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1900,858);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Scene_1_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib._1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(82,206,182,0.898)","rgba(99,222,170,0)"],[0.063,0.722],0,0,0,0,0,89.5).s().p("Aq4IgQheh4CKj1QCKjyEhjiQEfjhEOhLQEPhKBeB4QBeB4iKD1QiKDzkgDhQkgDikPBKQhnAchOAAQh9AAg6hKg");
	this.shape.setTransform(45.2209,333.6287);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(82,206,182,0.894)","rgba(99,222,170,0)"],[0.059,0.714],0,0,0,0,0,89.3).s().p("Aq+IVQhch6CMjyQCOjwEkjdQEijcEPhHQEPhGBcB6QBcB5iODyQiNDxkjDcQkiDdkQBFQhkAahLAAQiCAAg5hMg");
	this.shape_1.setTransform(50.9922,328.8183);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(82,206,182,0.886)","rgba(99,222,170,0)"],[0.055,0.706],0,0,0,0,0,89.1).s().p("ArFIJQhah7CQjvQCSjuEmjYQEljXEPhCQEQhCBaB7QBaB6iRDvQiRDvkmDXQklDYkQBBQhfAXhJAAQiHAAg6hPg");
	this.shape_2.setTransform(56.7463,324.0281);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(82,206,182,0.882)","rgba(99,222,170,0)"],[0.055,0.698],0,0,0,0,0,89).s().p("ArMH9QhYh8CTjtQCVjqEpjTQEojTEQg+QEQg+BYB8QBYB8iUDtQiUDrkpDTQkoDTkRA9QhbAVhGAAQiMAAg6hTg");
	this.shape_3.setTransform(62.5215,319.2166);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(82,206,182,0.875)","rgba(99,222,170,0)"],[0.051,0.69],0,0,0,0,0,88.9).s().p("ArTHxQhWh9CXjqQCYjoEsjOQErjOERg6QEQg5BWB9QBWB9iXDqQiYDpksDOQkrDOkRA5QhWAShDAAQiSAAg7hWg");
	this.shape_4.setTransform(68.275,314.425);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(82,206,182,0.871)","rgba(99,222,170,0)"],[0.047,0.682],0,0,0,0,0,88.8).s().p("AraHmQhUh/CajoQCcjlEvjJQEujJERg2QERg1BUB/QBUB+ibDnQibDnkvDIQkuDKkRA0QhRAQhBAAQiYAAg7hYg");
	this.shape_5.setTransform(74.0574,309.6044);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(82,206,182,0.863)","rgba(99,222,170,0)"],[0.043,0.675],0,0,0,0,0,88.8).s().p("ArhHaQhSh/CejlQCfjjEyjFQExjEERgxQESgxBSCAQBSB/ifDlQieDkkxDEQkxDEkTAwQhMAOg9AAQifAAg7hcg");
	this.shape_6.setTransform(79.8221,304.7889);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(82,206,182,0.859)","rgba(99,222,170,0)"],[0.043,0.667],0,0,0,0,0,88.7).s().p("AroHOQhQiBCijiQCijgE1jAQEzi/ETgtQESgtBQCBQBQCAiiDjQiiDhk0C/Qk0DAkTAsQhHALg5AAQinAAg7hfg");
	this.shape_7.setTransform(85.5835,300.0017);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(82,206,182,0.851)","rgba(99,222,170,0)"],[0.039,0.659],0,0,0,0,0,88.7).s().p("ArvHDQhNiCCljgQCljeE4i7QE2i6ETgpQETgoBOCCQBOCCimDfQilDfk3C6Qk2C7kUAoQhBAJg3AAQiuAAg7hig");
	this.shape_8.setTransform(91.3475,295.1868);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(82,206,182,0.847)","rgba(99,222,170,0)"],[0.035,0.651],0,0,0,0,0,88.7).s().p("Ar2G3QhMiDCpjdQCpjbE7i2QE5i2ETgkQEUglBMCEQBLCCioDeQipDck6C1Qk6C2kUAkQg7AHgyAAQi2AAg8hmg");
	this.shape_9.setTransform(97.1119,290.3927);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(82,206,182,0.839)","rgba(99,222,170,0)"],[0.031,0.643],0,0,0,0,0,88.7).s().p("Ar9GrQhJiECsjbQCsjYE+ixQE8ixETggQEVggBKCFQBJCDisDbQisDak9CwQk8CxkVAfQg2AGguAAQi+AAg8hqg");
	this.shape_10.setTransform(102.875,285.5769);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(82,206,182,0.835)","rgba(99,222,170,0)"],[0.031,0.635],0,0,0,0,0,88.8).s().p("AsDGgQhIiGCvjYQCwjWFBisQE+isEVgcQEVgcBICGQBHCFivDYQiwDXlACsQk/CskVAbQgvAFgqAAQjIAAg7hug");
	this.shape_11.setTransform(108.6376,280.7936);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(82,206,182,0.827)","rgba(99,222,170,0)"],[0.027,0.627],0,0,0,0,0,88.8).s().p("AsKGUQhGiHCzjVQCzjUFEinQFBinEVgYQEWgXBFCHQBGCGizDVQizDVlDCnQlCCnkVAXQgqADgkAAQjSAAg7hyg");
	this.shape_12.setTransform(114.4,275.9756);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(82,206,182,0.824)","rgba(99,222,170,0)"],[0.024,0.62],0,0,0,0,0,88.9).s().p("AsRGIQhEiIC2jTQC3jQFGijQFFiiEVgUQEXgTBECJQBDCHi3DTQi2DSlFChQlFCjkXASQgiADgfAAQjdAAg7h3g");
	this.shape_13.setTransform(120.1865,271.1511);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(82,206,182,0.816)","rgba(99,222,170,0)"],[0.02,0.612],0,0,0,0,0,89).s().p("AsYF8QhCiJC6jQQC6jOFJieQFIidEWgPQEXgPBCCJQBBCJi6DQQi6DPlICdQlICekXAOIgzACQjqAAg7h8g");
	this.shape_14.setTransform(125.9387,266.3709);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(82,206,182,0.812)","rgba(99,222,170,0)"],[0.02,0.604],0,0,0,0,0,89.1).s().p("AsfFxQhAiKC9jPQC+jLFMiYQFKiZEXgLQEXgLBACLQA/CKi9DNQi9DNlLCZQlLCZkXAJIgnABQj1AAg7iAg");
	this.shape_15.setTransform(131.714,261.5503);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["rgba(82,206,182,0.804)","rgba(99,222,170,0)"],[0.016,0.596],0,0,0,0,0,89.3).s().p("AsmFlQg+iLDBjMQDBjJFPiUQFNiTEXgHQEYgGA+CMQA9CKjADLQjBDLlOCTQlOCUkYAGIgWAAQkEAAg7iFg");
	this.shape_16.setTransform(137.4659,256.773);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["rgba(82,206,182,0.8)","rgba(99,222,170,0)"],[0.012,0.588],0,0,0,0,0,89.4).s().p("AstFZQg7iMDEjJQDEjGFSiQQFQiOEYgDQEYgCA8COQA7CLjEDJQjEDIlRCOQlQCQkZABIgIAAQkRAAg7iLg");
	this.shape_17.setTransform(143.2397,251.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["rgba(85,206,178,0.8)","rgba(98,221,171,0.024)","rgba(99,222,170,0)"],[0.012,0.561,0.588],0,0,0,0,0,88.9).s().p("AniHVQkWgFg4iMQg3iNDHjCQDIjBFTiHQFRiGEWAFQEXAEA4COQA4CMjIDCQjIDClSCGQlDCBkOAAIgYAAg");
	this.shape_18.setTransform(149.6,251.9555);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["rgba(87,205,175,0.8)","rgba(97,220,171,0.047)","rgba(99,222,170,0)"],[0.012,0.533,0.588],0,0,0,0,0,88.4).s().p("AnqHHQkVgMg0iNQg0iNDLi8QDLi8FUh9QFTh9EUALQEWALA0COQA0CNjLC8QjMC9lTB8Qk1BzkCAAIgxgBg");
	this.shape_19.setTransform(155.9669,251.9827);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["rgba(90,205,171,0.8)","rgba(97,220,172,0.071)","rgba(99,222,170,0)"],[0.012,0.506,0.588],0,0,0,0,0,88).s().p("AnyG4QkUgSgwiNQgwiODOi3QDPi1FWh0QFTh0ETARQETASAxCPQAwCOjOC1QjQC3lUB0QklBkj0AAQgoAAgmgDg");
	this.shape_20.setTransform(162.3414,251.9685);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["rgba(92,205,168,0.8)","rgba(96,219,172,0.094)","rgba(99,222,170,0)"],[0.008,0.475,0.588],0,0,0,0,0,87.6).s().p("An7GqQkRgZgtiOQgsiPDSiwQDSivFXhsQFVhqERAYQERAZAtCPQAsCOjSCvQjSCxlWBrQkTBXjnAAQg4AAg1gFg");
	this.shape_21.setTransform(168.6921,251.9816);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["rgba(95,204,164,0.8)","rgba(95,218,173,0.118)","rgba(99,222,170,0)"],[0.008,0.447,0.588],0,0,0,0,0,87.3).s().p("AoDGbQkQgfgpiPQgpiPDWiqQDWipFYhjQFWhiEPAfQEQAgApCPQApCPjWCqQjWCqlWBiQkBBKjaAAQhIAAhEgIg");
	this.shape_22.setTransform(175.0433,251.99);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["rgba(98,204,160,0.8)","rgba(94,217,173,0.141)","rgba(99,222,170,0)"],[0.008,0.42,0.588],0,0,0,0,0,87).s().p("AoMGNQkOgmgliQQgliPDZikQDZikFZhaQFYhYENAlQEPAmAlCQQAlCPjZCkQjaCllYBZQjvA/jNAAQhYAAhSgMg");
	this.shape_23.setTransform(181.4188,252.0065);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["rgba(100,204,157,0.8)","rgba(93,217,174,0.165)","rgba(99,222,170,0)"],[0.008,0.392,0.588],0,0,0,0,0,86.8).s().p("AoUF+QkNgsghiQQghiQDcifQDdidFbhRQFYhQEMAsQEMAtAiCRQAhCQjcCdQjeCflZBQQjcA0i9AAQhrAAhhgRg");
	this.shape_24.setTransform(187.775,252.0024);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["rgba(103,203,153,0.8)","rgba(93,216,175,0.188)","rgba(99,222,170,0)"],[0.008,0.365,0.588],0,0,0,0,0,86.6).s().p("AodFwQkKgzgeiRQgeiQDhiZQDgiXFchIQFahHEKAzQEKAzAeCSQAeCQjgCYQjhCYlaBIQjIApitAAQiAAAhxgWg");
	this.shape_25.setTransform(194.1448,252.012);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["rgba(106,203,149,0.8)","rgba(92,215,175,0.212)","rgba(99,222,170,0)"],[0.008,0.337,0.588],0,0,0,0,0,86.4).s().p("AolFiQkJg6gaiRQgaiRDkiTQDjiRFdg/QFbg+EJA5QEJA6AaCSQAaCRjkCSQjkCTlcA+QizAgieAAQiTAAiAgcg");
	this.shape_26.setTransform(200.5204,252.0183);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["rgba(108,203,146,0.8)","rgba(91,214,176,0.235)","rgba(99,222,170,0)"],[0.008,0.31,0.588],0,0,0,0,0,86.4).s().p("AouFTQkHhAgWiSQgWiQDniOQDniMFeg1QFdg2EGBBQEIBAAWCTQAWCQjnCNQjoCNldA1QicAZiMAAQirAAiRglg");
	this.shape_27.setTransform(206.8752,252.0272);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.rf(["rgba(111,202,142,0.8)","rgba(90,214,176,0.263)","rgba(99,222,170,0)"],[0.004,0.278,0.588],0,0,0,0,0,86.4).s().p("Ao2FFQkGhIgSiSQgTiRDriHQDriGFggtQFdgsEFBHQEFBIATCSQASCRjqCHQjsCHldAsQiGASh6AAQjDAAihgtg");
	this.shape_28.setTransform(213.2217,252.0281);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["rgba(113,202,139,0.8)","rgba(89,213,177,0.286)","rgba(99,222,170,0)"],[0.004,0.251,0.588],0,0,0,0,0,86.4).s().p("Ao/E2QkDhOgPiSQgPiSDviBQDuiAFhgkQFfgjEDBNQEDBPAPCTQAPCRjuCBQjvCBlfAkQhuALhlAAQjfAAiyg3g");
	this.shape_29.setTransform(219.5751,252.0392);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.rf(["rgba(116,202,135,0.8)","rgba(88,212,177,0.31)","rgba(99,222,170,0)"],[0.004,0.224,0.588],0,0,0,0,0,86.6).s().p("ApHEoQkChVgMiTQgKiSDyh7QDxh6FigbQFggaECBUQECBVAMCTQAKCSjyB7QjyB8lhAaQhUAGhQAAQj7AAjDhBg");
	this.shape_30.setTransform(225.95,252.0259);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["rgba(119,201,131,0.8)","rgba(88,211,178,0.333)","rgba(99,222,170,0)"],[0.004,0.196,0.588],0,0,0,0,0,86.7).s().p("ApQEaQkAhcgHiTQgIiTD2h1QD1h0FjgSQFigSD/BbQEBBcAHCUQAHCSj1B2Qj2B1lhARQg6ADg4AAQkbAAjWhNg");
	this.shape_31.setTransform(232.3236,252.0374);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.rf(["rgba(121,201,128,0.8)","rgba(87,211,179,0.357)","rgba(99,222,170,0)"],[0.004,0.169,0.588],0,-0.1,0,0,-0.1,87).s().p("ApYELQj/higDiUQgEiTD5hwQD5huFlgJQFigJD+BiQD+BiAECVQAECTj5BvQj6BvliAJIg8ABQk+AAjohbg");
	this.shape_32.setTransform(238.675,252.0532);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["rgba(124,201,124,0.8)","rgba(86,210,179,0.38)","rgba(99,222,170,0)"],[0.004,0.141,0.588],0,0,0,0,0,87.2).s().p("AAAFnQllAAj7hqQj+hpAAiUQABiUD9hqQD7hoFlAAQFlABD8BoQD9BpAACUQAACVj8BpQj8BpliAAIgEAAg");
	this.shape_33.setTransform(245.05,252.0251);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.rf(["rgba(127,200,120,0.8)","rgba(85,209,180,0.404)","rgba(99,222,170,0)"],[0.004,0.114,0.588],0,0,0,0,0,87.6).s().p("AgHFoQlngIj7hxQj7hwAEiUQADiVEBhkQD/hiFnAJQFlAJD7BvQD7BwgECUQgDCVkABkQjsBbk/AAIg6gBg");
	this.shape_34.setTransform(251.4,252.0497);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["rgba(129,200,117,0.8)","rgba(84,208,180,0.427)","rgba(99,222,170,0)"],[0,0.082,0.588],0,0,0,0,0,87.9).s().p("AgQFpQlpgRj5h4Qj5h2AHiVQAIiVEEheQEDhcFnASQFoASD4B2QD6B2gICVQgICWkDBdQjZBOkdAAQg5AAg6gDg");
	this.shape_35.setTransform(257.7514,252.0312);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.rf(["rgba(132,200,113,0.8)","rgba(84,208,181,0.451)","rgba(99,222,170,0)"],[0,0.055,0.588],0,0,0,0,0,88.4).s().p("AgZFrQlqgaj3h/Qj4h9AMiVQALiWEHhYQEHhWFpAbQFoAbD3B8QD3B9gLCWQgLCWkHBXQjJBDkCAAQhPAAhUgGg");
	this.shape_36.setTransform(264.1229,252.0458);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["rgba(134,199,110,0.8)","rgba(83,207,181,0.475)","rgba(99,222,170,0)"],[0,0.027,0.588],0,0,0,0,0,88.9).s().p("AgiFsQlrgjj1iFQj2iEAPiWQAPiWELhSQEKhRFqAkQFpAlD2CCQD1CEgOCXQgQCWkKBSQi5A4jlAAQhmAAhvgLg");
	this.shape_37.setTransform(270.4973,252.0333);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.rf(["rgba(137,199,106,0.8)","rgba(82,206,182,0.498)","rgba(99,222,170,0)"],[0,0,0.588],0,0,0,0,0,89.4).s().p("AgrFtQlsgsj0iMQj0iKASiWQAUiXEOhMQEOhLFrAtQFrAtDzCKQD0CKgTCXQgSCXkOBMQiqAvjNAAQh7AAiGgRg");
	this.shape_38.setTransform(276.85,252.043);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.rf(["rgba(134,199,110,0.8)","rgba(83,207,181,0.471)","rgba(99,222,170,0)"],[0,0.031,0.588],0,0,0,0,0,88.1).s().p("AgdFpQlogej1iAQj1h/AMiVQAOiVEHhVQEGhUFnAfQFoAfD0B+QD1B/gMCWQgNCVkHBUQjBA+j1AAQhZAAhegIg");
	this.shape_39.setTransform(282.6001,246.8215);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.rf(["rgba(131,200,114,0.8)","rgba(84,208,181,0.447)","rgba(99,222,170,0)"],[0,0.063,0.588],0,-0.1,0,0,-0.1,86.9).s().p("AgOFlQllgQj2h1Qj3h0AHiTQAHiUEAheQEAhcFjARQFjAQD2BzQD3B1gGCTQgICUj/BdQjaBQkfAAQg0AAg1gDg");
	this.shape_40.setTransform(288.3987,241.6053);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.rf(["rgba(128,200,118,0.8)","rgba(85,209,180,0.42)","rgba(99,222,170,0)"],[0,0.094,0.588],0,0,0,0,0,85.9).s().p("AAAFhQlhgBj3hqQj4hpAAiRQABiSD6hnQD4hlFgACQFfACD4BoQD4BpgBCSQgBCSj5BmQj0BklTAAIgQAAg");
	this.shape_41.setTransform(294.15,236.376);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.rf(["rgba(125,200,122,0.8)","rgba(86,209,179,0.392)","rgba(99,222,170,0)"],[0,0.125,0.588],0,0,0,0,0,85).s().p("ApIELQj5hdgGiRQgEiQDyhvQDyhuFcgMQFbgMD5BdQD5BdAFCSQAFCPjyBvQjzBvlaAMIhOACQkqAAjdhUg");
	this.shape_42.setTransform(299.901,231.1791);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.rf(["rgba(123,201,126,0.8)","rgba(86,210,179,0.369)","rgba(99,222,170,0)"],[0,0.153,0.588],0,0,0,0,0,84.2).s().p("Ao3EhQj7hSgLiQQgKiNDrh5QDrh3FYgaQFWgaD6BRQD8BSALCRQAKCOjqB3QjsB4lXAaQhUAHhPAAQjyAAi9g/g");
	this.shape_43.setTransform(305.7001,225.9497);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.rf(["rgba(120,201,130,0.8)","rgba(87,211,178,0.341)","rgba(99,222,170,0)"],[0,0.184,0.588],0,0,0,0,0,83.6).s().p("AomE2Qj9hHgRiNQgQiNDkiBQDkiAFVgoQFSgpD8BHQD8BHARCOQARCMjkCBQjlCBlSAoQh7APhvAAQjFAAihgug");
	this.shape_44.setTransform(311.4502,220.7382);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.rf(["rgba(117,202,134,0.8)","rgba(88,212,178,0.314)","rgba(99,222,170,0)"],[0,0.216,0.588],0,-0.1,0,0,-0.1,83.1).s().p("AoVFLQj+g7gXiMQgWiLDdiKQDdiJFRg3QFOg2D9A7QD+A8AXCNQAWCKjcCKQjeCKlPA2QigAbiNAAQicAAiEghg");
	this.shape_45.setTransform(317.2461,215.5067);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.rf(["rgba(114,202,138,0.8)","rgba(89,213,177,0.29)","rgba(99,222,170,0)"],[0,0.247,0.588],0,0,0,0,0,82.8).s().p("AoFFhQj/gwgdiLQgciKDXiSQDWiRFMhFQFLhFD+AwQD/AxAdCLQAdCKjWCRQjXCTlLBEQjBApinAAQh4AAhrgVg");
	this.shape_46.setTransform(323.0007,210.2821);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.rf(["rgba(111,202,142,0.8)","rgba(90,214,176,0.263)","rgba(99,222,170,0)"],[0,0.278,0.588],0,0,0,0,0,82.7).s().p("An0F3QkAglgjiJQgiiIDPicQDQiaFIhTQFHhTD/AlQEBAlAjCKQAiCIjPCaQjQCclGBTQjgA5i/AAQhYAAhSgMg");
	this.shape_47.setTransform(328.7571,205.0479);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.rf(["rgba(108,203,146,0.8)","rgba(91,214,176,0.235)","rgba(99,222,170,0)"],[0,0.31,0.588],0,0,0,0,0,82.7).s().p("AnjGMQkCgagoiHQgpiHDJikQDIijFFhhQFDhhEBAZQECAbApCHQAoCHjICjQjJCllDBgQj9BNjVAAQg8AAg4gGg");
	this.shape_48.setTransform(334.5437,199.8347);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.rf(["rgba(105,203,150,0.8)","rgba(92,215,175,0.208)","rgba(99,222,170,0)"],[0,0.341,0.588],-0.1,0,0,-0.1,0,82.8).s().p("AnTGiQkDgPguiFQguiFDBitQDCitFAhvQE/hvEDAOQEDAPAvCGQAuCFjBCsQjCCuk/BvQkXBijpAAQgiAAgigCg");
	this.shape_49.setTransform(340.3009,194.5968);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.rf(["rgba(102,203,154,0.8)","rgba(93,216,174,0.184)","rgba(99,222,170,0)"],[0,0.373,0.588],0,0,0,0,0,83.1).s().p("AnCG3QkEgEg1iDQg0iEC7i2QC7i1E8h9QE7h+EEADQEFAEA0CEQA1CEi7C1Qi7C2k7B+QkvB6j+AAIgUgBg");
	this.shape_50.setTransform(346.0609,189.356);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.rf(["rgba(99,204,158,0.8)","rgba(94,217,174,0.157)","rgba(99,222,170,0)"],[0,0.404,0.588],-0.1,0,0,-0.1,0,83.6).s().p("ArxFSQg6iBC0jAQCzi9E5iMQE3iMEFgIQEGgHA7CCQA6CDi0C+Qi0C+k3CMQk3CNkHAGIgaAAQjvAAg3h7g");
	this.shape_51.setTransform(351.8515,184.1475);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.rf(["rgba(96,204,162,0.8)","rgba(95,218,173,0.129)","rgba(99,222,170,0)"],[0,0.435,0.588],-0.1,0,0,-0.1,0,84.2).s().p("AroF1QhAiBCtjIQCtjGE1iaQEziaEGgTQEIgTBACBQBACAisDIQitDHkzCaQk0CbkIARQghADgeAAQjQAAg5hwg");
	this.shape_52.setTransform(357.6018,178.9254);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.rf(["rgba(94,205,166,0.8)","rgba(95,219,173,0.106)","rgba(99,222,170,0)"],[0,0.463,0.588],0,0,0,0,0,85).s().p("AreGXQhGh/CmjSQCmjOExipQEvioEHgeQEJgeBHB/QBGB/ilDRQimDQkwCnQkwCqkJAdQgyAGgrAAQi5AAg5hng");
	this.shape_53.setTransform(363.3918,173.7009);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.rf(["rgba(91,205,170,0.8)","rgba(96,219,172,0.078)","rgba(99,222,170,0)"],[0,0.494,0.588],0,0,0,0,0,85.9).s().p("ArUG5QhMh9CfjaQCfjYEsi2QEsi3EJgpQEKgpBNB9QBLB+ieDZQifDZkrC2QksC4kLAnQhCAKg2AAQilAAg5heg");
	this.shape_54.setTransform(369.1417,168.4765);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.rf(["rgba(88,205,174,0.8)","rgba(97,220,171,0.051)","rgba(99,222,170,0)"],[0,0.525,0.588],-0.1,0,0,-0.1,0,86.9).s().p("ArLHbQhSh7CYjjQCYjhEpjFQEnjEELg1QELg0BTB8QBSB8iYDiQiYDhknDFQkoDGkNAzQhPAPg/AAQiVAAg6hXg");
	this.shape_55.setTransform(374.9175,163.2646);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.rf(["rgba(85,206,178,0.8)","rgba(98,221,171,0.027)","rgba(99,222,170,0)"],[0,0.557,0.588],0,0,0,0,0,88.1).s().p("ArBH+QhYh6CRjsQCRjpEljTQEjjTEMhAQENg/BZB6QBXB6iQDrQiRDrkkDSQkkDUkOA+QhcAWhHAAQiIAAg5hQg");
	this.shape_56.setTransform(380.6883,158.0421);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.rf(["rgba(82,206,182,0.8)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,89.4).s().p("Aq4IgQheh4CKj1QCKjyEhjiQEgjhENhLQEOhKBfB4QBdB5iJD0QiKDzkgDhQkgDikPBKQhnAchOAAQh9AAg6hKg");
	this.shape_57.setTransform(386.4541,152.8287);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.rf(["rgba(82,206,182,0.804)","rgba(99,222,170,0)"],[0,0.588],0,0,0,0,0,87.1).s().p("Aq/HvQhVh5CSjoQCSjkEkjOQEijNEJg8QELg7BWB6QBVB5iRDnQiSDmkjDMQkiDPkMA6QhYAUhEAAQiLAAg5hSg");
	this.shape_58.setTransform(393.3435,152.1637);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.rf(["rgba(82,206,182,0.812)","rgba(99,222,170,0)"],[0,0.588],0,0,0,0,0,84.9).s().p("ArGG/QhMh7CajaQCZjYEni5QEli4EFgtQEHgtBOB7QBMB7iZDZQiaDZklC4QkmC6kHAsQhGAMg5AAQicAAg5hag");
	this.shape_59.setTransform(400.2305,151.5018);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.rf(["rgba(82,206,182,0.816)","rgba(99,222,170,0)"],[0,0.588],0,0,0,0,0,83).s().p("ArMGOQhFh7CijNQCijKEpilQEoilEBgeQEDgdBFB8QBFB8iiDMQihDLkoCkQkpCmkDAdQgxAFgrAAQi0AAg3hkg");
	this.shape_60.setTransform(407.1272,150.8259);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.rf(["rgba(82,206,182,0.824)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,81.3).s().p("ArTFeQg8h9CpjAQCqi8EsiRQEriQD9gPQD/gPA9B+QA8B9ipC+QiqC+krCQQkrCSkAANIgxACQjTAAg2hwg");
	this.shape_61.setTransform(414.0154,150.1707);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.rf(["rgba(82,206,182,0.827)","rgba(99,222,170,0)"],[0,0.588],0,0,0,0,0,79.9).s().p("AmrGsQj7gBg0h+Qg0h+CyixQCyiwEvh8QEth9D6AAQD7ABA0B/QA0B+ixCwQiyCxkuB8QkoB8j4AAIgJAAg");
	this.shape_62.setTransform(420.8925,149.4774);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.rf(["rgba(82,206,182,0.831)","rgba(99,222,170,0)"],[0,0.588],0,0,0,0,0,78.8).s().p("Am/GLQj2gPgsiAQgrh/C6ijQC5ijEyhoQEwhpD2APQD3AQAsCAQArCAi5CiQi5CkkxBoQkGBbjbAAQglAAgjgDg");
	this.shape_63.setTransform(427.7932,148.8304);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.rf(["rgba(82,206,182,0.839)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,78.1).s().p("AnSFqQjygfgkiAQgjiADCiWQDBiWE1hUQEzhUDyAeQDzAfAkCBQAiCBjBCVQjBCWkzBUQjfA+i+AAQhIAAhDgJg");
	this.shape_64.setTransform(434.6691,148.2028);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.rf(["rgba(82,206,182,0.843)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,77.6).s().p("AnlFKQjvgugbiBQgaiCDKiIQDIiIE4hAQE2hADuAtQDvAuAcCCQAaCCjJCIQjJCJk3BAQizAlicAAQhyAAhlgUg");
	this.shape_65.setTransform(441.5702,147.5489);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.rf(["rgba(82,206,182,0.851)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,77.4).s().p("An4EpQjrg9gSiCQgTiCDSh8QDRh7E6gsQE5grDqA8QDrA9ATCDQASCCjRB7QjRB8k5AsQiDATh1AAQikAAiJglg");
	this.shape_66.setTransform(448.4715,146.9027);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.rf(["rgba(82,206,182,0.855)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,77.6).s().p("AoLEJQjnhMgKiEQgKiCDahwQDZhtE9gXQE7gYDnBLQDnBNAKCEQAKCDjZBuQjZBuk8AYQhMAGhJAAQjgAAivg7g");
	this.shape_67.setTransform(455.348,146.2246);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.rf(["rgba(82,206,182,0.859)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,78.1).s().p("AoeDpQjkhbgBiGQgCiDDihiQDhhgFAgDQE+gEDjBaQDjBcACCGQABCEjgBgQjiBhk+AEIgdAAQkuAAjYhYg");
	this.shape_68.setTransform(462.2497,145.5539);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.rf(["rgba(82,206,182,0.867)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,78.9).s().p("AgPFEQlDgQjfhrQjfhrAGiFQAHiGDqhUQDohSFCAQQFCARDfBpQDfBrgGCGQgICGjoBTQjDBFkAAAQgzAAg0gCg");
	this.shape_69.setTransform(469.125,144.8729);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.rf(["rgba(82,206,182,0.871)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,80).s().p("AgjFHQlGgkjch7Qjbh5APiHQAQiHDxhHQDwhFFFAlQFFAlDbB4QDbB6gOCHQgQCIjxBFQieAujCAAQhmAAhugMg");
	this.shape_70.setTransform(476.0219,144.2047);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.rf(["rgba(82,206,182,0.875)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,81.3).s().p("Ag3FKQlJg4jXiKQjYiIAYiIQAXiID6g6QD4g3FIA5QFIA5DXCHQDXCIgXCJQgYCJj5A4Qh8AciQAAQiQAAijgcg");
	this.shape_71.setTransform(482.8956,143.5371);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.rf(["rgba(82,206,182,0.882)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,83).s().p("AhLFNQlMhMjUiaQjTiWAgiKQAgiJEBgsQEAgqFLBNQFKBNDUCWQDTCXgfCLQghCJkAArQhdAQhmAAQi1AAjSgxg");
	this.shape_72.setTransform(489.794,142.8606);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.rf(["rgba(82,206,182,0.886)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,84.9).s().p("AhgFQQlOhgjQipQjPilAoiLQAoiLEKgeQEIgdFNBiQFNBhDQClQDPCmgoCMQgpCKkIAeQg/AHhCAAQjXAAj9hKg");
	this.shape_73.setTransform(496.6925,142.182);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.rf(["rgba(82,206,182,0.894)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,87.1).s().p("Ah0FTQlSh1jLi3QjLi1AwiMQAxiMERgRQEQgPFQB2QFQB1DMC0QDLC1gwCNQgyCMkQAQQghACgiAAQj2AAkmhmg");
	this.shape_74.setTransform(503.5904,141.5066);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.rf(["rgba(82,206,182,0.898)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,89.4).s().p("AiIFWQlViJjHjGQjIjEA5iNQA5iNEagEQEXgCFTCKQFTCKDIDDQDHDEg4COQg6CNkYADIgMAAQkUAAlKiGg");
	this.shape_75.setTransform(510.4652,140.8268);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.rf(["rgba(82,206,182,0.894)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,87).s().p("Ah1FSQlRh2jLi4QjKi1AxiMQAyiLERgQQEPgOFQB3QFPB3DKC0QDLC2gxCNQgyCLkQAPQgfACgfAAQj4AAkohpg");
	this.shape_76.setTransform(518.6741,141.5856);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.rf(["rgba(82,206,182,0.89)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,84.7).s().p("AhiFOQlNhjjOiqQjNimApiLQAqiKEJgcQEHgaFMBkQFLBlDOCmQDNCngpCMQgqCKkIAaQg6AGg8AAQjaAAkChOg");
	this.shape_77.setTransform(526.8854,142.3295);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.rf(["rgba(82,206,182,0.882)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,82.6).s().p("AhPFKQlKhQjQibQjQiZAhiJQAiiIEBgoQD/gmFIBRQFIBRDQCZQDQCYghCKQgiCJkAAnQhUANhcAAQi7AAjbg3g");
	this.shape_78.setTransform(535.0936,143.0932);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.rf(["rgba(82,206,182,0.878)","rgba(99,222,170,0)"],[0,0.588],0,-0.1,0,0,-0.1,80.8).s().p("Ag8FGQlGg9jTiOQjTiKAZiHQAaiHD5g0QD3gyFEA+QFFA/DTCKQDSCKgZCIQgaCHj4A0QhwAXiAAAQiaAAiwgig");
	this.shape_79.setTransform(543.2952,143.8522);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.rf(["rgba(82,206,182,0.875)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,79.1).s().p("AgqFCQlCgqjWh/QjWh9ASiFQASiFDxhAQDvg/FAAsQFBAsDWB7QDVB+gRCFQgTCGjvA/QiPAmiqAAQh1AAiBgSg");
	this.shape_80.setTransform(551.5427,144.6167);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.rf(["rgba(82,206,182,0.871)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,77.7).s().p("AgXE/Qk+gYjahwQjYhvAKiDQAKiEDphMQDnhLE9AZQE8AZDZBtQDZBvgKCEQgLCEjnBMQivA5jeAAQhJAAhNgGg");
	this.shape_81.setTransform(559.7456,145.3469);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.rf(["rgba(82,206,182,0.867)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,76.6).s().p("AgEE7Qk6gFjdhiQjbhgACiCQACiCDhhZQDfhXE5AGQE5AHDbBfQDcBhgCCCQgDCCjfBYQjRBSkdAAIgpAAg");
	this.shape_82.setTransform(567.9491,146.078);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.rf(["rgba(82,206,182,0.859)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,75.7).s().p("AoHDxQjehSgGiBQgFh/DYhlQDXhjE2gNQE1gMDeBRQDeBSAGCBQAFCAjXBlQjXBkk1AMQgsACgrAAQj/AAi/hIg");
	this.shape_83.setTransform(576.1488,146.842);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.rf(["rgba(82,206,182,0.855)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,75.1).s().p("An0EOQjhhDgNh/QgOh/DQhxQDPhvEzggQExgeDhBCQDhBEAOCAQANB+jQBxQjPBwkxAfQhgAKhaAAQi/AAibgvg");
	this.shape_84.setTransform(584.3694,147.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.rf(["rgba(82,206,182,0.851)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,74.9).s().p("AngEsQjkg1gVh+QgVh9DHh9QDHh7EvgzQEtgxDkA0QDkA1AWB/QAVB9jIB8QjGB9kuAxQiRAZiCAAQiKAAh2gcg");
	this.shape_85.setTransform(592.5705,148.3382);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.rf(["rgba(82,206,182,0.847)","rgba(99,222,170,0)"],[0,0.588],-0.1,-0.1,0,-0.1,-0.1,74.9).s().p("AnNFJQjmgngdh8Qgdh8C/iJQC/iHErhFQEqhEDnAlQDnAnAdB9QAdB9jACIQi+CIkqBEQi9AtijAAQheAAhVgPg");
	this.shape_86.setTransform(597.7189,146.0224);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.rf(["rgba(82,206,182,0.843)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,75.1).s().p("Am5FnQjqgZgkh6Qglh7C3iVQC3iTEohYQElhXDqAXQDqAZAlB8QAlB7i4CTQi2CVkmBXQjjBFjAAAQg5AAg2gGg");
	this.shape_87.setTransform(602.8743,143.6791);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.rf(["rgba(82,206,182,0.835)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,75.7).s().p("AmlGEQjtgKgsh5Qgth5CvihQCvigEkhqQEihqDsAJQDtAKAuB6QArB6ivCgQiuCgkiBqQkHBhjcAAIgugBg");
	this.shape_88.setTransform(608.0319,141.3665);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.rf(["rgba(82,206,182,0.831)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,76.6).s().p("Aq1EuQg0h3CmiuQCnirEgh9QEeh9DwgFQDvgEA2B4QAzB4inCtQimCskeB9QkfB+jyADIgRAAQjgAAgyh0g");
	this.shape_89.setTransform(613.1882,139.0267);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.rf(["rgba(82,206,182,0.827)","rgba(99,222,170,0)"],[0,0.588],-0.1,0,0,-0.1,0,77.7).s().p("AqsFcQg8h2Cei7QCfi2EciRQEbiPDygTQDzgTA9B3QA7B2ifC6QidC4kbCPQkcCRj0ARQghADgdAAQi8AAg0hmg");
	this.shape_90.setTransform(618.3363,136.7255);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.rf(["rgba(82,206,182,0.824)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,79.1).s().p("AqkGJQhDh1CWjGQCWjDEZijQEYiiD0giQD1ggBFB1QBEB1iXDFQiVDEkYCiQkXCkj3AfQg3AIgtAAQihAAg1hbg");
	this.shape_91.setTransform(623.5,134.411);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.rf(["rgba(82,206,182,0.82)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,80.7).s().p("AqbG2QhLhzCPjTQCNjPEVi2QEUi0D4gwQD4gvBNBzQBLB0iPDRQiNDRkUC0QkTC3j7AuQhIAOg5AAQiNAAg2hSg");
	this.shape_92.setTransform(628.65,132.1042);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.rf(["rgba(82,206,182,0.816)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,82.6).s().p("AqSHkQhThyCGjfQCGjbESjJQEPjHD7g+QD7g9BUBxQBUByiHDeQiFDdkQDHQkQDKj9A7QhZAWhDAAQh9AAg2hJg");
	this.shape_93.setTransform(633.8118,129.7926);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.rf(["rgba(82,206,182,0.808)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,84.7).s().p("AqJIRQhbhwB+jsQB+jnEOjbQEMjaD9hNQD+hLBdBvQBaBxh+DqQh9DpkMDZQkNDdkABLQhmAehMAAQhwAAg3hCg");
	this.shape_94.setTransform(638.9585,127.5);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.rf(["rgba(82,206,182,0.804)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,86.9).s().p("AqAI+QhihuB1j4QB2jzEKjuQEIjtEAhbQEBhaBlBvQBiBvh2D1Qh1D1kJDtQkIDvkDBZQh0AohUAAQhlAAg3g8g");
	this.shape_95.setTransform(644.1198,125.1975);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.rf(["rgba(82,206,182,0.8)","rgba(99,222,170,0)"],[0,0.588],-0.2,0,0,-0.2,0,89.4).s().p("Ap3JrQhqhtBtkDQBukAEGkBQEFj/EDhpQEEhpBsBtQBqBuhuECQhtEBkFD/QkEECkGBnQh/AzhbAAQheAAg3g3g");
	this.shape_96.setTransform(649.2689,122.881);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.rf(["rgba(85,206,178,0.8)","rgba(98,221,171,0.024)","rgba(99,222,170,0)"],[0,0.561,0.588],-0.1,0,0,-0.1,0,89.2).s().p("AqBJYQhph0BykCQByj/ELj5QEJj3EFhfQEGheBqB0QBoB0hyEBQhyEAkJD4QkJD6kIBcQh2AqhWAAQhpAAg5g/g");
	this.shape_97.setTransform(654.6943,117.3427);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.rf(["rgba(87,205,175,0.8)","rgba(97,220,171,0.047)","rgba(99,222,170,0)"],[0,0.533,0.588],-0.2,0,0,-0.2,0,89.2).s().p("AqMJEQhnh6B3kCQB3j9EPjxQENjwEHhUQEHhUBpB7QBmB6h3EBQh2D/kODvQkODykJBTQhrAihRAAQh1AAg9hJg");
	this.shape_98.setTransform(660.1447,111.8041);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.rf(["rgba(90,205,171,0.8)","rgba(97,220,172,0.071)","rgba(99,222,170,0)"],[0,0.506,0.588],-0.2,0,0,-0.2,0,89.3).s().p("AqXIxQhliBB8kBQB7j8EUjpQERjoEJhKQEJhJBmCBQBlCCh8D/Qh7D+kSDoQkSDqkLBHQhgAbhLAAQiDAAhAhSg");
	this.shape_99.setTransform(665.575,106.2533);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.rf(["rgba(92,205,168,0.8)","rgba(96,219,172,0.094)","rgba(99,222,170,0)"],[0,0.475,0.588],-0.2,0,0,-0.2,0,89.6).s().p("AqiIeQhjiICAkAQCAj7EYjhQEXjgEKhAQELg/BkCIQBiCJiAD+Qh/D9kXDgQkWDikNA9QhVAUhEAAQiRAAhEhcg");
	this.shape_100.setTransform(671.008,100.705);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.rf(["rgba(95,204,164,0.8)","rgba(95,218,173,0.118)","rgba(99,222,170,0)"],[0,0.447,0.588],-0.2,0,0,-0.2,0,90.1).s().p("AqsILQhhiPCEj/QCEj6EdjZQEbjYEMg1QENg1BiCPQBgCPiED9QiED9kbDXQkbDakPAzQhIAOg8AAQijAAhGhng");
	this.shape_101.setTransform(676.4334,95.1768);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.rf(["rgba(98,204,160,0.8)","rgba(94,217,173,0.141)","rgba(99,222,170,0)"],[0,0.42,0.588],-0.2,0,0,-0.2,0,90.8).s().p("Aq3H4QhfiVCJj/QCJj5EhjRQEfjQEOgrQEOgqBhCVQBeCWiJD8QiID8kgDQQkgDSkQAoQg8AKgzAAQi0AAhKh0g");
	this.shape_102.setTransform(681.8838,89.636);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.rf(["rgba(100,204,157,0.8)","rgba(93,217,174,0.165)","rgba(99,222,170,0)"],[0,0.392,0.588],-0.2,-0.1,0,-0.2,-0.1,91.6).s().p("ArCHkQhdicCOj9QCNj5EmjJQEjjHEQghQEQggBeCcQBdCdiOD7QiND7kkDIQkkDKkSAeQgvAFgpAAQjIAAhNiBg");
	this.shape_103.setTransform(687.3131,84.1014);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.rf(["rgba(103,203,153,0.8)","rgba(93,216,175,0.188)","rgba(99,222,170,0)"],[0,0.365,0.588],-0.2,0,0,-0.2,0,92.6).s().p("ArNHRQhbiiCTj9QCRj3ErjBQEojAERgXQESgVBcCjQBbCjiSD6QiSD6kpDAQkoDCkUAUQggACgeAAQjeAAhRiPg");
	this.shape_104.setTransform(692.7382,78.536);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.rf(["rgba(106,203,149,0.8)","rgba(92,215,175,0.212)","rgba(99,222,170,0)"],[0,0.337,0.588],-0.2,-0.1,0,-0.2,-0.1,93.7).s().p("ArYG+QhZipCYj8QCWj3Eui5QEti3ETgNQEUgLBaCqQBZCqiXD5QiWD5kuC4QksC6kWAJIgiABQj3AAhUieg");
	this.shape_105.setTransform(698.1884,73.0031);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.rf(["rgba(108,203,146,0.8)","rgba(91,214,176,0.235)","rgba(99,222,170,0)"],[0,0.31,0.588],-0.2,-0.1,0,-0.2,-0.1,95.1).s().p("Al2JZQkVABhYivQhXiwCcj7QCbj2EzixQExivEVgDQEVAABZCwQBWCxibD4QibD4kyCxQkuCxkVAAIgFgBg");
	this.shape_106.setTransform(703.6135,67.4506);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.rf(["rgba(111,202,142,0.8)","rgba(90,214,176,0.263)","rgba(99,222,170,0)"],[0,0.278,0.588],-0.2,-0.1,0,-0.2,-0.1,96.5).s().p("AmBJXQkXgJhVi3QhVi2Cgj5QCfj2E4ipQE1ioEWAJQEYAKBWC3QBVC3igD2QifD5k2CoQkiCfkJAAIgkgBg");
	this.shape_107.setTransform(709.0637,61.9409);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.rf(["rgba(113,202,139,0.8)","rgba(89,213,177,0.286)","rgba(99,222,170,0)"],[0,0.251,0.588],-0.2,-0.1,0,-0.2,-0.1,98).s().p("AmMJVQkZgUhTi9QhTi+Clj3QCjj1E9iiQE6ifEYASQEZAVBUC+QBTC+ikD1QikD3k7ChQkUCPj9AAQgiAAgigDg");
	this.shape_108.setTransform(714.4889,56.4104);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.rf(["rgba(116,202,135,0.8)","rgba(88,212,177,0.31)","rgba(99,222,170,0)"],[0,0.224,0.588],-0.2,-0.2,0,-0.2,-0.2,99.8).s().p("AmXJSQkbgehRjEQhRjECqj2QCoj1FAiZQE/iXEaAcQEbAfBSDFQBRDEipD1QipD2k/CZQkHB/jwAAQgyAAgygGg");
	this.shape_109.setTransform(719.9391,50.9002);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.rf(["rgba(119,201,131,0.8)","rgba(88,211,178,0.333)","rgba(99,222,170,0)"],[0,0.196,0.588],-0.2,-0.1,0,-0.2,-0.1,101.6).s().p("AmiJQQkcgohQjLQhPjKCuj2QCtjzFFiSQFDiPEbAnQEdApBRDLQBODMitDzQitD2lECQQj5BxjkAAQhDAAhBgKg");
	this.shape_110.setTransform(725.3643,45.3474);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.rf(["rgba(121,201,128,0.8)","rgba(87,211,179,0.357)","rgba(99,222,170,0)"],[0,0.169,0.588],-0.2,-0.2,0,-0.2,-0.2,103.5).s().p("AmtJOQkegzhNjRQhNjSCyj1QCxjyFKiJQFHiIEeAyQEfAzBODSQBMDTixDyQiyD1lICIQjsBkjYAAQhTAAhRgPg");
	this.shape_111.setTransform(730.7917,39.8351);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.rf(["rgba(124,201,124,0.8)","rgba(86,210,179,0.38)","rgba(99,222,170,0)"],[0,0.141,0.588],-0.2,-0.2,0,-0.2,-0.2,105.6).s().p("Am4JLQkgg9hLjYQhLjYC3j0QC2jxFOiCQFLh/EgA7QEgA+BNDZQBKDZi2DyQi2DzlNCBQjeBYjMAAQhkAAhggWg");
	this.shape_112.setTransform(736.2418,34.3091);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.rf(["rgba(127,200,120,0.8)","rgba(85,209,180,0.404)","rgba(99,222,170,0)"],[0,0.114,0.588],-0.2,-0.2,0,-0.2,-0.2,107.8).s().p("AnDJJQkihHhJjfQhJjfC8jzQC6jwFSh6QFQh3EhBGQEjBIBKDgQBJDfi7DxQi7DzlRB4QjRBMjAAAQh1AAhugcg");
	this.shape_113.setTransform(741.6669,28.7791);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.rf(["rgba(129,200,117,0.8)","rgba(84,208,180,0.427)","rgba(99,222,170,0)"],[0,0.082,0.588],-0.2,-0.3,0,-0.2,-0.3,110.1).s().p("AnOJHQkkhShHjmQhHjlDAjzQC/jvFXhxQFVhwEiBQQEkBTBJDnQBGDmi/DvQi/DylWBxQjDBCi0AAQiGAAh9gkg");
	this.shape_114.setTransform(747.1053,23.2525);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.rf(["rgba(132,200,113,0.8)","rgba(84,208,181,0.451)","rgba(99,222,170,0)"],[0,0.055,0.588],-0.2,-0.3,0,-0.2,-0.3,112.4).s().p("AnZJEQklhchFjsQhGjsDFjyQDDjuFchpQFZhoElBbQEmBdBGDtQBEDtjDDuQjEDylaBpQi1A3ioAAQiYAAiMgtg");
	this.shape_115.setTransform(752.5325,17.7272);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.rf(["rgba(134,199,110,0.8)","rgba(83,207,181,0.475)","rgba(99,222,170,0)"],[0,0.027,0.588],-0.2,-0.3,0,-0.2,-0.3,114.9).s().p("AnkJCQknhmhDjzQhEjyDKjyQDIjtFghhQFdhgEmBlQEoBoBFDzQBCDzjIDvQjJDwleBhQioAvidAAQioAAiag3g");
	this.shape_116.setTransform(757.9828,12.1831);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.rf(["rgba(137,199,106,0.8)","rgba(82,206,182,0.498)","rgba(99,222,170,0)"],[0,0,0.588],-0.2,-0.3,0,-0.2,-0.3,117.4).s().p("AnvJAQkphxhBj6QhCj4DPjxQDMjsFkhaQFihXEoBvQEqByBCD6QBBD6jNDtQjNDwljBZQibAniPAAQi6AAiphBg");
	this.shape_117.setTransform(763.4082,6.6625);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},23).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).wait(65));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_4__копия_2_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgtBHIAAiNIAlAAQAYAAAPAQQAPAQAAAbIAAAWQAAAcgPAQQgPAQgZAAgAgRAvIAJAAQANAAAGgIQAGgHAAgTIAAgXQAAgUgFgIQgGgIgMAAIgLAAg");
	this.shape.setTransform(40.625,16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgmBHIAAiNIAcAAIAAB1IAyAAIAAAYg");
	this.shape_1.setTransform(30.4,16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgkA5QgOgQAAgcIAAgXQAAgdANgQQAOgRAXAAQAYAAANAQQAOAQAAAeIAAAWQAAAegNAPQgOAQgYAAQgXAAgNgQgAgQgnQgFAJgBASIAAAYQAAAUAGAIQAGAJAKAAQALAAAGgJQAFgIAAgTIAAgXQAAgTgFgKQgFgJgMAAQgKAAgGAJg");
	this.shape_2.setTransform(19.275,16.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAVBHIAAg9IgpAAIAAA9IgdAAIAAiNIAdAAIAAA5IApAAIAAg5IAdAAIAACNg");
	this.shape_3.setTransform(7.075,16.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(25,131,127,0)").ss(2,1,1).p("ADnAAInNAA");
	this.shape_4.setTransform(23.1,32.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#CBB832").s().p("ADnCgInNAAIg+AAIAAk/IJKAAIAAE/g");
	this.shape_5.setTransform(23.1,16.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ_4__копия_2_Слой_1, null, null);


(lib.Символ_4__копия_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgmBHIAAiNIAcAAIAAB1IAyAAIAAAYg");
	this.shape.setTransform(40.2,16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgmBHIAAiNIAcAAIAAB1IAxAAIAAAYg");
	this.shape_1.setTransform(30.65,16.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgoBHIAAiNIBRAAIAAAYIg0AAIAAAhIAsAAIAAAXIgsAAIAAAlIA0AAIAAAYg");
	this.shape_2.setTransform(20.975,16.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgVBDQgMgFgGgLQgHgLAAgOIAdAAQAAANAFAFQAFAGAKgBQAPAAAAgPQAAgJgFgFQgEgEgLgFQgVgIgKgKQgJgLAAgPQAAgRANgLQAMgLATAAQANAAAKAFQALAGAFAKQAGAKAAANIgdAAQAAgKgEgFQgEgFgIgBQgHAAgEAFQgEAFAAAHQAAAFAEAFQAFAFALAFQAVAIAJAJQAKALAAASQAAASgMALQgMAKgUAAQgNAAgLgGg");
	this.shape_3.setTransform(10.325,16.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(25,131,127,0)").ss(2,1,1).p("ADnAAInNAA");
	this.shape_4.setTransform(23.1,32.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#99BC52").s().p("ADnCgInNAAIg+AAIAAk/IJKAAIAAE/g");
	this.shape_5.setTransform(23.1,16.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ_4__копия_Слой_1, null, null);


(lib.Символ_4_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgOBHIAAg0IgmhZIAgAAIAUA/IAVg/IAgAAIgmBZIAAA0g");
	this.shape.setTransform(36.025,16.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgiA8QgMgMAAgWIAAhhIAdAAIAABhQAAAMAEAFQAEAFAJAAQAKAAAEgFQAEgFAAgMIAAhhIAdAAIAABiQgBAWgMALQgMAMgWAAQgWAAgMgMg");
	this.shape_1.setTransform(24.875,16.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgtBHIAAiNIAsAAQAVAAAMAKQAMAJAAAUQAAALgFAHQgFAIgIAEQAJACAFAIQAGAIAAAMQAAAVgMALQgLAKgWAAgAgQAvIARAAQAIAAAEgEQAEgGAAgIQAAgUgOAAIgTAAgAgQgKIAPAAQAQgBAAgRQAAgKgEgEQgEgFgIABIgPAAg");
	this.shape_2.setTransform(13.675,16.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(25,131,127,0)").ss(2,1,1).p("ADnCgInNAAAjmifIHNAA");
	this.shape_3.setTransform(23.1,16.025);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#52BCAB").s().p("AjmCgIAAk/IHNAAIAAE/g");
	this.shape_4.setTransform(23.1,16.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ_4_Слой_1, null, null);


(lib.Символ_2__копия_4_Слой_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(131,130,25,0)").ss(2,1,1).p("AAABPIAAid");
	this.shape.setTransform(9.025,2.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(132,131,26,0.02)").ss(2,1,1).p("AAAA7IAAh1");
	this.shape_1.setTransform(9.025,0.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(133,132,27,0.039)").ss(2,1,1).p("AAAAmIAAhL");
	this.shape_2.setTransform(9.025,-1.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(134,133,28,0.059)").ss(2,1,1).p("AAAASIAAgj");
	this.shape_3.setTransform(9.025,-2.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(135,133,29,0.078)").ss(2,1,1).p("AAAgCIAAAF");
	this.shape_4.setTransform(9.025,-4.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(136,134,30,0.098)").ss(2,1,1).p("AAAgWIAAAt");
	this.shape_5.setTransform(9.025,-6.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(138,135,32,0.114)").ss(2,1,1).p("AAAgqIAABV");
	this.shape_6.setTransform(9.025,-8.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(139,136,33,0.133)").ss(2,1,1).p("AAAg/IAAB/");
	this.shape_7.setTransform(9.025,-9.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(140,137,34,0.153)").ss(2,1,1).p("AAAhTIAACn");
	this.shape_8.setTransform(9.025,-11.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(141,138,35,0.173)").ss(2,1,1).p("AAAhoIAADR");
	this.shape_9.setTransform(9.025,-13.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(142,139,36,0.192)").ss(2,1,1).p("AAAh8IAAD5");
	this.shape_10.setTransform(9.025,-15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(143,140,37,0.212)").ss(2,1,1).p("AAAiQIAAEh");
	this.shape_11.setTransform(9.025,-16.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(144,140,38,0.231)").ss(2,1,1).p("AAAilIAAFL");
	this.shape_12.setTransform(9.025,-18.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(145,141,39,0.251)").ss(2,1,1).p("AAAi5IAAFz");
	this.shape_13.setTransform(9.025,-20.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(146,142,40,0.271)").ss(2,1,1).p("AAAjNIAAGb");
	this.shape_14.setTransform(9.025,-21.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(147,143,41,0.29)").ss(2,1,1).p("AAAjiIAAHF");
	this.shape_15.setTransform(9.025,-23.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(149,144,43,0.306)").ss(2,1,1).p("AAAj2IAAHt");
	this.shape_16.setTransform(9.025,-25.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(150,145,44,0.325)").ss(2,1,1).p("AAAkLIAAIX");
	this.shape_17.setTransform(9.025,-27.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(151,146,45,0.345)").ss(2,1,1).p("AAAkfIAAI/");
	this.shape_18.setTransform(9.025,-28.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(152,146,46,0.365)").ss(2,1,1).p("AAAkzIAAJn");
	this.shape_19.setTransform(9.025,-30.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(153,147,47,0.384)").ss(2,1,1).p("AAAlIIAAKR");
	this.shape_20.setTransform(9.025,-32.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(154,148,48,0.404)").ss(2,1,1).p("AAAlcIAAK5");
	this.shape_21.setTransform(9.025,-34.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(155,149,49,0.424)").ss(2,1,1).p("AAAlwIAALh");
	this.shape_22.setTransform(9.025,-35.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(156,150,50,0.443)").ss(2,1,1).p("AAAmFIAAMK");
	this.shape_23.setTransform(9.025,-37.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(157,151,51,0.463)").ss(2,1,1).p("AAAmZIAAMz");
	this.shape_24.setTransform(9.025,-39.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(158,152,52,0.482)").ss(2,1,1).p("AAAmtIAANb");
	this.shape_25.setTransform(9.025,-41.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(160,153,54,0.502)").ss(2,1,1).p("AAAnCIAAOF");
	this.shape_26.setTransform(9.025,-42.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(161,153,55,0.518)").ss(2,1,1).p("AAAnWIAAOt");
	this.shape_27.setTransform(9,-44.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(162,154,56,0.537)").ss(2,1,1).p("AAAnrIAAPX");
	this.shape_28.setTransform(9,-46.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(163,155,57,0.557)").ss(2,1,1).p("AAAn/IAAP/");
	this.shape_29.setTransform(9,-47.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(164,156,58,0.576)").ss(2,1,1).p("AAAoTIAAQn");
	this.shape_30.setTransform(9,-49.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(165,157,59,0.596)").ss(2,1,1).p("AAAooIAARR");
	this.shape_31.setTransform(9,-51.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(166,158,60,0.616)").ss(2,1,1).p("AAAo8IAAR5");
	this.shape_32.setTransform(9,-53.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(167,159,61,0.635)").ss(2,1,1).p("AAApQIAASh");
	this.shape_33.setTransform(9,-54.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(168,159,62,0.655)").ss(2,1,1).p("AAAplIAATL");
	this.shape_34.setTransform(9,-56.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(169,160,63,0.675)").ss(2,1,1).p("AAAp5IAATz");
	this.shape_35.setTransform(9,-58.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(170,161,64,0.694)").ss(2,1,1).p("AAAqNIAAUb");
	this.shape_36.setTransform(9,-60.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(172,162,66,0.71)").ss(2,1,1).p("AAAqiIAAVF");
	this.shape_37.setTransform(9,-61.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(173,163,67,0.729)").ss(2,1,1).p("AAAq2IAAVt");
	this.shape_38.setTransform(9,-63.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(174,164,68,0.749)").ss(2,1,1).p("AAArKIAAWV");
	this.shape_39.setTransform(9,-65.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(175,165,69,0.769)").ss(2,1,1).p("AAArfIAAW/");
	this.shape_40.setTransform(9,-67);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(176,165,70,0.788)").ss(2,1,1).p("AAArzIAAXn");
	this.shape_41.setTransform(9,-68.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(177,166,71,0.808)").ss(2,1,1).p("AAAsHIAAYP");
	this.shape_42.setTransform(9,-70.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(178,167,72,0.827)").ss(2,1,1).p("AAAscIAAY5");
	this.shape_43.setTransform(9,-72.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(179,168,73,0.847)").ss(2,1,1).p("AAAswIAAZh");
	this.shape_44.setTransform(9,-73.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(180,169,74,0.867)").ss(2,1,1).p("AAAtFIAAaL");
	this.shape_45.setTransform(9,-75.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(181,170,75,0.886)").ss(2,1,1).p("AAAtZIAAaz");
	this.shape_46.setTransform(9,-77.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(183,171,77,0.902)").ss(2,1,1).p("AAAttIAAbb");
	this.shape_47.setTransform(9,-79.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("rgba(184,172,78,0.922)").ss(2,1,1).p("AAAuCIAAcF");
	this.shape_48.setTransform(9,-80.85);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("rgba(185,172,79,0.941)").ss(2,1,1).p("AAAuWIAAct");
	this.shape_49.setTransform(9,-82.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(186,173,80,0.961)").ss(2,1,1).p("AAAuqIAAdV");
	this.shape_50.setTransform(9,-84.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("rgba(187,174,81,0.98)").ss(2,1,1).p("AAAu/IAAd/");
	this.shape_51.setTransform(9,-86.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#BCAF52").ss(2,1,1).p("AAAPUIAA+n");
	this.shape_52.setTransform(9,-87.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#99BC52").ss(2,1,1).p("AAAPUIAA+n");
	this.shape_53.setTransform(9,-87.8);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#99BC52").ss(2,1,1).p("AAAtfIAAa/");
	this.shape_54.setTransform(9,-76.175);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#99BC52").ss(2,1,1).p("AAArrIAAXX");
	this.shape_55.setTransform(9,-64.575);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#99BC52").ss(2,1,1).p("AAAp3IAATu");
	this.shape_56.setTransform(9,-52.95);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#99BC52").ss(2,1,1).p("AAAoDIAAQH");
	this.shape_57.setTransform(9,-41.35);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#99BC52").ss(2,1,1).p("AAAmOIAAMd");
	this.shape_58.setTransform(9,-29.725);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#99BC52").ss(2,1,1).p("AAAkaIAAI1");
	this.shape_59.setTransform(9,-18.125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#99BC52").ss(2,1,1).p("AAAimIAAFN");
	this.shape_60.setTransform(9,-6.5);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#99BC52").ss(2,1,1).p("AAAAzIAAhl");
	this.shape_61.setTransform(9,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},83).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},62).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_4_Слой_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B7BC52").s().p("Ag/BAQgbgbAAglQAAglAbgaQAagbAlAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQglABgagbg");
	this.shape.setTransform(9.05,9.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#B7BC52").s().p("Ag/BAQgbgaAAgmQAAglAbgaQAagbAlAAQAmAAAaAbQAbAaAAAlQAAAmgbAaQgaAbgmAAQglAAgagbg");
	this.shape_1.setTransform(9.05,9.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#B7BC52").s().p("AhABBQgbgbAAgmQAAglAbgbQAbgbAlAAQAmAAAbAbQAbAbAAAlQAAAmgbAbQgbAbgmAAQglAAgbgbg");
	this.shape_2.setTransform(9.05,9.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#B7BC52").s().p("AhBBCQgbgcAAgmQAAgmAbgbQAbgbAmAAQAmAAAcAbQAbAbAAAmQAAAmgbAcQgcAbgmAAQgmAAgbgbg");
	this.shape_3.setTransform(9.05,9.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#B7BC52").s().p("AhBBCQgcgbAAgnQAAgmAcgbQAbgcAmAAQAnAAAbAcQAcAbAAAmQAAAngcAbQgbAcgnAAQgmAAgbgcg");
	this.shape_4.setTransform(9.05,9.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#B7BC52").s().p("AhCBDQgbgcAAgnQAAgmAbgcQAcgbAmAAQAnAAAcAbQAcAcAAAmQAAAngcAcQgcAcgnAAQgmAAgcgcg");
	this.shape_5.setTransform(9.05,9.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#B7BC52").s().p("AhCBEQgcgdAAgnQAAgmAcgcQAcgcAmAAQAnAAAdAcQAbAcAAAmQAAAngbAdQgdAbgnAAQgmAAgcgbg");
	this.shape_6.setTransform(9.05,9.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#B7BC52").s().p("AhDBEQgcgdAAgnQAAgmAcgdQAdgcAmAAQAnAAAdAcQAcAdAAAmQAAAngcAdQgdAcgnAAQgmAAgdgcg");
	this.shape_7.setTransform(9.05,9.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#B8BC52").s().p("AhDBEQgdgcAAgoQAAgnAdgcQAcgdAnAAQAoAAAcAdQAcAcABAnQgBAogcAcQgcAcgoABQgngBgcgcg");
	this.shape_8.setTransform(9.05,9.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#B8BC52").s().p("AhEBFQgcgcAAgpQAAgnAcgdQAdgcAnAAQApAAAcAcQAcAdAAAnQAAApgcAcQgcAcgpAAQgnAAgdgcg");
	this.shape_9.setTransform(9.05,9.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#B8BC52").s().p("AhEBFQgdgcAAgpQAAgnAdgdQAdgdAnAAQApAAAcAdQAdAdAAAnQAAApgdAcQgcAdgpAAQgnAAgdgdg");
	this.shape_10.setTransform(9.05,9.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#B8BC52").s().p("AhFBGQgdgdAAgpQAAgoAdgdQAdgdAoAAQApAAAdAdQAcAdAAAoQAAApgcAdQgdAcgpAAQgoAAgdgcg");
	this.shape_11.setTransform(9.05,9.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#B8BC52").s().p("AhFBGQgdgdAAgpQAAgoAdgdQAdgdAoAAQApAAAdAdQAdAdAAAoQAAApgdAdQgdAdgpAAQgoAAgdgdg");
	this.shape_12.setTransform(9.05,9.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#B8BC52").s().p("AhGBHQgdgdAAgqQAAgpAdgdQAdgdApAAQAqAAAdAdQAdAdAAApQAAAqgdAdQgdAdgqAAQgpAAgdgdg");
	this.shape_13.setTransform(9.05,9.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B8BC52").s().p("AhGBHQgegdABgqQgBgpAegdQAdgeApABQAqgBAdAeQAeAdgBApQABAqgeAdQgdAegqgBQgpABgdgeg");
	this.shape_14.setTransform(9.05,9.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#B8BC52").s().p("AhHBHQgdgdAAgqQAAgpAdgeQAegdApAAQAqAAAdAdQAeAeAAApQAAAqgeAdQgdAegqAAQgpAAgegeg");
	this.shape_15.setTransform(9.05,9.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#B8BC52").s().p("AhHBIQgegeAAgqQAAgpAegeQAegeApAAQAqAAAeAeQAeAeAAApQAAAqgeAeQgeAegqAAQgpAAgegeg");
	this.shape_16.setTransform(9.05,9.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#B8BC52").s().p("AhIBIQgdgdAAgrQAAgqAdgeQAegdAqAAQArAAAdAdQAeAeAAAqQAAArgeAdQgdAegrAAQgqAAgegeg");
	this.shape_17.setTransform(9.05,9.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#B8BC52").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAeAeAAAqQAAArgeAeQgeAegrAAQgqAAgegeg");
	this.shape_18.setTransform(9.05,9.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#B8BC52").s().p("AhIBJQgfgeAAgrQAAgqAfgeQAegfAqAAQArAAAeAfQAfAeAAAqQAAArgfAeQgeAfgrAAQgqAAgegfg");
	this.shape_19.setTransform(9.05,9.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#B8BC52").s().p("AhJBKQgfgeAAgsQAAgqAfgfQAfgfAqAAQAsAAAeAfQAfAfAAAqQAAAsgfAeQgeAfgsAAQgqAAgfgfg");
	this.shape_20.setTransform(9.05,9.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#B8BC52").s().p("AhJBKQgfgeAAgsQAAgrAfgeQAegfArAAQAsAAAeAfQAfAeAAArQAAAsgfAeQgeAfgsAAQgrAAgegfg");
	this.shape_21.setTransform(9.05,9.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#B8BC52").s().p("AhKBLQgfgfAAgsQAAgrAfgfQAfgfArAAQAsAAAfAfQAfAfAAArQAAAsgfAfQgfAfgsAAQgrAAgfgfg");
	this.shape_22.setTransform(9.05,9.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#B8BC52").s().p("AhKBLQgggfAAgsQAAgrAggfQAfggArAAQAsAAAfAgQAgAfAAArQAAAsggAfQgfAggsAAQgrAAgfggg");
	this.shape_23.setTransform(9.05,9.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#B9BC52").s().p("AhKBLQgggeAAgtQAAgsAggeQAeggAsAAQAtAAAeAgQAgAeAAAsQAAAtggAeQgeAggtAAQgsAAgeggg");
	this.shape_24.setTransform(9.05,9.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#B9BC52").s().p("AhLBMQgggfAAgtQAAgsAggfQAfggAsAAQAtAAAfAgQAgAfAAAsQAAAtggAfQgfAggtAAQgsAAgfggg");
	this.shape_25.setTransform(9.05,9.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#B9BC52").s().p("AhLBNQghggAAgtQAAgsAhgfQAfghAsAAQAtAAAgAhQAfAfAAAsQAAAtgfAgQggAfgtAAQgsAAgfgfg");
	this.shape_26.setTransform(9.05,9.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#B9BC52").s().p("AhMBNQgggfAAguQAAgtAggfQAfggAtAAQAuAAAfAgQAgAfAAAtQAAAuggAfQgfAgguAAQgtAAgfggg");
	this.shape_27.setTransform(9.05,9.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#B9BC52").s().p("AhNBOQggghAAgtQAAgsAgghQAhggAsAAQAtAAAhAgQAgAhAAAsQAAAtggAhQghAggtAAQgsAAghggg");
	this.shape_28.setTransform(9.05,9.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#B9BC52").s().p("AhNBOQghggABguQgBgtAhggQAgghAtABQAugBAgAhQAhAggBAtQABAughAgQggAhgugBQgtABggghg");
	this.shape_29.setTransform(9.05,9.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#B9BC52").s().p("AhOBPQggghAAguQAAgtAgghQAhggAtAAQAuAAAhAgQAgAhAAAtQAAAuggAhQghAgguAAQgtAAghggg");
	this.shape_30.setTransform(9.05,9.05);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#B9BC52").s().p("AhOBPQghggAAgvQAAguAhggQAgghAuAAQAvAAAgAhQAhAgAAAuQAAAvghAgQggAhgvAAQguAAggghg");
	this.shape_31.setTransform(9.05,9.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#B9BC52").s().p("AhPBQQgggiAAguQAAgtAggiQAiggAtAAQAuAAAiAgQAgAiABAtQgBAuggAiQgiAgguABQgtgBgiggg");
	this.shape_32.setTransform(9.05,9.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#B9BC52").s().p("AhPBQQghghAAgvQAAguAhghQAhghAuAAQAvAAAhAhQAhAhAAAuQAAAvghAhQghAhgvAAQguAAghghg");
	this.shape_33.setTransform(9.05,9.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#B9BC52").s().p("AhQBRQghgiAAgvQAAguAhgiQAighAuAAQAvAAAiAhQAhAiAAAuQAAAvghAiQgiAhgvAAQguAAgighg");
	this.shape_34.setTransform(9.05,9.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#B9BC52").s().p("AhQBRQgigiAAgvQAAgvAighQAhgiAvAAQAvAAAiAiQAhAhABAvQgBAvghAiQgiAhgvABQgvgBghghg");
	this.shape_35.setTransform(9.05,9.05);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#B9BC52").s().p("AhRBRQghghAAgwQAAgvAhgiQAighAvAAQAwAAAhAhQAiAiAAAvQAAAwgiAhQghAigwAAQgvAAgigig");
	this.shape_36.setTransform(9.05,9.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#B9BC52").s().p("AhRBSQgigiAAgwQAAgvAigiQAigiAvAAQAwAAAiAiQAiAiAAAvQAAAwgiAiQgiAigwAAQgvAAgigig");
	this.shape_37.setTransform(9.05,9.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#B9BC52").s().p("AhRBSQgjghAAgxQAAgwAjghQAhgjAwAAQAxAAAhAjQAjAhgBAwQABAxgjAhQghAjgxgBQgwABghgjg");
	this.shape_38.setTransform(9.05,9.05);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#B9BC52").s().p("AhSBTQgigjAAgwQAAgvAigjQAjgiAvAAQAwAAAjAiQAiAjAAAvQAAAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_39.setTransform(9.05,9.05);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#B9BC52").s().p("AhSBTQgjgiAAgxQAAgwAjgiQAigjAwAAQAxAAAiAjQAjAiAAAwQAAAxgjAiQgiAjgxAAQgwAAgigjg");
	this.shape_40.setTransform(9.05,9.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#BABB52").s().p("AhSBTQgkgiABgxQgBgwAkgiQAigkAwABQAxgBAiAkQAkAigBAwQABAxgkAiQgiAkgxgBQgwABgigkg");
	this.shape_41.setTransform(9.05,9.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#BABB52").s().p("AhTBUQgjgjAAgxQAAgwAjgjQAjgjAwAAQAxAAAjAjQAkAjgBAwQABAxgkAjQgjAkgxgBQgwABgjgkg");
	this.shape_42.setTransform(9.05,9.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#BABB52").s().p("AhTBUQgkgjAAgxQAAgxAkgiQAigkAxAAQAxAAAjAkQAkAiAAAxQAAAxgkAjQgjAkgxAAQgxAAgigkg");
	this.shape_43.setTransform(9.05,9.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#BABB52").s().p("AhUBVQgkgjABgyQgBgxAkgjQAjgkAxABQAygBAjAkQAkAjgBAxQABAygkAjQgjAkgygBQgxABgjgkg");
	this.shape_44.setTransform(9.05,9.05);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#BABB52").s().p("AhUBWQgkgkAAgyQAAgxAkgjQAjgkAxAAQAyAAAkAkQAjAjABAxQgBAygjAkQgkAjgyABQgxgBgjgjg");
	this.shape_45.setTransform(9.05,9.05);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#BABB52").s().p("AhVBWQgkgkAAgyQAAgxAkgkQAkgkAxAAQAyAAAkAkQAkAkAAAxQAAAygkAkQgkAkgyAAQgxAAgkgkg");
	this.shape_46.setTransform(9.05,9.05);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#BABB52").s().p("AhWBXQgjgkgBgzQABgyAjgkQAkgjAygBQAzABAkAjQAjAkABAyQgBAzgjAkQgkAjgzABQgygBgkgjg");
	this.shape_47.setTransform(9.05,9.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#BABB52").s().p("AhWBXQglgkAAgzQAAgyAlgkQAkglAyAAQAzAAAkAlQAlAkAAAyQAAAzglAkQgkAlgzAAQgyAAgkglg");
	this.shape_48.setTransform(9.05,9.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#BABB52").s().p("AhXBYQgkglAAgzQAAgyAkglQAlgkAyAAQAzAAAlAkQAkAlAAAyQAAAzgkAlQglAkgzAAQgyAAglgkg");
	this.shape_49.setTransform(9.05,9.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#BABB52").s().p("AhXBYQglglAAgzQAAgzAlgkQAkglAzAAQAzAAAlAlQAlAkAAAzQAAAzglAlQglAlgzAAQgzAAgkglg");
	this.shape_50.setTransform(9.05,9.05);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#BABB52").s().p("AhYBZQglglAAg0QAAgzAlglQAlglAzAAQA0AAAlAlQAlAlAAAzQAAA0glAlQglAlg0AAQgzAAglglg");
	this.shape_51.setTransform(9.05,9.05);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#BABB52").s().p("AhZBaQglgmAAg0QAAgzAlgmQAmglAzAAQA0AAAmAlQAlAmgBAzQABA0glAmQgmAlg0gBQgzABgmglg");
	this.shape_52.setTransform(9.05,9.05);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#BABB52").s().p("AhZBaQglgmAAg0QAAg0AlglQAlglA0AAQA0AAAmAlQAlAlAAA0QAAA0glAmQgmAlg0AAQg0AAglglg");
	this.shape_53.setTransform(9.05,9.05);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#BABB52").s().p("AhaBaQglglAAg1QAAg0AlgmQAmglA0AAQA1AAAlAlQAmAmAAA0QAAA1gmAlQglAmg1AAQg0AAgmgmg");
	this.shape_54.setTransform(9.05,9.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#BABB52").s().p("AhaBbQglglAAg2QAAg0AlgmQAmglA0AAQA2AAAlAlQAlAmAAA0QAAA2glAlQglAlg2AAQg0AAgmglg");
	this.shape_55.setTransform(9.05,9.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#BABB52").s().p("AhaBbQgmglAAg2QAAg0AmgmQAmgmA0AAQA2AAAlAmQAmAmAAA0QAAA2gmAlQglAmg2AAQg0AAgmgmg");
	this.shape_56.setTransform(9.05,9.05);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#BBBB52").s().p("AhaBbQgnglAAg2QAAg1AnglQAlgnA1AAQA2AAAlAnQAnAlAAA1QAAA2gnAlQglAng2AAQg1AAglgng");
	this.shape_57.setTransform(9.05,9.05);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#BBBB52").s().p("AhbBcQgngmABg2QgBg1AngmQAmgnA1ABQA2gBAmAnQAnAmAAA1QAAA2gnAmQgmAng2AAQg1AAgmgng");
	this.shape_58.setTransform(9.05,9.05);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#BBBB52").s().p("AhbBcQgoglAAg3QAAg1AogmQAmgoA1AAQA3AAAlAoQAoAmAAA1QAAA3goAlQglAog3AAQg1AAgmgog");
	this.shape_59.setTransform(9.05,9.05);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#BBBB52").s().p("AhcBdQgngmAAg3QAAg1AngnQAngnA1AAQA3AAAmAnQAnAnAAA1QAAA3gnAmQgmAng3AAQg1AAgngng");
	this.shape_60.setTransform(9.05,9.05);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#BBBB52").s().p("AhcBdQgogmAAg3QAAg2AogmQAmgoA2AAQA3AAAmAoQAnAmABA2QgBA3gnAmQgmAng3ABQg2gBgmgng");
	this.shape_61.setTransform(9.05,9.05);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#BBBB52").s().p("AhdBeQgognAAg3QAAg2AognQAngoA2AAQA3AAAnAoQAoAnAAA2QAAA3goAnQgnAog3AAQg2AAgngog");
	this.shape_62.setTransform(9.05,9.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#BBBB52").s().p("AhdBfQgognAAg4QAAg3AogmQAmgoA3AAQA4AAAnAoQAnAmAAA3QAAA4gnAnQgnAng4AAQg3AAgmgng");
	this.shape_63.setTransform(9.05,9.05);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#BBBB52").s().p("AheBfQgognAAg4QAAg3AognQAngoA3AAQA4AAAnAoQAoAnAAA3QAAA4goAnQgnAog4AAQg3AAgngog");
	this.shape_64.setTransform(9.05,9.05);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#BBBB52").s().p("AhfBgQgogoAAg4QAAg3AogoQAogoA3AAQA4AAAoAoQAoAogBA3QABA4goAoQgoAog4gBQg3ABgogog");
	this.shape_65.setTransform(9.05,9.05);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#BBBB52").s().p("AhfBgQgogoAAg4QAAg4AognQAngoA4AAQA4AAAoAoQAoAnAAA4QAAA4goAoQgoAog4AAQg4AAgngog");
	this.shape_66.setTransform(9.05,9.05);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#BBBB52").s().p("AhgBhQgogoABg5QgBg4AogoQAogoA4ABQA5gBAoAoQAoAogBA4QABA5goAoQgoAog5gBQg4ABgogog");
	this.shape_67.setTransform(9.05,9.05);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#BBBB52").s().p("AhgBhQgogoAAg5QAAg4AogoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA5goAoQgoAog5AAQg4AAgogog");
	this.shape_68.setTransform(9.05,9.05);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#BBBB52").s().p("AhhBiQgogpAAg5QAAg4AogpQApgoA4AAQA5AAApAoQAoApAAA4QAAA5goApQgpAog5AAQg4AAgpgog");
	this.shape_69.setTransform(9.05,9.05);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#BBBB52").s().p("AhhBiQgogpAAg5QAAg5AogoQAogoA5AAQA5AAApAoQAoAoAAA5QAAA5goApQgpAog5AAQg5AAgogog");
	this.shape_70.setTransform(9.05,9.05);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#BBBB52").s().p("AhiBiQgogoAAg6QAAg5AogpQApgoA5AAQA6AAAoAoQAqApAAA5QAAA6gqAoQgoAqg6AAQg5AAgpgqg");
	this.shape_71.setTransform(9.05,9.05);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#BBBB52").s().p("AhiBjQgpgpAAg6QAAg5ApgpQApgpA5AAQA6AAApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape_72.setTransform(9.05,9.05);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#BCBB52").s().p("AhiBjQgqgoAAg7QAAg6AqgoQAogqA6AAQA7AAAoAqQAqAoAAA6QAAA7gqAoQgoAqg7AAQg6AAgogqg");
	this.shape_73.setTransform(9.05,9.05);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#BCBB52").s().p("AhjBjQgqgpAAg6QAAg6AqgpQApgqA6AAQA6AAApAqQAqApABA6QgBA6gqApQgpAqg6ABQg6gBgpgqg");
	this.shape_74.setTransform(9.05,9.05);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#BCBB52").s().p("AhjBkQgqgpAAg7QAAg6AqgpQApgqA6AAQA7AAApAqQAqApAAA6QAAA7gqApQgpAqg7AAQg6AAgpgqg");
	this.shape_75.setTransform(9.05,9.05);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#BCBB52").s().p("AhjBkQgqgpgBg7QABg6AqgpQApgqA6gBQA7ABApAqQAqApABA6QgBA7gqApQgpAqg7ABQg6gBgpgqg");
	this.shape_76.setTransform(9.05,9.05);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#BCBB52").s().p("AhkBlQgrgpAAg8QAAg7ArgpQApgrA7AAQA8AAApArQArApgBA7QABA8grApQgpArg8gBQg7ABgpgrg");
	this.shape_77.setTransform(9.05,9.05);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#BCBB52").s().p("AhkBlQgrgqAAg7QAAg7ArgpQApgrA7AAQA7AAAqArQArApAAA7QAAA7grAqQgqArg7AAQg7AAgpgrg");
	this.shape_78.setTransform(9.05,9.05);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#BCBB52").s().p("AhlBmQgrgqAAg8QAAg7ArgqQAqgrA7AAQA8AAAqArQAqAqAAA7QAAA8gqAqQgqAqg8AAQg7AAgqgqg");
	this.shape_79.setTransform(9.05,9.05);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#BCBB52").s().p("AhlBmQgsgqABg8QgBg7AsgqQAqgsA7ABQA8gBAqAsQAsAqgBA7QABA8gsAqQgqAsg8gBQg7ABgqgsg");
	this.shape_80.setTransform(9.05,9.05);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#BCBB52").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_81.setTransform(9.05,9.05);
	this.shape_81._off = true;

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#BCBA52").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_82.setTransform(9.05,9.05);
	this.shape_82._off = true;

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#BCB952").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_83.setTransform(9.05,9.05);
	this.shape_83._off = true;

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#BCB852").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_84.setTransform(9.05,9.05);
	this.shape_84._off = true;

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#BCB752").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_85.setTransform(9.05,9.05);
	this.shape_85._off = true;

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#BCB652").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_86.setTransform(9.05,9.05);
	this.shape_86._off = true;

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#BCB552").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_87.setTransform(9.05,9.05);
	this.shape_87._off = true;

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#BBB852").s().p("AhhBiQgpgpAAg5QAAg5ApgoQAogpA5AAQA5AAApApQApAoAAA5QAAA5gpApQgpApg5AAQg5AAgogpg");
	this.shape_88.setTransform(9.05,9.05);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#BABB52").s().p("AhcBdQgngmAAg3QAAg1AngnQAngnA1AAQA3AAAmAnQAnAnAAA1QAAA3gnAmQgmAng3AAQg1AAgngng");
	this.shape_89.setTransform(9.05,9.05);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#B9BE52").s().p("AhYBZQgkglAAg0QAAgzAkglQAlgkAzAAQA0AAAlAkQAkAlAAAzQAAA0gkAlQglAkg0AAQgzAAglgkg");
	this.shape_90.setTransform(9.05,9.05);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#B8C252").s().p("AhTBTQgigiAAgxQAAgwAigjQAjgiAwAAQAxAAAiAiQAjAjAAAwQAAAxgjAiQgiAjgxAAQgwAAgjgjg");
	this.shape_91.setTransform(9.075,9.075);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#B6C552").s().p("AhOBPQggghAAguQAAgtAgghQAhggAtAAQAuAAAhAgQAgAhAAAtQAAAuggAhQghAgguAAQgtAAghggg");
	this.shape_92.setTransform(9.05,9.05);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#B5C852").s().p("AhIBKQgfgegBgsQABgqAfgeQAegfAqgBQAsABAeAfQAfAeAAAqQAAAsgfAeQgeAfgsAAQgqAAgegfg");
	this.shape_93.setTransform(9.05,9.05);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#B4CB52").s().p("AhEBFQgcgcgBgpQABgnAcgdQAdgcAngBQApABAcAcQAcAdABAnQgBApgcAcQgcAcgpABQgngBgdgcg");
	this.shape_94.setTransform(9.05,9.05);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#B3CE52").s().p("Ag/BAQgbgbAAglQAAglAbgaQAagbAlAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQglABgagbg");
	this.shape_95.setTransform(9.05,9.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_81).wait(83).to({_off:false},0).wait(4).to({_off:true},1).wait(118));
	this.timeline.addTween(cjs.Tween.get(this.shape_82).wait(88).to({_off:false},0).wait(8).to({_off:true},1).wait(109));
	this.timeline.addTween(cjs.Tween.get(this.shape_83).wait(97).to({_off:false},0).wait(7).to({_off:true},1).wait(101));
	this.timeline.addTween(cjs.Tween.get(this.shape_84).wait(105).to({_off:false},0).wait(8).to({_off:true},1).wait(92));
	this.timeline.addTween(cjs.Tween.get(this.shape_85).wait(114).to({_off:false},0).wait(8).to({_off:true},1).wait(83));
	this.timeline.addTween(cjs.Tween.get(this.shape_86).wait(123).to({_off:false},0).wait(7).to({_off:true},1).wait(75));
	this.timeline.addTween(cjs.Tween.get(this.shape_87).wait(131).to({_off:false},0).wait(66).to({_off:true},1).wait(8));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_4_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#C1CE52","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,37.9).s().p("AkKELQhuhuAAidQAAibBuhvQBvhuCbAAQCdAABuBuQBvBvAACbQAACdhvBuQhuBvidAAQibAAhvhvg");
	this.shape.setTransform(9.1,9.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(193,206,82,0.992)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.2).s().p("AkLEMQhvhugBieQABidBvhuQBuhvCdgBQCeABBuBvQBwBuAACdQAACehwBuQhuBwieAAQidAAhuhwg");
	this.shape_1.setTransform(9.1,9.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(193,206,82,0.988)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.3).s().p("AkNEOQhwhwAAieQAAidBwhwQBwhwCdAAQCeAABwBwQBwBwAACdQAACehwBwQhwBwieAAQidAAhwhwg");
	this.shape_2.setTransform(9.125,9.125);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(193,206,82,0.98)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.6).s().p("AkPEQQhwhxAAifQAAieBwhxQBxhwCeAAQCfAABxBwQBwBxAACeQAACfhwBxQhxBwifAAQieAAhxhwg");
	this.shape_3.setTransform(9.1,9.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(193,206,82,0.976)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.8).s().p("AkQERQhxhxAAigQAAifBxhxQBxhxCfAAQCgAABxBxQBxBxAACfQAACghxBxQhxBxigAAQifAAhxhxg");
	this.shape_4.setTransform(9.1,9.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(193,206,82,0.969)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39).s().p("AkSESQhxhxAAihQAAigBxhyQByhxCgAAQChAABxBxQByByAACgQAAChhyBxQhxByihAAQigAAhyhyg");
	this.shape_5.setTransform(9.1,9.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(194,206,82,0.965)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.2).s().p("AkTEUQhyhyAAiiQAAihByhyQByhyChAAQCiAAByByQByByAAChQAACihyByQhyByiiAAQihAAhyhyg");
	this.shape_6.setTransform(9.125,9.125);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(194,206,82,0.957)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.4).s().p("AkUEVQh0hyAAijQAAiiB0hyQByh0CiAAQCjAAByB0QB0BygBCiQABCjh0ByQhyB0ijgBQiiABhyh0g");
	this.shape_7.setTransform(9.1,9.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(194,206,82,0.953)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.7).s().p("AkWEXQhzhzAAikQAAiiBzh0QB0hzCiAAQCkAABzBzQB0B0gBCiQABCkh0BzQhzB0ikgBQiiABh0h0g");
	this.shape_8.setTransform(9.1,9.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(194,206,82,0.945)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.8).s().p("AkYEZQhzh1AAikQAAijBzh1QB1hzCjAAQCkAAB1BzQBzB1ABCjQgBCkhzB1Qh1BzikABQijgBh1hzg");
	this.shape_9.setTransform(9.1,9.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(194,206,82,0.941)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.1).s().p("AkZEaQh1h1AAilQAAikB1h1QB1h1CkAAQClAAB1B1QB1B1AACkQAAClh1B1Qh1B1ilAAQikAAh1h1g");
	this.shape_10.setTransform(9.125,9.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(194,206,82,0.933)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.3).s().p("AkbEbQh1h1AAimQAAilB1h2QB2h1ClAAQCmAAB1B1QB2B2AAClQAACmh2B1Qh1B2imAAQilAAh2h2g");
	this.shape_11.setTransform(9.1,9.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(194,206,82,0.925)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.5).s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_12.setTransform(9.1,9.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(194,206,82,0.922)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.8).s().p("AkdEeQh3h2AAioQAAinB3h2QB2h3CnAAQCoAAB2B3QB3B2AACnQAACoh3B2Qh2B3ioAAQinAAh2h3g");
	this.shape_13.setTransform(9.1,9.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(194,206,82,0.914)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.9).s().p("AkfEgQh3h3AAipQAAioB3h3QB3h3CoAAQCpAAB3B3QB3B3AACoQAACph3B3Qh3B3ipAAQioAAh3h3g");
	this.shape_14.setTransform(9.125,9.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(194,206,82,0.91)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.2).s().p("AkhEhQh3h3AAiqQAAipB3h4QB4h3CpAAQCqAAB3B3QB4B4AACpQAACqh4B3Qh3B4iqAAQipAAh4h4g");
	this.shape_15.setTransform(9.125,9.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["rgba(194,206,82,0.902)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.3).s().p("AkiEjQh4h4AAirQAAiqB4h4QB4h4CqAAQCrAAB4B4QB4B4AACqQAACrh4B4Qh4B4irAAQiqAAh4h4g");
	this.shape_16.setTransform(9.1,9.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["rgba(194,206,82,0.898)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.6).s().p("AkkEkQh4h4AAisQAAirB4h5QB5h4CrAAQCsAAB4B4QB6B5AACrQAACsh6B4Qh4B6isAAQirAAh5h6g");
	this.shape_17.setTransform(9.1,9.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["rgba(195,206,82,0.89)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.8).s().p("AklEmQh6h6AAisQAAirB6h6QB6h6CrAAQCsAAB6B6QB6B6AACrQAACsh6B6Qh6B6isAAQirAAh6h6g");
	this.shape_18.setTransform(9.125,9.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["rgba(195,206,82,0.886)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42).s().p("AknEnQh6h6AAitQAAisB6h7QB7h6CsAAQCtAAB6B6QB7B7AACsQAACth7B6Qh6B7itAAQisAAh7h7g");
	this.shape_19.setTransform(9.125,9.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["rgba(195,206,82,0.878)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.2).s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape_20.setTransform(9.1,9.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["rgba(195,206,82,0.875)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.4).s().p("AkqErQh7h8AAivQAAiuB7h8QB8h7CuAAQCvAAB8B7QB7B8AACuQAACvh7B8Qh8B7ivAAQiuAAh8h7g");
	this.shape_21.setTransform(9.1,9.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["rgba(195,206,82,0.867)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.7).s().p("AkrEsQh8h8AAiwQAAivB8h8QB8h8CvAAQCwAAB8B8QB8B8AACvQAACwh8B8Qh8B8iwAAQivAAh8h8g");
	this.shape_22.setTransform(9.125,9.125);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["rgba(195,206,82,0.863)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.8).s().p("AktEtQh8h8AAixQAAiwB8h9QB9h8CwAAQCxAAB8B8QB9B9AACwQAACxh9B8Qh8B9ixAAQiwAAh9h9g");
	this.shape_23.setTransform(9.125,9.125);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["rgba(195,206,82,0.855)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.1).s().p("AkuEvQh9h9AAiyQAAixB9h9QB9h9CxAAQCyAAB9B9QB9B9AACxQAACyh9B9Qh9B9iyAAQixAAh9h9g");
	this.shape_24.setTransform(9.125,9.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["rgba(195,206,82,0.847)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.3).s().p("AkvEwQh/h+ABiyQgBiyB/h9QB9h/CyABQCygBB+B/QB/B9gBCyQABCyh/B+Qh+B/iygBQiyABh9h/g");
	this.shape_25.setTransform(9.1,9.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["rgba(195,206,82,0.843)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.5).s().p("AkxEyQh/h/AAizQAAiyB/h/QB/h/CyAAQCzAAB/B/QB/B/AACyQAACzh/B/Qh/B/izAAQiyAAh/h/g");
	this.shape_26.setTransform(9.125,9.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["rgba(195,206,82,0.835)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.7).s().p("AkzEzQh/h/AAi0QAAizB/iAQCAh/CzAAQC0AAB/B/QCACAAACzQAAC0iAB/Qh/CAi0AAQizAAiAiAg");
	this.shape_27.setTransform(9.125,9.125);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.rf(["rgba(195,206,82,0.831)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.9).s().p("Ak0E1QiAiAAAi1QAAi0CAiAQCAiAC0AAQC1AACACAQCACAAAC0QAAC1iACAQiACAi1AAQi0AAiAiAg");
	this.shape_28.setTransform(9.125,9.125);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["rgba(195,206,82,0.824)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.1).s().p("Ak2E2QiAiAAAi2QAAi1CAiBQCBiAC1AAQC2AACACAQCBCBAAC1QAAC2iBCAQiACBi2AAQi1AAiBiBg");
	this.shape_29.setTransform(9.1,9.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.rf(["rgba(196,206,82,0.82)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.3).s().p("Ak3E4QiBiBAAi3QAAi2CBiBQCBiBC2AAQC3AACBCBQCBCBAAC2QAAC3iBCBQiBCBi3AAQi2AAiBiBg");
	this.shape_30.setTransform(9.125,9.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["rgba(196,206,82,0.812)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.6).s().p("Ak5E5QiBiBAAi4QAAi3CBiCQCCiBC3AAQC4AACBCBQCCCCAAC3QAAC4iCCBQiBCCi4AAQi3AAiCiCg");
	this.shape_31.setTransform(9.125,9.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.rf(["rgba(196,206,82,0.808)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.8).s().p("Ak6E7QiCiCAAi5QAAi4CCiCQCCiCC4AAQC5AACCCCQCCCCAAC4QAAC5iCCCQiCCCi5AAQi4AAiCiCg");
	this.shape_32.setTransform(9.125,9.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["rgba(196,206,82,0.8)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45).s().p("Ak8E9QiCiDAAi6QAAi5CCiDQCDiCC5AAQC6AACDCCQCCCDAAC5QAAC6iCCDQiDCCi6AAQi5AAiDiCg");
	this.shape_33.setTransform(9.1,9.1);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.rf(["rgba(196,206,82,0.796)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.2).s().p("Ak9E+QiEiEAAi6QAAi5CEiEQCEiEC5AAQC6AACECEQCECEAAC5QAAC6iECEQiECEi6AAQi5AAiEiEg");
	this.shape_34.setTransform(9.125,9.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["rgba(196,206,82,0.788)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.4).s().p("Ak/E/QiEiEAAi7QAAi6CEiFQCFiEC6AAQC7AACECEQCFCFAAC6QAAC7iFCEQiECFi7AAQi6AAiFiFg");
	this.shape_35.setTransform(9.125,9.125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.rf(["rgba(196,206,82,0.78)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.6).s().p("AlAFBQiFiFAAi8QAAi7CFiFQCFiFC7AAQC8AACFCFQCFCFAAC7QAAC8iFCFQiFCFi8AAQi7AAiFiFg");
	this.shape_36.setTransform(9.125,9.125);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["rgba(196,206,82,0.776)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.8).s().p("AlCFCQiFiFAAi9QAAi8CFiGQCGiFC8AAQC9AACFCFQCGCGAAC8QAAC9iGCFQiFCGi9AAQi8AAiGiGg");
	this.shape_37.setTransform(9.125,9.125);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.rf(["rgba(196,206,82,0.769)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.1).s().p("AlDFEQiGiGAAi+QAAi9CGiGQCGiGC9AAQC+AACGCGQCGCGAAC9QAAC+iGCGQiGCGi+AAQi9AAiGiGg");
	this.shape_38.setTransform(9.125,9.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.rf(["rgba(196,206,82,0.765)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.3).s().p("AlFFFQiGiGAAi/QAAi+CGiHQCHiGC+AAQC/AACGCGQCHCHAAC+QAAC/iHCGQiGCHi/AAQi+AAiHiHg");
	this.shape_39.setTransform(9.125,9.125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.rf(["rgba(196,206,82,0.757)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.5).s().p("AlGFHQiHiHAAjAQAAi/CHiHQCHiHC/AAQDAAACHCHQCHCHAAC/QAADAiHCHQiHCHjAAAQi/AAiHiHg");
	this.shape_40.setTransform(9.125,9.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.rf(["rgba(196,206,82,0.753)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.7).s().p("AlIFIQiHiHAAjBQAAjACHiIQCIiHDAAAQDBAACHCHQCICIAADAQAADBiICHQiHCIjBAAQjAAAiIiIg");
	this.shape_41.setTransform(9.125,9.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.rf(["rgba(197,206,82,0.745)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.9).s().p("AlJFKQiJiJAAjBQAAjACJiJQCJiJDAAAQDBAACJCJQCJCJAADAQAADBiJCJQiJCJjBAAQjAAAiJiJg");
	this.shape_42.setTransform(9.125,9.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.rf(["rgba(197,206,82,0.741)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.1).s().p("AlKFMQiKiKAAjCQAAjBCKiJQCJiKDBAAQDCAACKCKQCJCJAADBQAADCiJCKQiKCJjCAAQjBAAiJiJg");
	this.shape_43.setTransform(9.125,9.125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.rf(["rgba(197,206,82,0.733)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.3).s().p("AlMFNQiKiKAAjDQAAjCCKiKQCKiKDCAAQDDAACKCKQCKCKAADCQAADDiKCKQiKCKjDAAQjCAAiKiKg");
	this.shape_44.setTransform(9.125,9.125);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.rf(["rgba(197,206,82,0.729)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.6).s().p("AlNFPQiLiLAAjEQAAjDCLiKQCKiLDDAAQDEAACLCLQCKCKAADDQAADEiKCLQiLCKjEAAQjDAAiKiKg");
	this.shape_45.setTransform(9.125,9.125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.rf(["rgba(197,206,82,0.722)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.8).s().p("AlPFQQiLiLAAjFQAAjECLiLQCLiLDEAAQDFAACLCLQCLCLAADEQAADFiLCLQiLCLjFAAQjEAAiLiLg");
	this.shape_46.setTransform(9.125,9.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.rf(["rgba(197,206,82,0.718)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.9).s().p("AlQFSQiMiMAAjGQAAjFCMiLQCLiMDFAAQDGAACMCMQCLCLAADFQAADGiLCMQiMCLjGAAQjFAAiLiLg");
	this.shape_47.setTransform(9.125,9.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.rf(["rgba(197,206,82,0.71)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.2).s().p("AlSFTQiMiMAAjHQAAjGCMiMQCMiMDGAAQDHAACMCMQCMCMAADGQAADHiMCMQiMCMjHAAQjGAAiMiMg");
	this.shape_48.setTransform(9.125,9.125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.rf(["rgba(197,206,82,0.702)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.4).s().p("AlTFVQiNiNAAjIQAAjHCNiMQCMiNDHAAQDIAACNCNQCMCMAADHQAADIiMCNQiNCMjIAAQjHAAiMiMg");
	this.shape_49.setTransform(9.125,9.125);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.rf(["rgba(197,206,82,0.698)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,48.6).s().p("AlVFWQiOiNAAjJQAAjICOiNQCNiODIAAQDJAACNCOQCNCNABDIQgBDJiNCNQiNCNjJABQjIgBiNiNg");
	this.shape_50.setTransform(9.15,9.15);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.rf(["rgba(197,206,82,0.69)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.8).s().p("AlWFYQiPiPAAjJQAAjICPiOQCOiPDIAAQDJAACPCPQCOCOAADIQAADJiOCPQiPCOjJAAQjIAAiOiOg");
	this.shape_51.setTransform(9.125,9.125);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.rf(["rgba(197,206,82,0.686)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.1).s().p("AlYFZQiPiPAAjKQAAjJCPiPQCPiPDJAAQDKAACPCPQCPCPAADJQAADKiPCPQiPCPjKAAQjJAAiPiPg");
	this.shape_52.setTransform(9.125,9.125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.rf(["rgba(197,206,82,0.678)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.3).s().p("AlZFbQiQiQAAjLQAAjKCQiPQCPiQDKAAQDLAACQCQQCPCPAADKQAADLiPCQQiQCPjLAAQjKAAiPiPg");
	this.shape_53.setTransform(9.125,9.125);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.rf(["rgba(198,206,82,0.675)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,49.5).s().p("AlbFcQiQiQAAjMQAAjLCQiQQCQiQDLAAQDMAACQCQQCQCQAADLQAADMiQCQQiQCQjMAAQjLAAiQiQg");
	this.shape_54.setTransform(9.15,9.15);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.rf(["rgba(198,206,82,0.667)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.7).s().p("AlcFeQiRiRAAjNQAAjMCRiQQCQiRDMAAQDNAACRCRQCQCQAADMQAADNiQCRQiRCQjNAAQjMAAiQiQg");
	this.shape_55.setTransform(9.125,9.125);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.rf(["rgba(198,206,82,0.663)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.9).s().p("AleFfQiRiRAAjOQAAjNCRiRQCRiRDNAAQDOAACRCRQCRCRAADNQAADOiRCRQiRCRjOAAQjNAAiRiRg");
	this.shape_56.setTransform(9.125,9.125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.rf(["rgba(198,206,82,0.655)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.1).s().p("AlfFhQiSiSAAjPQAAjOCSiRQCRiSDOAAQDPAACSCSQCRCRAADOQAADPiRCSQiSCRjPAAQjOAAiRiRg");
	this.shape_57.setTransform(9.125,9.125);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.rf(["rgba(198,206,82,0.651)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,50.3).s().p("AlhFiQiTiTABjPQgBjPCTiSQCSiTDPABQDPgBCTCTQCTCSAADPQAADPiTCTQiTCTjPAAQjPAAiSiTg");
	this.shape_58.setTransform(9.15,9.15);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.rf(["rgba(198,206,82,0.643)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.5).s().p("AliFkQiUiUAAjQQAAjPCUiTQCTiUDPAAQDQAACUCUQCTCTAADPQAADQiTCUQiUCTjQAAQjPAAiTiTg");
	this.shape_59.setTransform(9.125,9.125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.rf(["rgba(198,206,82,0.635)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.8).s().p("AlkFlQiUiUAAjRQAAjQCUiUQCUiUDQAAQDRAACUCUQCUCUAADQQAADRiUCUQiUCUjRAAQjQAAiUiUg");
	this.shape_60.setTransform(9.125,9.125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.rf(["rgba(198,206,82,0.631)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.9).s().p("AllFnQiViVAAjSQAAjRCViUQCUiVDRAAQDSAACVCVQCUCUAADRQAADSiUCVQiVCUjSAAQjRAAiUiUg");
	this.shape_61.setTransform(9.125,9.125);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.rf(["rgba(198,206,82,0.624)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.2).s().p("AlnFoQiViVAAjTQAAjSCViVQCViVDSAAQDTAACVCVQCVCVAADSQAADTiVCVQiVCVjTAAQjSAAiViVg");
	this.shape_62.setTransform(9.15,9.15);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.rf(["rgba(198,206,82,0.62)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.4).s().p("AlpFpQiViVAAjUQAAjTCViWQCWiVDTAAQDUAACVCVQCWCWAADTQAADUiWCVQiVCWjUAAQjTAAiWiWg");
	this.shape_63.setTransform(9.15,9.15);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.rf(["rgba(198,206,82,0.612)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,51.6).s().p("AlqFrQiWiWAAjVQAAjUCWiWQCWiWDUAAQDVAACWCWQCWCWAADUQAADViWCWQiWCWjVAAQjUAAiWiWg");
	this.shape_64.setTransform(9.125,9.125);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.rf(["rgba(198,206,82,0.608)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,51.8).s().p("AlrFtQiXiXAAjWQAAjVCXiWQCWiXDVAAQDWAACXCXQCWCWAADVQAADWiWCXQiXCWjWAAQjVAAiWiWg");
	this.shape_65.setTransform(9.125,9.125);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.rf(["rgba(199,206,82,0.6)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52).s().p("AltFuQiXiXAAjXQAAjWCXiXQCXiXDWAAQDXAACXCXQCYCXAADWQAADXiYCXQiXCYjXAAQjWAAiXiYg");
	this.shape_66.setTransform(9.15,9.15);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.rf(["rgba(199,206,82,0.596)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.3).s().p("AlvFvQiYiXAAjYQAAjWCYiZQCZiYDWAAQDYAACXCYQCYCZABDWQgBDYiYCXQiXCYjYABQjWgBiZiYg");
	this.shape_67.setTransform(9.15,9.15);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.rf(["rgba(199,206,82,0.588)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,52.5).s().p("AlwFxQiZiZAAjYQAAjXCZiZQCZiZDXAAQDYAACZCZQCZCZAADXQAADYiZCZQiZCZjYAAQjXAAiZiZg");
	this.shape_68.setTransform(9.125,9.125);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.rf(["rgba(199,206,82,0.584)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,52.7).s().p("AlxFzQiaiaAAjZQAAjYCaiZQCZiaDYAAQDZAACaCaQCZCZAADYQAADZiZCaQiaCZjZAAQjYAAiZiZg");
	this.shape_69.setTransform(9.125,9.125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.rf(["rgba(199,206,82,0.576)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.9).s().p("AlzF0QiaiaAAjaQAAjZCaiaQCaiaDZAAQDaAACaCaQCaCaAADZQAADaiaCaQiaCajaAAQjZAAiaiag");
	this.shape_70.setTransform(9.15,9.15);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.rf(["rgba(199,206,82,0.573)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.1).s().p("Al0F2QibibAAjbQAAjaCbiaQCaibDaAAQDbAACbCbQCaCaAADaQAADbiaCbQibCajbAAQjaAAiaiag");
	this.shape_71.setTransform(9.15,9.15);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.rf(["rgba(199,206,82,0.565)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.3).s().p("Al2F3QibibAAjcQAAjbCbibQCbibDbAAQDcAACbCbQCbCbAADbQAADcibCbQibCbjcAAQjbAAibibg");
	this.shape_72.setTransform(9.15,9.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.rf(["rgba(199,206,82,0.557)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,53.5).s().p("Al3F5QicicAAjdQAAjcCcibQCbicDcAAQDdAACcCcQCbCbAADcQAADdibCcQicCbjdAAQjcAAibibg");
	this.shape_73.setTransform(9.125,9.125);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.rf(["rgba(199,206,82,0.553)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.7).s().p("Al5F6QididABjdQgBjdCdicQCcidDdABQDdgBCdCdQCcCcABDdQgBDdicCdQidCcjdABQjdgBicicg");
	this.shape_74.setTransform(9.15,9.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.rf(["rgba(199,206,82,0.545)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54).s().p("Al7F7QidicABjfQgBjdCdieQCeidDdABQDfgBCcCdQCeCeAADdQAADfieCcQicCejfAAQjdAAieieg");
	this.shape_75.setTransform(9.15,9.15);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.rf(["rgba(199,206,82,0.541)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.2).s().p("Al8F9QidiegBjfQABjfCdidQCdidDfgBQDfABCeCdQCeCdAADfQAADfieCeQieCejfAAQjfAAidieg");
	this.shape_76.setTransform(9.15,9.15);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.rf(["rgba(199,206,82,0.533)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,54.4).s().p("Al9F/QififAAjgQAAjfCfieQCeifDfAAQDgAACfCfQCeCeAADfQAADgieCfQifCejgAAQjfAAieieg");
	this.shape_77.setTransform(9.125,9.125);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.rf(["rgba(200,206,82,0.529)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.6).s().p("Al/GAQififAAjhQAAjgCfifQCfifDgAAQDhAACfCfQCfCfAADgQAADhifCfQifCfjhAAQjgAAififg");
	this.shape_78.setTransform(9.15,9.15);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.rf(["rgba(200,206,82,0.522)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.8).s().p("AmBGCQifigAAjiQAAjhCfigQCgifDhAAQDiAACgCfQCfCgAADhQAADiifCgQigCfjiAAQjhAAigifg");
	this.shape_79.setTransform(9.15,9.15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.rf(["rgba(200,206,82,0.518)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55).s().p("AmCGDQigigAAjjQAAjiCgigQCgigDiAAQDjAACgCgQCgCgAADiQAADjigCgQigCgjjAAQjiAAigigg");
	this.shape_80.setTransform(9.15,9.15);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.rf(["rgba(200,206,82,0.51)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,55.2).s().p("AmDGFQihihAAjkQAAjjChigQCgihDjAAQDkAAChChQCgCgAADjQAADkigChQihCgjkAAQjjAAigigg");
	this.shape_81.setTransform(9.125,9.125);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.rf(["rgba(200,206,82,0.506)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.5).s().p("AmFGGQiiihABjlQgBjkCiihQChiiDkABQDlgBChCiQChChAADkQAADlihChQihChjlAAQjkAAihihg");
	this.shape_82.setTransform(9.15,9.15);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.rf(["rgba(200,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_83.setTransform(9.15,9.15);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.rf(["rgba(199,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_84.setTransform(9.15,9.15);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.rf(["rgba(198,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_85.setTransform(9.15,9.15);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.rf(["rgba(197,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_86.setTransform(9.15,9.15);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.rf(["rgba(196,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_87.setTransform(9.15,9.15);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.rf(["rgba(195,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_88.setTransform(9.15,9.15);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.rf(["rgba(194,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_89.setTransform(9.15,9.15);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.rf(["rgba(193,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_90.setTransform(9.15,9.15);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.rf(["rgba(192,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_91.setTransform(9.15,9.15);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.rf(["rgba(191,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_92.setTransform(9.15,9.15);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.rf(["rgba(190,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_93.setTransform(9.15,9.15);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.rf(["rgba(189,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_94.setTransform(9.15,9.15);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.rf(["rgba(188,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_95.setTransform(9.15,9.15);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.rf(["rgba(187,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_96.setTransform(9.15,9.15);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.rf(["rgba(186,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_97.setTransform(9.15,9.15);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.rf(["rgba(185,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_98.setTransform(9.15,9.15);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.rf(["rgba(184,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_99.setTransform(9.15,9.15);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.rf(["rgba(183,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_100.setTransform(9.15,9.15);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.rf(["rgba(182,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_101.setTransform(9.15,9.15);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.rf(["rgba(181,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_102.setTransform(9.15,9.15);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.rf(["rgba(180,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_103.setTransform(9.15,9.15);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.rf(["rgba(179,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_104.setTransform(9.15,9.15);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.rf(["rgba(178,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_105.setTransform(9.15,9.15);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.rf(["rgba(177,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_106.setTransform(9.15,9.15);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.rf(["rgba(176,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_107.setTransform(9.15,9.15);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.rf(["rgba(175,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_108.setTransform(9.15,9.15);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.rf(["rgba(174,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_109.setTransform(9.15,9.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.rf(["rgba(173,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_110.setTransform(9.15,9.15);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.rf(["rgba(172,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_111.setTransform(9.15,9.15);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.rf(["rgba(171,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_112.setTransform(9.15,9.15);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.rf(["rgba(170,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_113.setTransform(9.15,9.15);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.rf(["rgba(169,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_114.setTransform(9.15,9.15);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.rf(["rgba(168,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_115.setTransform(9.15,9.15);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.rf(["rgba(167,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_116.setTransform(9.15,9.15);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.rf(["rgba(166,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_117.setTransform(9.15,9.15);
	this.shape_117._off = true;

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.rf(["rgba(169,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.4).s().p("Al3F4QicibAAjdQAAjcCcibQCbicDcAAQDdAACbCcQCcCbgBDcQABDdicCbQibCcjdgBQjcABibicg");
	this.shape_118.setTransform(9.15,9.15);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.rf(["rgba(171,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.2).s().p("AloFoQiUiVAAjTQAAjTCUiVQCViUDTAAQDTAACVCUQCVCVABDTQgBDTiVCVQiVCVjTABQjTgBiViVg");
	this.shape_119.setTransform(9.15,9.15);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.rf(["rgba(174,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,49).s().p("AlYFYQiOiOgBjKQABjJCOiPQCPiODJgBQDKABCOCOQCPCPAADJQAADKiPCOQiOCPjKAAQjJAAiPiPg");
	this.shape_120.setTransform(9.15,9.15);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.rf(["rgba(176,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,46.8).s().p("AlIFJQiJiIAAjBQAAjACJiIQCIiJDAAAQDBAACICJQCICIABDAQgBDBiICIQiICIjBABQjAgBiIiIg");
	this.shape_121.setTransform(9.15,9.15);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.rf(["rgba(179,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.6).s().p("Ak4E6QiDiCAAi4QAAi2CDiCQCCiDC2AAQC4AACCCDQCCCCAAC2QAAC4iCCCQiCCCi4AAQi2AAiCiCg");
	this.shape_122.setTransform(9.1,9.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.rf(["rgba(181,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.4).s().p("AkpErQh7h8AAivQAAiuB7h7QB7h7CuAAQCvAAB8B7QB6B7AACuQAACvh6B8Qh8B6ivAAQiuAAh7h6g");
	this.shape_123.setTransform(9.1,9.1);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.rf(["rgba(184,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.2).s().p("AkaEaQh0h1gBilQABikB0h2QB2h0CkgBQClABB1B0QB2B2gBCkQABClh2B1Qh1B2ilgBQikABh2h2g");
	this.shape_124.setTransform(9.1,9.1);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.rf(["rgba(186,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,37.9).s().p("AkKELQhuhuAAidQAAibBuhvQBvhuCbAAQCdAABuBuQBvBvAACbQAACdhvBuQhuBvidAAQibAAhvhvg");
	this.shape_125.setTransform(9.1,9.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_117).wait(135).to({_off:false},0).wait(62).to({_off:true},1).wait(8));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_3_Слой_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(25,131,127,0)").ss(2,1,1).p("AAABPIAAid");
	this.shape.setTransform(9.025,2.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(27,132,126,0.02)").ss(2,1,1).p("AAAA7IAAh1");
	this.shape_1.setTransform(9.025,0.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(30,133,125,0.039)").ss(2,1,1).p("AAAAmIAAhL");
	this.shape_2.setTransform(9.025,-1.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(32,134,124,0.059)").ss(2,1,1).p("AAAASIAAgj");
	this.shape_3.setTransform(9.025,-2.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(35,135,124,0.078)").ss(2,1,1).p("AAAgCIAAAF");
	this.shape_4.setTransform(9.025,-4.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(37,136,123,0.098)").ss(2,1,1).p("AAAgWIAAAt");
	this.shape_5.setTransform(9.025,-6.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(40,138,122,0.114)").ss(2,1,1).p("AAAgqIAABV");
	this.shape_6.setTransform(9.025,-8.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(42,139,121,0.133)").ss(2,1,1).p("AAAg/IAAB/");
	this.shape_7.setTransform(9.025,-9.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(45,140,120,0.153)").ss(2,1,1).p("AAAhTIAACn");
	this.shape_8.setTransform(9.025,-11.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(47,141,119,0.173)").ss(2,1,1).p("AAAhoIAADR");
	this.shape_9.setTransform(9.025,-13.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(50,142,118,0.192)").ss(2,1,1).p("AAAh8IAAD5");
	this.shape_10.setTransform(9.025,-15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(52,143,117,0.212)").ss(2,1,1).p("AAAiQIAAEh");
	this.shape_11.setTransform(9.025,-16.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(55,144,117,0.231)").ss(2,1,1).p("AAAilIAAFL");
	this.shape_12.setTransform(9.025,-18.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(57,145,116,0.251)").ss(2,1,1).p("AAAi5IAAFz");
	this.shape_13.setTransform(9.025,-20.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(59,146,115,0.271)").ss(2,1,1).p("AAAjNIAAGb");
	this.shape_14.setTransform(9.025,-21.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(62,147,114,0.29)").ss(2,1,1).p("AAAjiIAAHF");
	this.shape_15.setTransform(9.025,-23.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(64,149,113,0.306)").ss(2,1,1).p("AAAj2IAAHt");
	this.shape_16.setTransform(9.025,-25.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(67,150,112,0.325)").ss(2,1,1).p("AAAkLIAAIX");
	this.shape_17.setTransform(9.025,-27.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(69,151,111,0.345)").ss(2,1,1).p("AAAkfIAAI/");
	this.shape_18.setTransform(9.025,-28.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(72,152,111,0.365)").ss(2,1,1).p("AAAkzIAAJn");
	this.shape_19.setTransform(9.025,-30.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(74,153,110,0.384)").ss(2,1,1).p("AAAlIIAAKR");
	this.shape_20.setTransform(9.025,-32.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(77,154,109,0.404)").ss(2,1,1).p("AAAlcIAAK5");
	this.shape_21.setTransform(9.025,-34.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(79,155,108,0.424)").ss(2,1,1).p("AAAlwIAALh");
	this.shape_22.setTransform(9.025,-35.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(82,156,107,0.443)").ss(2,1,1).p("AAAmFIAAMK");
	this.shape_23.setTransform(9.025,-37.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(84,157,106,0.463)").ss(2,1,1).p("AAAmZIAAMz");
	this.shape_24.setTransform(9.025,-39.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(87,158,105,0.482)").ss(2,1,1).p("AAAmtIAANb");
	this.shape_25.setTransform(9.025,-41.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(89,160,105,0.502)").ss(2,1,1).p("AAAnCIAAOF");
	this.shape_26.setTransform(9.025,-42.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(91,161,104,0.518)").ss(2,1,1).p("AAAnWIAAOt");
	this.shape_27.setTransform(9,-44.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(94,162,103,0.537)").ss(2,1,1).p("AAAnrIAAPX");
	this.shape_28.setTransform(9,-46.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(96,163,102,0.557)").ss(2,1,1).p("AAAn/IAAP/");
	this.shape_29.setTransform(9,-47.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(99,164,101,0.576)").ss(2,1,1).p("AAAoTIAAQn");
	this.shape_30.setTransform(9,-49.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(101,165,100,0.596)").ss(2,1,1).p("AAAooIAARR");
	this.shape_31.setTransform(9,-51.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(104,166,99,0.616)").ss(2,1,1).p("AAAo8IAAR5");
	this.shape_32.setTransform(9,-53.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(106,167,98,0.635)").ss(2,1,1).p("AAApQIAASh");
	this.shape_33.setTransform(9,-54.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(109,168,98,0.655)").ss(2,1,1).p("AAAplIAATL");
	this.shape_34.setTransform(9,-56.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(111,169,97,0.675)").ss(2,1,1).p("AAAp5IAATz");
	this.shape_35.setTransform(9,-58.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(114,170,96,0.694)").ss(2,1,1).p("AAAqNIAAUb");
	this.shape_36.setTransform(9,-60.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(116,172,95,0.71)").ss(2,1,1).p("AAAqiIAAVF");
	this.shape_37.setTransform(9,-61.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(119,173,94,0.729)").ss(2,1,1).p("AAAq2IAAVt");
	this.shape_38.setTransform(9,-63.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(121,174,93,0.749)").ss(2,1,1).p("AAArKIAAWV");
	this.shape_39.setTransform(9,-65.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(123,175,92,0.769)").ss(2,1,1).p("AAArfIAAW/");
	this.shape_40.setTransform(9,-67);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(126,176,92,0.788)").ss(2,1,1).p("AAArzIAAXn");
	this.shape_41.setTransform(9,-68.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(128,177,91,0.808)").ss(2,1,1).p("AAAsHIAAYP");
	this.shape_42.setTransform(9,-70.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(131,178,90,0.827)").ss(2,1,1).p("AAAscIAAY5");
	this.shape_43.setTransform(9,-72.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(133,179,89,0.847)").ss(2,1,1).p("AAAswIAAZh");
	this.shape_44.setTransform(9,-73.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(136,180,88,0.867)").ss(2,1,1).p("AAAtFIAAaL");
	this.shape_45.setTransform(9,-75.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(138,181,87,0.886)").ss(2,1,1).p("AAAtZIAAaz");
	this.shape_46.setTransform(9,-77.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(141,183,86,0.902)").ss(2,1,1).p("AAAttIAAbb");
	this.shape_47.setTransform(9,-79.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("rgba(143,184,85,0.922)").ss(2,1,1).p("AAAuCIAAcF");
	this.shape_48.setTransform(9,-80.85);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("rgba(146,185,85,0.941)").ss(2,1,1).p("AAAuWIAAct");
	this.shape_49.setTransform(9,-82.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(148,186,84,0.961)").ss(2,1,1).p("AAAuqIAAdV");
	this.shape_50.setTransform(9,-84.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("rgba(151,187,83,0.98)").ss(2,1,1).p("AAAu/IAAd/");
	this.shape_51.setTransform(9,-86.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#99BC52").ss(2,1,1).p("AAAPUIAA+n");
	this.shape_52.setTransform(9,-87.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#99BC52").ss(2,1,1).p("AAAtfIAAa/");
	this.shape_53.setTransform(9,-76.175);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#99BC52").ss(2,1,1).p("AAArrIAAXX");
	this.shape_54.setTransform(9,-64.575);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#99BC52").ss(2,1,1).p("AAAp3IAATu");
	this.shape_55.setTransform(9,-52.95);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#99BC52").ss(2,1,1).p("AAAoDIAAQH");
	this.shape_56.setTransform(9,-41.35);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#99BC52").ss(2,1,1).p("AAAmOIAAMd");
	this.shape_57.setTransform(9,-29.725);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#99BC52").ss(2,1,1).p("AAAkaIAAI1");
	this.shape_58.setTransform(9,-18.125);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#99BC52").ss(2,1,1).p("AAAimIAAFN");
	this.shape_59.setTransform(9,-6.5);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#99BC52").ss(2,1,1).p("AAAAzIAAhl");
	this.shape_60.setTransform(9,5.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},123).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_52}]},22).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_3_Слой_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#99BC52").s().p("Ag/BAQgbgbAAglQAAglAbgaQAagbAlAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQglABgagbg");
	this.shape.setTransform(9.05,9.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#99BC52").s().p("Ag/BAQgbgbAAglQAAgkAbgbQAbgbAkAAQAlAAAbAbQAbAbAAAkQAAAlgbAbQgbAbglAAQgkAAgbgbg");
	this.shape_1.setTransform(9.05,9.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#99BC52").s().p("Ag/BAQgbgaAAgmQAAglAbgaQAagbAlAAQAmAAAaAbQAbAaAAAlQAAAmgbAaQgaAbgmAAQglAAgagbg");
	this.shape_2.setTransform(9.05,9.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#99BC52").s().p("AhABBQgbgbAAgmQAAglAbgbQAbgbAlAAQAmAAAbAbQAbAbAAAlQAAAmgbAbQgbAbgmAAQglAAgbgbg");
	this.shape_3.setTransform(9.05,9.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#99BC52").s().p("AhABBQgcgbAAgmQAAglAcgbQAbgcAlAAQAmAAAbAcQAcAbAAAlQAAAmgcAbQgbAcgmAAQglAAgbgcg");
	this.shape_4.setTransform(9.05,9.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#99BC52").s().p("AhBBCQgbgcAAgmQAAgmAbgbQAbgbAmAAQAmAAAcAbQAbAbAAAmQAAAmgbAcQgcAbgmAAQgmAAgbgbg");
	this.shape_5.setTransform(9.05,9.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#99BC52").s().p("AhBBCQgbgbAAgnQAAgmAbgbQAbgbAmAAQAnAAAbAbQAbAbAAAmQAAAngbAbQgbAbgnAAQgmAAgbgbg");
	this.shape_6.setTransform(9.05,9.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#99BC52").s().p("AhBBCQgcgbAAgnQAAgmAcgbQAbgcAmAAQAnAAAbAcQAcAbAAAmQAAAngcAbQgbAcgnAAQgmAAgbgcg");
	this.shape_7.setTransform(9.05,9.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#99BC52").s().p("AhCBDQgbgcAAgnQAAgmAbgcQAcgbAmAAQAnAAAcAbQAcAcAAAmQAAAngcAcQgcAcgnAAQgmAAgcgcg");
	this.shape_8.setTransform(9.05,9.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#99BC52").s().p("AhCBDQgcgcAAgnQAAgmAcgcQAcgcAmAAQAnAAAcAcQAcAcAAAmQAAAngcAcQgcAcgnAAQgmAAgcgcg");
	this.shape_9.setTransform(9.05,9.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#99BC52").s().p("AhCBEQgdgdAAgnQAAgmAdgcQAcgdAmAAQAnAAAdAdQAcAcAAAmQAAAngcAdQgdAcgnAAQgmAAgcgcg");
	this.shape_10.setTransform(9.05,9.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#99BC52").s().p("AhDBEQgcgdAAgnQAAgmAcgdQAdgcAmAAQAnAAAdAcQAcAdAAAmQAAAngcAdQgdAcgnAAQgmAAgdgcg");
	this.shape_11.setTransform(9.05,9.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#99BC52").s().p("AhDBEQgdgcAAgoQAAgnAdgcQAcgdAnAAQAoAAAcAdQAcAcABAnQgBAogcAcQgcAcgoABQgngBgcgcg");
	this.shape_12.setTransform(9.05,9.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#99BC52").s().p("AhEBFQgcgdAAgoQAAgnAcgdQAdgcAnAAQAoAAAdAcQAcAdAAAnQAAAogcAdQgdAcgoAAQgnAAgdgcg");
	this.shape_13.setTransform(9.05,9.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#99BC52").s().p("AhEBFQgcgcgBgpQABgnAcgdQAdgcAngBQApABAcAcQAcAdABAnQgBApgcAcQgcAcgpABQgngBgdgcg");
	this.shape_14.setTransform(9.05,9.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#99BC52").s().p("AhFBGQgcgdAAgpQAAgoAcgdQAdgcAoAAQApAAAdAcQAcAdAAAoQAAApgcAdQgdAcgpAAQgoAAgdgcg");
	this.shape_15.setTransform(9.05,9.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#99BC52").s().p("AhFBGQgdgdAAgpQAAgoAdgdQAdgdAoAAQApAAAdAdQAcAdAAAoQAAApgcAdQgdAcgpAAQgoAAgdgcg");
	this.shape_16.setTransform(9.05,9.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#99BC52").s().p("AhFBGQgdgdAAgpQAAgoAdgdQAdgdAoAAQApAAAdAdQAdAdAAAoQAAApgdAdQgdAdgpAAQgoAAgdgdg");
	this.shape_17.setTransform(9.05,9.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#99BC52").s().p("AhGBHQgdgeAAgpQAAgoAdgeQAegdAoAAQApAAAeAdQAcAeAAAoQAAApgcAeQgeAcgpAAQgoAAgegcg");
	this.shape_18.setTransform(9.05,9.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#99BC52").s().p("AhGBHQgdgdAAgqQAAgpAdgdQAdgdApAAQAqAAAdAdQAdAdAAApQAAAqgdAdQgdAdgqAAQgpAAgdgdg");
	this.shape_19.setTransform(9.05,9.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#99BC52").s().p("AhGBHQgegdABgqQgBgpAegdQAdgeApABQAqgBAdAeQAeAdgBApQABAqgeAdQgdAegqgBQgpABgdgeg");
	this.shape_20.setTransform(9.05,9.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#99BC52").s().p("AhHBHQgdgdAAgqQAAgpAdgeQAegdApAAQAqAAAdAdQAeAeAAApQAAAqgeAdQgdAegqAAQgpAAgegeg");
	this.shape_21.setTransform(9.05,9.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#99BC52").s().p("AhHBIQgegeAAgqQAAgpAegeQAegeApAAQAqAAAeAeQAeAeAAApQAAAqgeAeQgeAegqAAQgpAAgegeg");
	this.shape_22.setTransform(9.05,9.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#99BC52").s().p("AhHBIQgegeAAgqQAAgqAegdQAdgeAqAAQAqAAAeAeQAeAdAAAqQAAAqgeAeQgeAegqAAQgqAAgdgeg");
	this.shape_23.setTransform(9.05,9.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#99BC52").s().p("AhIBIQgdgdAAgrQAAgqAdgeQAegdAqAAQArAAAdAdQAeAeAAAqQAAArgeAdQgdAegrAAQgqAAgegeg");
	this.shape_24.setTransform(9.05,9.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#99BC52").s().p("AhIBJQgegfAAgqQAAgqAegeQAegeAqAAQAqAAAfAeQAeAeAAAqQAAAqgeAfQgfAegqAAQgqAAgegeg");
	this.shape_25.setTransform(9.05,9.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#99BC52").s().p("AhIBJQgegeAAgrQAAgqAegeQAegeAqAAQArAAAeAeQAfAeAAAqQAAArgfAeQgeAfgrAAQgqAAgegfg");
	this.shape_26.setTransform(9.05,9.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#99BC52").s().p("AhIBJQgfgeAAgrQAAgqAfgeQAegfAqAAQArAAAeAfQAfAeAAAqQAAArgfAeQgeAfgrAAQgqAAgegfg");
	this.shape_27.setTransform(9.05,9.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#99BC52").s().p("AhJBKQgfgeAAgsQAAgqAfgfQAfgfAqAAQAsAAAeAfQAfAfAAAqQAAAsgfAeQgeAfgsAAQgqAAgfgfg");
	this.shape_28.setTransform(9.05,9.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#99BC52").s().p("AhJBKQgggeAAgsQAAgrAggeQAeggArAAQAsAAAeAgQAgAeAAArQAAAsggAeQgeAggsAAQgrAAgeggg");
	this.shape_29.setTransform(9.05,9.05);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#99BC52").s().p("AhKBLQgfgfAAgsQAAgrAfgfQAfgfArAAQAsAAAfAfQAfAfAAArQAAAsgfAfQgfAfgsAAQgrAAgfgfg");
	this.shape_30.setTransform(9.05,9.05);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#99BC52").s().p("AhKBLQgfgfgBgsQABgrAfgfQAfgfArgBQAsABAfAfQAfAfABArQgBAsgfAfQgfAfgsABQgrgBgfgfg");
	this.shape_31.setTransform(9.05,9.05);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#99BC52").s().p("AhKBLQgggfAAgsQAAgrAggfQAfggArAAQAsAAAfAgQAgAfAAArQAAAsggAfQgfAggsAAQgrAAgfggg");
	this.shape_32.setTransform(9.05,9.05);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#99BC52").s().p("AhKBLQgggeAAgtQAAgsAggeQAeggAsAAQAtAAAeAgQAgAeAAAsQAAAtggAeQgeAggtAAQgsAAgeggg");
	this.shape_33.setTransform(9.05,9.05);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#99BC52").s().p("AhLBMQgfgfgBgtQABgsAfgfQAfgfAsgBQAtABAfAfQAfAfAAAsQAAAtgfAfQgfAfgtAAQgsAAgfgfg");
	this.shape_34.setTransform(9.05,9.05);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#99BC52").s().p("AhLBNQggggAAgtQAAgsAggfQAfggAsAAQAtAAAgAgQAfAfAAAsQAAAtgfAgQggAfgtAAQgsAAgfgfg");
	this.shape_35.setTransform(9.05,9.05);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#99BC52").s().p("AhLBNQghggAAgtQAAgsAhgfQAfghAsAAQAtAAAgAhQAfAfAAAsQAAAtgfAgQggAfgtAAQgsAAgfgfg");
	this.shape_36.setTransform(9.05,9.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#99BC52").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAtAAAgAgQAgAgAAAsQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_37.setTransform(9.05,9.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#99BC52").s().p("AhNBOQgfghAAgtQAAgsAfghQAhgfAsAAQAtAAAhAfQAfAhAAAsQAAAtgfAhQghAfgtAAQgsAAghgfg");
	this.shape_38.setTransform(9.05,9.05);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#99BC52").s().p("AhNBOQggghAAgtQAAgsAgghQAhggAsAAQAtAAAhAgQAgAhAAAsQAAAtggAhQghAggtAAQgsAAghggg");
	this.shape_39.setTransform(9.05,9.05);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#99BC52").s().p("AhNBOQghggABguQgBgtAhggQAgghAtABQAugBAgAhQAhAggBAtQABAughAgQggAhgugBQgtABggghg");
	this.shape_40.setTransform(9.05,9.05);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#99BC52").s().p("AhOBPQggghAAguQAAgtAgghQAhggAtAAQAuAAAhAgQAgAhAAAtQAAAuggAhQghAgguAAQgtAAghggg");
	this.shape_41.setTransform(9.05,9.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#99BC52").s().p("AhOBPQghggABgvQgBguAhggQAgghAuABQAvgBAgAhQAhAggBAuQABAvghAgQggAhgvgBQguABggghg");
	this.shape_42.setTransform(9.05,9.05);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#99BC52").s().p("AhOBPQghggAAgvQAAguAhggQAgghAuAAQAvAAAgAhQAhAgAAAuQAAAvghAgQggAhgvAAQguAAggghg");
	this.shape_43.setTransform(9.05,9.05);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#99BC52").s().p("AhPBQQgggiAAguQAAgtAggiQAiggAtAAQAuAAAiAgQAgAiABAtQgBAuggAiQgiAgguABQgtgBgiggg");
	this.shape_44.setTransform(9.05,9.05);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#99BC52").s().p("AhPBQQghghAAgvQAAguAhghQAhghAuAAQAvAAAhAhQAhAhAAAuQAAAvghAhQghAhgvAAQguAAghghg");
	this.shape_45.setTransform(9.05,9.05);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#99BC52").s().p("AhPBQQgighAAgvQAAguAighQAhgiAuAAQAvAAAhAiQAiAhAAAuQAAAvgiAhQghAigvAAQguAAghgig");
	this.shape_46.setTransform(9.05,9.05);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#99BC52").s().p("AhQBRQghgiAAgvQAAguAhgiQAighAuAAQAvAAAiAhQAhAiAAAuQAAAvghAiQgiAhgvAAQguAAgighg");
	this.shape_47.setTransform(9.05,9.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#99BC52").s().p("AhQBRQgigiAAgvQAAgvAighQAhgiAvAAQAvAAAiAiQAhAhABAvQgBAvghAiQgiAhgvABQgvgBghghg");
	this.shape_48.setTransform(9.05,9.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#99BC52").s().p("AhQBRQgigiAAgvQAAgvAighQAhgiAvAAQAvAAAiAiQAiAhAAAvQAAAvgiAiQgiAigvAAQgvAAghgig");
	this.shape_49.setTransform(9.05,9.05);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#99BC52").s().p("AhRBRQgighAAgwQAAgvAigiQAigiAvAAQAwAAAhAiQAjAiAAAvQAAAwgjAhQghAjgwAAQgvAAgigjg");
	this.shape_50.setTransform(9.05,9.05);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#99BC52").s().p("AhRBSQgigiAAgwQAAgvAigiQAigiAvAAQAwAAAiAiQAiAiAAAvQAAAwgiAiQgiAigwAAQgvAAgigig");
	this.shape_51.setTransform(9.05,9.05);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#99BC52").s().p("AhRBSQgjghAAgxQAAgwAjghQAhgjAwAAQAxAAAhAjQAjAhgBAwQABAxgjAhQghAjgxgBQgwABghgjg");
	this.shape_52.setTransform(9.05,9.05);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#99BC52").s().p("AhRBSQgjghAAgxQAAgwAjghQAhgjAwAAQAxAAAhAjQAjAhAAAwQAAAxgjAhQghAjgxAAQgwAAghgjg");
	this.shape_53.setTransform(9.05,9.05);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#99BC52").s().p("AhSBTQgigjgBgwQABgvAigjQAjgiAvgBQAwABAjAiQAiAjAAAvQAAAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_54.setTransform(9.05,9.05);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#99BC52").s().p("AhSBTQgjgiAAgxQAAgwAjgiQAigjAwAAQAxAAAiAjQAjAiAAAwQAAAxgjAiQgiAjgxAAQgwAAgigjg");
	this.shape_55.setTransform(9.05,9.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#99BC52").s().p("AhSBTQgkgiABgxQgBgwAkgiQAigkAwABQAxgBAiAkQAkAigBAwQABAxgkAiQgiAkgxgBQgwABgigkg");
	this.shape_56.setTransform(9.05,9.05);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#99BC52").s().p("AhTBUQgjgjAAgxQAAgwAjgjQAjgjAwAAQAxAAAjAjQAjAjAAAwQAAAxgjAjQgjAjgxAAQgwAAgjgjg");
	this.shape_57.setTransform(9.05,9.05);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#99BC52").s().p("AhTBUQgkgjABgxQgBgxAkgiQAigkAxABQAxgBAjAkQAjAiAAAxQAAAxgjAjQgjAjgxAAQgxAAgigjg");
	this.shape_58.setTransform(9.05,9.05);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#99BC52").s().p("AhTBUQgkgjAAgxQAAgxAkgiQAigkAxAAQAxAAAjAkQAkAiAAAxQAAAxgkAjQgjAkgxAAQgxAAgigkg");
	this.shape_59.setTransform(9.05,9.05);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#99BC52").s().p("AhUBVQgkgjABgyQgBgxAkgjQAjgkAxABQAygBAjAkQAkAjgBAxQABAygkAjQgjAkgygBQgxABgjgkg");
	this.shape_60.setTransform(9.05,9.05);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#99BC52").s().p("AhUBWQgkgkAAgyQAAgxAkgjQAjgkAxAAQAyAAAkAkQAjAjAAAxQAAAygjAkQgkAjgyAAQgxAAgjgjg");
	this.shape_61.setTransform(9.05,9.05);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#99BC52").s().p("AhVBWQgkgkABgyQgBgxAkgkQAkgkAxABQAygBAkAkQAkAkAAAxQAAAygkAkQgkAkgyAAQgxAAgkgkg");
	this.shape_62.setTransform(9.05,9.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#99BC52").s().p("AhVBWQgkgkAAgyQAAgxAkgkQAkgkAxAAQAyAAAkAkQAkAkAAAxQAAAygkAkQgkAkgyAAQgxAAgkgkg");
	this.shape_63.setTransform(9.05,9.05);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#99BC52").s().p("AhWBXQgjgkgBgzQABgyAjgkQAkgjAygBQAzABAkAjQAjAkABAyQgBAzgjAkQgkAjgzABQgygBgkgjg");
	this.shape_64.setTransform(9.05,9.05);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#99BC52").s().p("AhWBXQgkgkAAgzQAAgyAkgkQAkgkAyAAQAzAAAkAkQAkAkAAAyQAAAzgkAkQgkAkgzAAQgyAAgkgkg");
	this.shape_65.setTransform(9.05,9.05);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#99BC52").s().p("AhWBXQglgkAAgzQAAgyAlgkQAkglAyAAQAzAAAkAlQAlAkAAAyQAAAzglAkQgkAlgzAAQgyAAgkglg");
	this.shape_66.setTransform(9.05,9.05);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#99BC52").s().p("AhXBYQgkglAAgzQAAgyAkglQAlgkAyAAQAzAAAlAkQAkAlAAAyQAAAzgkAlQglAkgzAAQgyAAglgkg");
	this.shape_67.setTransform(9.05,9.05);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#99BC52").s().p("AhXBYQglglAAgzQAAgzAlgkQAkglAzAAQAzAAAlAlQAlAkAAAzQAAAzglAlQglAlgzAAQgzAAgkglg");
	this.shape_68.setTransform(9.05,9.05);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#99BC52").s().p("AhYBZQgkglAAg0QAAgzAkglQAlgkAzAAQA0AAAlAkQAkAlAAAzQAAA0gkAlQglAkg0AAQgzAAglgkg");
	this.shape_69.setTransform(9.05,9.05);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#99BC52").s().p("AhYBZQglglAAg0QAAgzAlglQAlglAzAAQA0AAAlAlQAlAlAAAzQAAA0glAlQglAlg0AAQgzAAglglg");
	this.shape_70.setTransform(9.05,9.05);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#99BC52").s().p("AhYBZQglglAAg0QAAg0AlgkQAkglA0AAQA0AAAlAlQAlAkAAA0QAAA0glAlQglAlg0AAQg0AAgkglg");
	this.shape_71.setTransform(9.05,9.05);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#99BC52").s().p("AhZBaQglgmAAg0QAAgzAlgmQAmglAzAAQA0AAAmAlQAlAmgBAzQABA0glAmQgmAlg0gBQgzABgmglg");
	this.shape_72.setTransform(9.05,9.05);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#99BC52").s().p("AhZBaQglgmAAg0QAAgzAlgmQAmglAzAAQA0AAAmAlQAlAmAAAzQAAA0glAmQgmAlg0AAQgzAAgmglg");
	this.shape_73.setTransform(9.05,9.05);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#99BC52").s().p("AhZBaQglglAAg1QAAg0AlglQAlglA0AAQA1AAAlAlQAlAlAAA0QAAA1glAlQglAlg1AAQg0AAglglg");
	this.shape_74.setTransform(9.05,9.05);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#99BC52").s().p("AhaBaQglglAAg1QAAg0AlgmQAmglA0AAQA1AAAlAlQAmAmAAA0QAAA1gmAlQglAmg1AAQg0AAgmgmg");
	this.shape_75.setTransform(9.05,9.05);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#99BC52").s().p("AhZBaQgnglABg1QgBg0AnglQAlgnA0ABQA1gBAlAnQAmAlAAA0QAAA1gmAlQglAmg1AAQg0AAglgmg");
	this.shape_76.setTransform(9.05,9.05);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#99BC52").s().p("AhaBbQgmglAAg2QAAg0AmgmQAmgmA0AAQA2AAAlAmQAmAmAAA0QAAA2gmAlQglAmg2AAQg0AAgmgmg");
	this.shape_77.setTransform(9.05,9.05);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#99BC52").s().p("AhaBbQgnglAAg2QAAg1AnglQAlgnA1AAQA2AAAlAnQAnAlAAA1QAAA2gnAlQglAng2AAQg1AAglgng");
	this.shape_78.setTransform(9.05,9.05);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#99BC52").s().p("AhbBcQgmgmAAg2QAAg1AmgmQAmgmA1AAQA2AAAmAmQAmAmAAA1QAAA2gmAmQgmAmg2AAQg1AAgmgmg");
	this.shape_79.setTransform(9.05,9.05);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#99BC52").s().p("AhbBcQgngmABg2QgBg1AngmQAmgnA1ABQA2gBAmAnQAnAmAAA1QAAA2gnAmQgmAng2AAQg1AAgmgng");
	this.shape_80.setTransform(9.05,9.05);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#99BC52").s().p("AhbBcQgnglAAg3QAAg1AngmQAmgnA1AAQA3AAAlAnQAnAmAAA1QAAA3gnAlQglAng3AAQg1AAgmgng");
	this.shape_81.setTransform(9.05,9.05);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#99BC52").s().p("AhcBdQgngmAAg3QAAg1AngnQAngnA1AAQA3AAAmAnQAnAnAAA1QAAA3gnAmQgmAng3AAQg1AAgngng");
	this.shape_82.setTransform(9.05,9.05);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#99BC52").s().p("AhcBdQgogmAAg3QAAg2AogmQAmgoA2AAQA3AAAmAoQAnAmABA2QgBA3gnAmQgmAng3ABQg2gBgmgng");
	this.shape_83.setTransform(9.05,9.05);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#99BC52").s().p("AhdBeQgngnAAg3QAAg2AngnQAngnA2AAQA3AAAnAnQAnAnAAA2QAAA3gnAnQgnAng3AAQg2AAgngng");
	this.shape_84.setTransform(9.05,9.05);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#99BC52").s().p("AhdBeQgogmAAg4QAAg3AogmQAmgoA3AAQA4AAAmAoQAoAmAAA3QAAA4goAmQgmAog4AAQg3AAgmgog");
	this.shape_85.setTransform(9.05,9.05);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#99BC52").s().p("AhdBfQgognAAg4QAAg3AogmQAmgoA3AAQA4AAAnAoQAnAmAAA3QAAA4gnAnQgnAng4AAQg3AAgmgng");
	this.shape_86.setTransform(9.05,9.05);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#99BC52").s().p("AheBfQgognAAg4QAAg3AognQAngoA3AAQA4AAAnAoQAoAnAAA3QAAA4goAnQgnAog4AAQg3AAgngog");
	this.shape_87.setTransform(9.05,9.05);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#99BC52").s().p("AhfBgQgngoAAg4QAAg3AngoQAognA3AAQA4AAAoAnQAnAoAAA3QAAA4gnAoQgoAng4AAQg3AAgogng");
	this.shape_88.setTransform(9.05,9.05);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#99BC52").s().p("AhfBgQgogoAAg4QAAg3AogoQAogoA3AAQA4AAAoAoQAoAogBA3QABA4goAoQgoAog4gBQg3ABgogog");
	this.shape_89.setTransform(9.05,9.05);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#99BC52").s().p("AhfBgQgogoAAg4QAAg4AognQAngoA4AAQA4AAAoAoQAoAnAAA4QAAA4goAoQgoAog4AAQg4AAgngog");
	this.shape_90.setTransform(9.05,9.05);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#99BC52").s().p("AhgBhQgogoABg5QgBg4AogoQAogoA4ABQA5gBAoAoQAoAogBA4QABA5goAoQgoAog5gBQg4ABgogog");
	this.shape_91.setTransform(9.05,9.05);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#99BC52").s().p("AhgBhQgogoAAg5QAAg4AogoQAogoA4AAQA5AAAoAoQAoAoAAA4QAAA5goAoQgoAog5AAQg4AAgogog");
	this.shape_92.setTransform(9.05,9.05);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#99BC52").s().p("AhhBiQgogpAAg5QAAg4AogpQApgoA4AAQA5AAApAoQAoApAAA4QAAA5goApQgpAog5AAQg4AAgpgog");
	this.shape_93.setTransform(9.05,9.05);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#99BC52").s().p("AhhBiQgogoAAg6QAAg5AogoQAogoA5AAQA6AAAoAoQAoAoAAA5QAAA6goAoQgoAog6AAQg5AAgogog");
	this.shape_94.setTransform(9.05,9.05);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#99BC52").s().p("AhhBiQgpgpAAg5QAAg5ApgoQAogpA5AAQA5AAApApQApAoAAA5QAAA5gpApQgpApg5AAQg5AAgogpg");
	this.shape_95.setTransform(9.05,9.05);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#99BC52").s().p("AhiBiQgogoAAg6QAAg5AogpQApgoA5AAQA6AAAoAoQAqApAAA5QAAA6gqAoQgoAqg6AAQg5AAgpgqg");
	this.shape_96.setTransform(9.05,9.05);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#99BC52").s().p("AhiBjQgpgpAAg6QAAg5ApgpQApgpA5AAQA6AAApApQApApAAA5QAAA6gpApQgpApg6AAQg5AAgpgpg");
	this.shape_97.setTransform(9.05,9.05);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#99BC52").s().p("AhiBjQgqgoAAg7QAAg6AqgoQAogqA6AAQA7AAAoAqQAqAoAAA6QAAA7gqAoQgoAqg7AAQg6AAgogqg");
	this.shape_98.setTransform(9.05,9.05);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#99BC52").s().p("AhjBjQgpgpAAg6QAAg6ApgpQApgpA6AAQA6AAApApQAqApAAA6QAAA6gqApQgpAqg6AAQg6AAgpgqg");
	this.shape_99.setTransform(9.05,9.05);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#99BC52").s().p("AhjBkQgqgpAAg7QAAg5AqgqQAqgqA5AAQA7AAApAqQAqAqAAA5QAAA7gqApQgpAqg7AAQg5AAgqgqg");
	this.shape_100.setTransform(9.05,9.05);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#99BC52").s().p("AhjBkQgqgpAAg7QAAg6AqgpQApgqA6AAQA7AAApAqQAqApAAA6QAAA7gqApQgpAqg7AAQg6AAgpgqg");
	this.shape_101.setTransform(9.05,9.05);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#99BC52").s().p("AhjBkQgqgpgBg7QABg6AqgpQApgqA6gBQA7ABApAqQAqApABA6QgBA7gqApQgpAqg7ABQg6gBgpgqg");
	this.shape_102.setTransform(9.05,9.05);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#99BC52").s().p("AhkBlQgqgqAAg7QAAg6AqgqQAqgqA6AAQA7AAAqAqQAqAqAAA6QAAA7gqAqQgqAqg7AAQg6AAgqgqg");
	this.shape_103.setTransform(9.05,9.05);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#99BC52").s().p("AhkBlQgrgpAAg8QAAg7ArgpQApgrA7AAQA8AAApArQArApgBA7QABA8grApQgpArg8gBQg7ABgpgrg");
	this.shape_104.setTransform(9.05,9.05);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#99BC52").s().p("AhkBlQgqgqgBg7QABg7AqgpQApgqA7gBQA7ABAqAqQAqApAAA7QAAA7gqAqQgqAqg7AAQg7AAgpgqg");
	this.shape_105.setTransform(9.05,9.05);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#99BC52").s().p("AhkBlQgrgpAAg8QAAg7ArgpQApgrA7AAQA8AAApArQArApAAA7QAAA8grApQgpArg8AAQg7AAgpgrg");
	this.shape_106.setTransform(9.05,9.05);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#99BC52").s().p("AhlBmQgrgqAAg8QAAg7ArgqQAqgrA7AAQA8AAAqArQAqAqAAA7QAAA8gqAqQgqAqg8AAQg7AAgqgqg");
	this.shape_107.setTransform(9.05,9.05);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#99BC52").s().p("AhlBmQgrgqAAg8QAAg7ArgqQAqgrA7AAQA8AAAqArQArAqAAA7QAAA8grAqQgqArg8AAQg7AAgqgrg");
	this.shape_108.setTransform(9.05,9.05);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#99BC52").s().p("AhlBmQgsgqABg8QgBg8AsgpQApgsA8ABQA8gBAqAsQAsApgBA8QABA8gsAqQgqAsg8gBQg8ABgpgsg");
	this.shape_109.setTransform(9.05,9.05);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#99BC52").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_110.setTransform(9.05,9.05);
	this.shape_110._off = true;

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#90BE5F").s().p("AhhBiQgpgpAAg5QAAg5ApgoQAogpA5AAQA5AAApApQApAoAAA5QAAA5gpApQgpApg5AAQg5AAgogpg");
	this.shape_111.setTransform(9.05,9.05);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#87C16B").s().p("AhcBdQgngmAAg3QAAg1AngnQAngnA1AAQA3AAAmAnQAnAnAAA1QAAA3gnAmQgmAng3AAQg1AAgngng");
	this.shape_112.setTransform(9.05,9.05);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#7EC378").s().p("AhYBZQgkglAAg0QAAgzAkglQAlgkAzAAQA0AAAlAkQAkAlAAAzQAAA0gkAlQglAkg0AAQgzAAglgkg");
	this.shape_113.setTransform(9.05,9.05);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#76C584").s().p("AhTBTQgigiAAgxQAAgwAigjQAjgiAwAAQAxAAAiAiQAjAjAAAwQAAAxgjAiQgiAjgxAAQgwAAgjgjg");
	this.shape_114.setTransform(9.075,9.075);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#6DC791").s().p("AhOBPQggghAAguQAAgtAgghQAhggAtAAQAuAAAhAgQAgAhAAAtQAAAuggAhQghAgguAAQgtAAghggg");
	this.shape_115.setTransform(9.05,9.05);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#64CA9D").s().p("AhIBKQgfgegBgsQABgqAfgeQAegfAqgBQAsABAeAfQAfAeAAAqQAAAsgfAeQgeAfgsAAQgqAAgegfg");
	this.shape_116.setTransform(9.05,9.05);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#5BCCAA").s().p("AhEBFQgcgcgBgpQABgnAcgdQAdgcAngBQApABAcAcQAcAdABAnQgBApgcAcQgcAcgpABQgngBgdgcg");
	this.shape_117.setTransform(9.05,9.05);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#52CEB6").s().p("Ag/BAQgbgbAAglQAAglAbgaQAagbAlAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQglABgagbg");
	this.shape_118.setTransform(9.05,9.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_110).wait(123).to({_off:false},0).wait(74).to({_off:true},1).wait(8));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_3_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["#81CE52","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,37.9).s().p("AkKELQhuhuAAidQAAibBuhvQBvhuCbAAQCdAABuBuQBvBvAACbQAACdhvBuQhuBvidAAQibAAhvhvg");
	this.shape.setTransform(9.1,9.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(129,206,82,0.996)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.1).s().p("AkLEMQhvhvAAidQAAicBvhvQBvhvCcAAQCdAABvBvQBvBvAACcQAACdhvBvQhvBvidAAQicAAhvhvg");
	this.shape_1.setTransform(9.1,9.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(129,206,82,0.992)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.3).s().p("AkMENQhwhvAAieQAAidBwhvQBvhwCdAAQCeAABvBwQBvBvABCdQgBCehvBvQhvBvieABQidgBhvhvg");
	this.shape_2.setTransform(9.1,9.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(129,206,82,0.988)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.4).s().p("AkNEOQhwhvAAifQAAieBwhvQBvhwCeAAQCfAABvBwQBwBvAACeQAACfhwBvQhvBwifAAQieAAhvhwg");
	this.shape_3.setTransform(9.1,9.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(129,206,82,0.984)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.6).s().p("AkOEPQhwhwAAifQAAieBwhwQBwhwCeAAQCfAABwBwQBwBwAACeQAACfhwBwQhwBwifAAQieAAhwhwg");
	this.shape_4.setTransform(9.1,9.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(129,206,82,0.98)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.7).s().p("AkPEQQhwhwAAigQAAifBwhwQBwhwCfAAQCgAABwBwQBxBwgBCfQABCghxBwQhwBxiggBQifABhwhxg");
	this.shape_5.setTransform(9.1,9.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(129,206,82,0.976)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.8).s().p("AkQERQhxhxAAigQAAifBxhxQBxhxCfAAQCgAABxBxQBxBxAACfQAACghxBxQhxBxigAAQifAAhxhxg");
	this.shape_6.setTransform(9.1,9.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(129,206,82,0.973)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.9).s().p("AkRESQhyhyABigQgBigByhxQBxhyCgABQCggBByByQByBxAACgQAACghyByQhyByigAAQigAAhxhyg");
	this.shape_7.setTransform(9.1,9.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(129,206,82,0.969)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.1).s().p("AkSETQhyhyAAihQAAigByhyQByhyCgAAQChAAByByQByByAACgQAAChhyByQhyByihAAQigAAhyhyg");
	this.shape_8.setTransform(9.1,9.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(129,206,82,0.965)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.3).s().p("AkTEUQhyhygBiiQABihByhyQByhyChgBQCiABByByQByByAAChQAACihyByQhyByiiAAQihAAhyhyg");
	this.shape_9.setTransform(9.1,9.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(129,206,82,0.961)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.4).s().p("AkUEVQhzhzAAiiQAAihBzhzQBzhzChAAQCiAABzBzQBzBzAAChQAACihzBzQhzBziiAAQihAAhzhzg");
	this.shape_10.setTransform(9.1,9.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(129,206,82,0.957)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.6).s().p("AkVEWQhzhzAAijQAAiiBzhzQBzhzCiAAQCjAABzBzQBzBzAACiQAACjhzBzQhzBzijAAQiiAAhzhzg");
	this.shape_11.setTransform(9.125,9.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(129,206,82,0.953)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.7).s().p("AkWEXQhzhzAAikQAAiiBzh0QB0hzCiAAQCkAABzBzQB0B0gBCiQABCkh0BzQhzB0ikgBQiiABh0h0g");
	this.shape_12.setTransform(9.1,9.1);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(129,206,82,0.945)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.8).s().p("AkXEYQh0hzAAilQAAijB0h0QB0h0CjAAQClAABzB0QB0B0AACjQAAClh0BzQhzB0ilAAQijAAh0h0g");
	this.shape_13.setTransform(9.1,9.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(129,206,82,0.941)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.9).s().p("AkYEZQh1h0AAilQAAikB1h0QB0h1CkAAQClAAB0B1QB1B0AACkQAAClh1B0Qh0B1ilAAQikAAh0h1g");
	this.shape_14.setTransform(9.1,9.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(129,206,82,0.937)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.1).s().p("AkZEaQh1h0AAimQAAilB1h0QB0h1ClAAQCmAAB0B1QB1B0AAClQAACmh1B0Qh0B1imAAQilAAh0h1g");
	this.shape_15.setTransform(9.1,9.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["rgba(128,206,82,0.933)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.3).s().p("AkaEbQh2h1AAimQAAilB2h1QB1h2ClAAQCmAAB1B2QB2B1gBClQABCmh2B1Qh1B2imgBQilABh1h2g");
	this.shape_16.setTransform(9.1,9.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["rgba(128,206,82,0.929)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.4).s().p("AkbEcQh2h2AAimQAAimB2h1QB1h2CmAAQCmAAB2B2QB2B1AACmQAACmh2B2Qh2B2imAAQimAAh1h2g");
	this.shape_17.setTransform(9.1,9.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["rgba(128,206,82,0.925)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.6).s().p("AkcEdQh2h2AAinQAAimB2h2QB2h2CmAAQCnAAB2B2QB2B2AACmQAACnh2B2Qh2B2inAAQimAAh2h2g");
	this.shape_18.setTransform(9.125,9.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["rgba(128,206,82,0.922)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.7).s().p("AkdEeQh3h2AAioQAAinB3h2QB2h3CnAAQCoAAB2B3QB3B2AACnQAACoh3B2Qh2B3ioAAQinAAh2h3g");
	this.shape_19.setTransform(9.125,9.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["rgba(128,206,82,0.918)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.8).s().p("AkeEgQh3h3AAipQAAinB3h3QB3h3CnAAQCpAAB3B3QB2B3AACnQAACph2B3Qh3B2ipAAQinAAh3h2g");
	this.shape_20.setTransform(9.1,9.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["rgba(128,206,82,0.914)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41).s().p("AkfEhQh4h4AAipQAAioB4h3QB3h4CoAAQCpAAB4B4QB2B3ABCoQgBCph2B4Qh4B2ipABQiogBh3h2g");
	this.shape_21.setTransform(9.1,9.1);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["rgba(128,206,82,0.91)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.1).s().p("AkgEiQh4h4AAiqQAAioB4h4QB4h4CoAAQCqAAB4B4QB3B4AACoQAACqh3B4Qh4B3iqAAQioAAh4h3g");
	this.shape_22.setTransform(9.1,9.1);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["rgba(128,206,82,0.906)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.3).s().p("AkhEjQh5h5AAiqQAAipB5h4QB4h5CpAAQCqAAB5B5QB4B4gBCpQABCqh4B5Qh5B4iqgBQipABh4h4g");
	this.shape_23.setTransform(9.1,9.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["rgba(128,206,82,0.902)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.4).s().p("AkiEjQh5h4AAirQAAiqB5h4QB4h5CqAAQCrAAB4B5QB5B4AACqQAACrh5B4Qh4B5irAAQiqAAh4h5g");
	this.shape_24.setTransform(9.125,9.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["rgba(128,206,82,0.898)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.6).s().p("AkjEkQh5h5AAirQAAiqB5h5QB5h5CqAAQCrAAB5B5QB5B5AACqQAACrh5B5Qh5B5irAAQiqAAh5h5g");
	this.shape_25.setTransform(9.125,9.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["rgba(128,206,82,0.894)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.7).s().p("AkkElQh6h5AAisQAAirB6h5QB5h6CrAAQCsAAB5B6QB6B5AACrQAACsh6B5Qh5B6isAAQirAAh5h6g");
	this.shape_26.setTransform(9.125,9.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["rgba(128,206,82,0.89)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.8).s().p("AklEmQh6h6AAisQAAisB6h5QB5h6CsAAQCsAAB6B6QB6B5AACsQAACsh6B6Qh6B6isAAQisAAh5h6g");
	this.shape_27.setTransform(9.1,9.1);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.rf(["rgba(128,206,82,0.886)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42).s().p("AkmEnQh7h6AAitQAAisB7h6QB6h7CsAAQCtAAB6B7QB6B6AACsQAACth6B6Qh6B6itAAQisAAh6h6g");
	this.shape_28.setTransform(9.1,9.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["rgba(128,206,82,0.882)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.1).s().p("AknEpQh7h7AAiuQAAitB7h6QB6h7CtAAQCuAAB7B7QB6B6AACtQAACuh6B7Qh7B6iuAAQitAAh6h6g");
	this.shape_29.setTransform(9.1,9.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.rf(["rgba(128,206,82,0.878)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.3).s().p("AkoEqQh7h7AAivQAAitB7h7QB7h7CtAAQCvAAB7B7QB6B7AACtQAACvh6B7Qh7B6ivAAQitAAh7h6g");
	this.shape_30.setTransform(9.1,9.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["rgba(128,206,82,0.875)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.4).s().p("AkqEqQh7h7AAivQAAiuB7h8QB8h7CuAAQCvAAB7B7QB8B8AACuQAACvh8B7Qh7B8ivAAQiuAAh8h8g");
	this.shape_31.setTransform(9.125,9.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.rf(["rgba(128,206,82,0.871)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.6).s().p("AkrErQh7h8AAivQAAivB7h8QB8h7CvAAQCvAAB8B7QB8B8AACvQAACvh8B8Qh8B8ivAAQivAAh8h8g");
	this.shape_32.setTransform(9.125,9.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["rgba(128,206,82,0.867)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.7).s().p("AksEsQh8h8AAiwQAAivB8h9QB9h8CvAAQCwAAB8B8QB9B9AACvQAACwh9B8Qh8B9iwAAQivAAh9h9g");
	this.shape_33.setTransform(9.125,9.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.rf(["rgba(128,206,82,0.863)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.8).s().p("AktEtQh8h8AAixQAAiwB8h9QB9h8CwAAQCxAAB8B8QB9B9AACwQAACxh9B8Qh8B9ixAAQiwAAh9h9g");
	this.shape_34.setTransform(9.125,9.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.rf(["rgba(128,206,82,0.859)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43).s().p("AkuEuQh8h9gBixQABiwB8h+QB+h8CwgBQCxABB9B8QB9B+AACwQAACxh9B9Qh9B9ixAAQiwAAh+h9g");
	this.shape_35.setTransform(9.1,9.1);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.rf(["rgba(128,206,82,0.855)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.1).s().p("AkuEvQh+h9AAiyQAAixB+h9QB9h+CxAAQCyAAB9B+QB+B9AACxQAACyh+B9Qh9B+iyAAQixAAh9h+g");
	this.shape_36.setTransform(9.1,9.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.rf(["rgba(128,206,82,0.847)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.3).s().p("AkvEwQh/h+ABiyQgBiyB/h9QB9h/CyABQCygBB+B/QB/B9gBCyQABCyh/B+Qh+B/iygBQiyABh9h/g");
	this.shape_37.setTransform(9.1,9.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.rf(["rgba(128,206,82,0.843)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.4).s().p("AkxExQh+h+AAizQAAiyB+h/QB/h+CyAAQCzAAB+B+QB/B/AACyQAACzh/B+Qh+B/izAAQiyAAh/h/g");
	this.shape_38.setTransform(9.125,9.125);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.rf(["rgba(128,206,82,0.839)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.6).s().p("AkyEyQh+h+AAi0QAAizB+h/QB/h+CzAAQC0AAB+B+QB/B/AACzQAAC0h/B+Qh+B/i0AAQizAAh/h/g");
	this.shape_39.setTransform(9.125,9.125);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.rf(["rgba(128,206,82,0.835)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.7).s().p("AkzEzQh/h/AAi0QAAizB/iAQCAh/CzAAQC0AAB/B/QCACAAACzQAAC0iAB/Qh/CAi0AAQizAAiAiAg");
	this.shape_40.setTransform(9.125,9.125);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.rf(["rgba(128,206,82,0.831)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.8).s().p("Ak0E0Qh/h/AAi1QAAi0B/iAQCAh/C0AAQC1AAB/B/QCACAAAC0QAAC1iAB/Qh/CAi1AAQi0AAiAiAg");
	this.shape_41.setTransform(9.125,9.125);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.rf(["rgba(128,206,82,0.827)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44).s().p("Ak1E1QiAiAAAi1QAAi1CAiAQCAiAC1AAQC1AACACAQCBCAAAC1QAAC1iBCAQiACBi1AAQi1AAiAiBg");
	this.shape_42.setTransform(9.125,9.125);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.rf(["rgba(128,206,82,0.824)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.2).s().p("Ak2E2QiAiAAAi2QAAi1CAiBQCBiAC1AAQC2AACACAQCBCBAAC1QAAC2iBCAQiACBi2AAQi1AAiBiBg");
	this.shape_43.setTransform(9.1,9.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.rf(["rgba(128,206,82,0.82)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.3).s().p("Ak3E3QiBiAABi3QgBi1CBiCQCCiBC1ABQC3gBCACBQCCCCAAC1QAAC3iCCAQiACCi3AAQi1AAiCiCg");
	this.shape_44.setTransform(9.1,9.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.rf(["rgba(128,206,82,0.816)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.4).s().p("Ak4E4QiBiBAAi3QAAi2CBiCQCCiBC2AAQC3AACBCBQCCCCAAC2QAAC3iCCBQiBCCi3AAQi2AAiCiCg");
	this.shape_45.setTransform(9.125,9.125);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.rf(["rgba(128,206,82,0.812)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.6).s().p("Ak5E5QiBiBAAi4QAAi3CBiCQCCiBC3AAQC4AACBCBQCCCCAAC3QAAC4iCCBQiBCCi4AAQi3AAiCiCg");
	this.shape_46.setTransform(9.125,9.125);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.rf(["rgba(127,206,82,0.808)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.7).s().p("Ak6E7QiCiDAAi4QAAi3CCiDQCDiCC3AAQC4AACDCCQCCCDAAC3QAAC4iCCDQiDCCi4AAQi3AAiDiCg");
	this.shape_47.setTransform(9.125,9.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.rf(["rgba(127,206,82,0.804)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.8).s().p("Ak7E8QiCiDAAi5QAAi4CCiDQCDiCC4AAQC5AACDCCQCCCDAAC4QAAC5iCCDQiDCCi5AAQi4AAiDiCg");
	this.shape_48.setTransform(9.125,9.125);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.rf(["rgba(127,206,82,0.8)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45).s().p("Ak8E9QiDiDAAi6QAAi5CDiDQCDiDC5AAQC6AACDCDQCDCDAAC5QAAC6iDCDQiDCDi6AAQi5AAiDiDg");
	this.shape_49.setTransform(9.125,9.125);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.rf(["rgba(127,206,82,0.796)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.2).s().p("Ak9E+QiDiDAAi7QAAi5CDiEQCEiDC5AAQC7AACDCDQCDCEAAC5QAAC7iDCDQiDCDi7AAQi5AAiEiDg");
	this.shape_50.setTransform(9.1,9.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.rf(["rgba(127,206,82,0.792)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.3).s().p("Ak+E/QiEiEABi7QgBi6CEiEQCEiEC6ABQC7gBCECEQCDCEABC6QgBC7iDCEQiECDi7ABQi6gBiEiDg");
	this.shape_51.setTransform(9.1,9.1);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.rf(["rgba(127,206,82,0.788)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.4).s().p("Ak/FAQiEiFAAi7QAAi6CEiFQCFiEC6AAQC7AACFCEQCECFAAC6QAAC7iECFQiFCEi7AAQi6AAiFiEg");
	this.shape_52.setTransform(9.125,9.125);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.rf(["rgba(127,206,82,0.784)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.6).s().p("AlAFBQiEiFAAi8QAAi7CEiFQCFiEC7AAQC8AACFCEQCECFAAC7QAAC8iECFQiFCEi8AAQi7AAiFiEg");
	this.shape_53.setTransform(9.125,9.125);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.rf(["rgba(127,206,82,0.78)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.7).s().p("AlBFCQiFiFAAi9QAAi8CFiFQCFiFC8AAQC9AACFCFQCFCFAAC8QAAC9iFCFQiFCFi9AAQi8AAiFiFg");
	this.shape_54.setTransform(9.125,9.125);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.rf(["rgba(127,206,82,0.776)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.8).s().p("AlCFDQiFiGAAi9QAAi8CFiGQCGiFC8AAQC9AACGCFQCFCGAAC8QAAC9iFCGQiGCFi9AAQi8AAiGiFg");
	this.shape_55.setTransform(9.125,9.125);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.rf(["rgba(127,206,82,0.773)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46).s().p("AlDFEQiGiGAAi+QAAi9CGiGQCGiGC9AAQC+AACGCGQCGCGAAC9QAAC+iGCGQiGCGi+AAQi9AAiGiGg");
	this.shape_56.setTransform(9.125,9.125);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.rf(["rgba(127,206,82,0.769)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.2).s().p("AlEFFQiGiHAAi+QAAi9CGiHQCHiGC9AAQC+AACHCGQCGCHAAC9QAAC+iGCHQiHCGi+AAQi9AAiHiGg");
	this.shape_57.setTransform(9.125,9.125);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.rf(["rgba(127,206,82,0.765)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.3).s().p("AlFFGQiHiHAAi/QAAi+CHiHQCHiHC+AAQC/AACHCHQCGCHABC+QgBC/iGCHQiHCGi/ABQi+gBiHiGg");
	this.shape_58.setTransform(9.1,9.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.rf(["rgba(127,206,82,0.761)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.4).s().p("AlGFHQiHiHAAjAQAAi/CHiHQCHiHC/AAQDAAACHCHQCHCHAAC/QAADAiHCHQiHCHjAAAQi/AAiHiHg");
	this.shape_59.setTransform(9.125,9.125);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.rf(["rgba(127,206,82,0.757)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.6).s().p("AlHFIQiHiIAAjAQAAi/CHiIQCIiHC/AAQDAAACICHQCHCIAAC/QAADAiHCIQiICHjAAAQi/AAiIiHg");
	this.shape_60.setTransform(9.125,9.125);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.rf(["rgba(127,206,82,0.753)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.8).s().p("AlIFJQiIiIAAjBQAAjACIiIQCIiIDAAAQDBAACICIQCICIAADAQAADBiICIQiICIjBAAQjAAAiIiIg");
	this.shape_61.setTransform(9.125,9.125);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.rf(["rgba(127,206,82,0.745)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.8).s().p("AlJFKQiIiJAAjBQAAjACIiJQCJiIDAAAQDBAACJCIQCICJAADAQAADBiICJQiJCIjBAAQjAAAiJiIg");
	this.shape_62.setTransform(9.125,9.125);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.rf(["rgba(127,206,82,0.741)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47).s().p("AlKFLQiJiJAAjCQAAjBCJiJQCJiJDBAAQDCAACJCJQCJCJAADBQAADCiJCJQiJCJjCAAQjBAAiJiJg");
	this.shape_63.setTransform(9.125,9.125);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.rf(["rgba(127,206,82,0.737)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.2).s().p("AlLFMQiJiKAAjCQAAjBCJiKQCKiJDBAAQDCAACKCJQCJCKAADBQAADCiJCKQiKCJjCAAQjBAAiKiJg");
	this.shape_64.setTransform(9.125,9.125);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.rf(["rgba(127,206,82,0.733)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,47.3).s().p("AlMFMQiKiJABjDQgBjDCKiJQCJiKDDABQDDgBCJCKQCKCJAADDQAADDiKCJQiJCKjDAAQjDAAiJiKg");
	this.shape_65.setTransform(9.15,9.15);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.rf(["rgba(127,206,82,0.729)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.4).s().p("AlNFOQiKiKAAjEQAAjDCKiKQCKiKDDAAQDEAACKCKQCKCKAADDQAADEiKCKQiKCKjEAAQjDAAiKiKg");
	this.shape_66.setTransform(9.125,9.125);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.rf(["rgba(127,206,82,0.725)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.6).s().p("AlOFPQiKiLAAjEQAAjDCKiLQCLiKDDAAQDEAACLCKQCKCLAADDQAADEiKCLQiLCKjEAAQjDAAiLiKg");
	this.shape_67.setTransform(9.125,9.125);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.rf(["rgba(127,206,82,0.722)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.8).s().p("AlPFQQiLiLAAjFQAAjECLiLQCLiLDEAAQDFAACLCLQCLCLAADEQAADFiLCLQiLCLjFAAQjEAAiLiLg");
	this.shape_68.setTransform(9.125,9.125);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.rf(["rgba(127,206,82,0.718)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.8).s().p("AlQFRQiLiMAAjFQAAjECLiMQCMiLDEAAQDFAACMCLQCLCMAADEQAADFiLCMQiMCLjFAAQjEAAiMiLg");
	this.shape_69.setTransform(9.125,9.125);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.rf(["rgba(127,206,82,0.714)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48).s().p("AlRFSQiMiMAAjGQAAjFCMiMQCMiMDFAAQDGAACMCMQCMCMAADFQAADGiMCMQiMCMjGAAQjFAAiMiMg");
	this.shape_70.setTransform(9.125,9.125);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.rf(["rgba(127,206,82,0.71)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.2).s().p("AlSFTQiMiMAAjHQAAjGCMiMQCMiMDGAAQDHAACMCMQCMCMAADGQAADHiMCMQiMCMjHAAQjGAAiMiMg");
	this.shape_71.setTransform(9.125,9.125);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.rf(["rgba(127,206,82,0.706)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,48.3).s().p("AlTFUQiNiNABjHQgBjHCNiMQCMiNDHABQDHgBCNCNQCMCMABDHQgBDHiMCNQiNCMjHABQjHgBiMiMg");
	this.shape_72.setTransform(9.15,9.15);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.rf(["rgba(127,206,82,0.702)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,48.5).s().p("AlUFVQiNiOAAjHQAAjHCNiNQCNiNDHAAQDHAACOCNQCNCNAADHQAADHiNCOQiOCNjHAAQjHAAiNiNg");
	this.shape_73.setTransform(9.15,9.15);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.rf(["rgba(127,206,82,0.698)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.6).s().p("AlVFWQiNiOAAjIQAAjHCNiOQCOiNDHAAQDIAACOCNQCNCOAADHQAADIiNCOQiOCNjIAAQjHAAiOiNg");
	this.shape_74.setTransform(9.125,9.125);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.rf(["rgba(127,206,82,0.694)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.8).s().p("AlWFXQiOiOAAjJQAAjICOiOQCOiODIAAQDJAACOCOQCOCOAADIQAADJiOCOQiOCOjJAAQjIAAiOiOg");
	this.shape_75.setTransform(9.125,9.125);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.rf(["rgba(127,206,82,0.69)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.8).s().p("AlXFYQiOiOAAjKQAAjJCOiOQCOiODJAAQDKAACOCOQCOCOAADJQAADKiOCOQiOCOjKAAQjJAAiOiOg");
	this.shape_76.setTransform(9.125,9.125);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.rf(["rgba(126,206,82,0.686)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.1).s().p("AlYFZQiPiPAAjKQAAjJCPiPQCPiPDJAAQDKAACPCPQCPCPAADJQAADKiPCPQiPCPjKAAQjJAAiPiPg");
	this.shape_77.setTransform(9.125,9.125);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.rf(["rgba(126,206,82,0.682)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.2).s().p("AlZFaQiPiPAAjLQAAjKCPiPQCPiPDKAAQDLAACPCPQCPCPAADKQAADLiPCPQiPCPjLAAQjKAAiPiPg");
	this.shape_78.setTransform(9.125,9.125);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.rf(["rgba(126,206,82,0.678)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,49.3).s().p("AlaFbQiQiQABjLQgBjKCQiQQCQiQDKABQDLgBCQCQQCQCQAADKQAADLiQCQQiQCQjLAAQjKAAiQiQg");
	this.shape_79.setTransform(9.15,9.15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.rf(["rgba(126,206,82,0.675)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,49.5).s().p("AlbFcQiQiQAAjMQAAjLCQiQQCQiQDLAAQDMAACQCQQCQCQAADLQAADMiQCQQiQCQjMAAQjLAAiQiQg");
	this.shape_80.setTransform(9.15,9.15);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.rf(["rgba(126,206,82,0.671)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.6).s().p("AlcFdQiQiQAAjNQAAjLCQiRQCRiQDLAAQDNAACQCQQCQCRAADLQAADNiQCQQiQCQjNAAQjLAAiRiQg");
	this.shape_81.setTransform(9.125,9.125);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.rf(["rgba(126,206,82,0.667)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.8).s().p("AldFeQiRiRAAjNQAAjMCRiRQCRiRDMAAQDNAACRCRQCRCRAADMQAADNiRCRQiRCRjNAAQjMAAiRiRg");
	this.shape_82.setTransform(9.125,9.125);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.rf(["rgba(126,206,82,0.663)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.9).s().p("AleFfQiRiRAAjOQAAjNCRiRQCRiRDNAAQDOAACRCRQCRCRAADNQAADOiRCRQiRCRjOAAQjNAAiRiRg");
	this.shape_83.setTransform(9.125,9.125);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.rf(["rgba(126,206,82,0.659)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.1).s().p("AlfFgQiSiSAAjOQAAjNCSiSQCSiSDNAAQDOAACSCSQCSCSAADNQAADOiSCSQiSCSjOAAQjNAAiSiSg");
	this.shape_84.setTransform(9.125,9.125);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.rf(["rgba(126,206,82,0.655)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.2).s().p("AlgFhQiSiSAAjPQAAjOCSiSQCSiSDOAAQDPAACSCSQCSCSAADOQAADPiSCSQiSCSjPAAQjOAAiSiSg");
	this.shape_85.setTransform(9.125,9.125);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.rf(["rgba(126,206,82,0.651)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,50.3).s().p("AlhFiQiTiTABjPQgBjPCTiSQCSiTDPABQDPgBCTCTQCTCSAADPQAADPiTCTQiTCTjPAAQjPAAiSiTg");
	this.shape_86.setTransform(9.15,9.15);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.rf(["rgba(126,206,82,0.643)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,50.5).s().p("AliFjQiTiTAAjQQAAjQCTiSQCSiTDQAAQDQAACTCTQCTCSAADQQAADQiTCTQiTCTjQAAQjQAAiSiTg");
	this.shape_87.setTransform(9.15,9.15);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.rf(["rgba(126,206,82,0.639)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,50.6).s().p("AljFkQiUiUAAjQQAAjQCUiTQCTiUDQAAQDQAACUCUQCTCTAADQQAADQiTCUQiUCTjQAAQjQAAiTiTg");
	this.shape_88.setTransform(9.15,9.15);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.rf(["rgba(126,206,82,0.635)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.8).s().p("AlkFlQiUiUAAjRQAAjQCUiUQCUiUDQAAQDRAACUCUQCUCUAADQQAADRiUCUQiUCUjRAAQjQAAiUiUg");
	this.shape_89.setTransform(9.125,9.125);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.rf(["rgba(126,206,82,0.631)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.9).s().p("AllFmQiUiUAAjSQAAjRCUiUQCUiUDRAAQDSAACUCUQCUCUAADRQAADSiUCUQiUCUjSAAQjRAAiUiUg");
	this.shape_90.setTransform(9.125,9.125);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.rf(["rgba(126,206,82,0.627)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,51.1).s().p("AlmFnQiViUAAjTQAAjRCViVQCViVDRAAQDTAACUCVQCVCVAADRQAADTiVCUQiUCVjTAAQjRAAiViVg");
	this.shape_91.setTransform(9.125,9.125);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.rf(["rgba(126,206,82,0.624)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,51.2).s().p("AlnFoQiViVAAjTQAAjSCViVQCViVDSAAQDTAACVCVQCVCVAADSQAADTiVCVQiVCVjTAAQjSAAiViVg");
	this.shape_92.setTransform(9.125,9.125);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.rf(["rgba(126,206,82,0.62)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.4).s().p("AlpFpQiViWAAjTQAAjTCViWQCWiVDTAAQDTAACWCVQCWCWAADTQAADTiWCWQiWCWjTAAQjTAAiWiWg");
	this.shape_93.setTransform(9.15,9.15);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.rf(["rgba(126,206,82,0.616)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.5).s().p("AlpFqQiWiWAAjUQAAjUCWiVQCViWDUAAQDUAACWCWQCWCVAADUQAADUiWCWQiWCWjUAAQjUAAiViWg");
	this.shape_94.setTransform(9.15,9.15);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.rf(["rgba(126,206,82,0.612)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.6).s().p("AlqFrQiWiWgBjVQABjUCWiWQCWiWDUgBQDVABCWCWQCWCWAADUQAADViWCWQiWCWjVAAQjUAAiWiWg");
	this.shape_95.setTransform(9.15,9.15);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.rf(["rgba(126,206,82,0.608)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.8).s().p("AlrFsQiXiXAAjVQAAjUCXiXQCXiXDUAAQDVAACXCXQCXCXAADUQAADViXCXQiXCXjVAAQjUAAiXiXg");
	this.shape_96.setTransform(9.15,9.15);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.rf(["rgba(126,206,82,0.604)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,51.9).s().p("AlsFtQiXiXAAjWQAAjVCXiXQCXiXDVAAQDWAACXCXQCXCXAADVQAADWiXCXQiXCXjWAAQjVAAiXiXg");
	this.shape_97.setTransform(9.125,9.125);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.rf(["rgba(126,206,82,0.6)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,52.1).s().p("AltFuQiYiXAAjXQAAjWCYiXQCXiYDWAAQDXAACXCYQCYCXAADWQAADXiYCXQiXCYjXAAQjWAAiXiYg");
	this.shape_98.setTransform(9.125,9.125);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.rf(["rgba(126,206,82,0.596)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,52.2).s().p("AluFvQiYiYAAjXQAAjWCYiYQCYiYDWAAQDXAACYCYQCYCYAADWQAADXiYCYQiYCYjXAAQjWAAiYiYg");
	this.shape_99.setTransform(9.125,9.125);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.rf(["rgba(126,206,82,0.592)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.3).s().p("AlwFwQiYiYAAjYQAAjXCYiZQCZiYDXAAQDYAACYCYQCYCZABDXQgBDYiYCYQiYCYjYABQjXgBiZiYg");
	this.shape_100.setTransform(9.15,9.15);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.rf(["rgba(126,206,82,0.588)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.5).s().p("AlxFxQiYiZAAjYQAAjYCYiZQCZiYDYAAQDYAACZCYQCZCZAADYQAADYiZCZQiZCZjYAAQjYAAiZiZg");
	this.shape_101.setTransform(9.15,9.15);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.rf(["rgba(126,206,82,0.584)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.6).s().p("AlyFyQiYiZgBjZQABjYCYiaQCaiYDYgBQDZABCZCYQCZCaAADYQAADZiZCZQiZCZjZAAQjYAAiaiZg");
	this.shape_102.setTransform(9.15,9.15);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.rf(["rgba(126,206,82,0.58)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.8).s().p("AlyFzQiaiZAAjaQAAjZCaiZQCZiaDZAAQDaAACZCaQCaCZAADZQAADaiaCZQiZCajaAAQjZAAiZiag");
	this.shape_103.setTransform(9.15,9.15);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.rf(["rgba(126,206,82,0.576)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,52.9).s().p("AlzF0QiaiaAAjaQAAjZCaiaQCaiaDZAAQDaAACaCaQCaCaAADZQAADaiaCaQiaCajaAAQjZAAiaiag");
	this.shape_104.setTransform(9.125,9.125);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.rf(["rgba(126,206,82,0.573)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,53.1).s().p("Al0F1QibiaAAjbQAAjaCbiaQCaibDaAAQDbAACaCbQCbCaAADaQAADbibCaQiaCbjbAAQjaAAiaibg");
	this.shape_105.setTransform(9.125,9.125);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.rf(["rgba(126,206,82,0.569)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.2).s().p("Al1F2QibiaAAjcQAAjbCbiaQCaibDbAAQDcAACaCbQCbCaAADbQAADcibCaQiaCbjcAAQjbAAiaibg");
	this.shape_106.setTransform(9.15,9.15);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.rf(["rgba(126,206,82,0.565)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.4).s().p("Al3F3QiaibgBjcQABjbCaicQCciaDbgBQDcABCbCaQCcCcgBDbQABDcicCbQibCcjcgBQjbABicicg");
	this.shape_107.setTransform(9.15,9.15);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.rf(["rgba(125,206,82,0.561)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.5).s().p("Al4F4QibicAAjcQAAjcCbicQCcibDcAAQDcAACcCbQCcCcAADcQAADcicCcQicCcjcAAQjcAAicicg");
	this.shape_108.setTransform(9.15,9.15);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.rf(["rgba(125,206,82,0.557)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.6).s().p("Al5F5QibicAAjdQAAjcCbidQCdibDcAAQDdAACcCbQCdCdgBDcQABDdidCcQicCdjdgBQjcABididg");
	this.shape_109.setTransform(9.15,9.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.rf(["rgba(125,206,82,0.553)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.8).s().p("Al6F6QicicAAjeQAAjdCcidQCdicDdAAQDeAACcCcQCdCdAADdQAADeidCcQicCdjeAAQjdAAididg");
	this.shape_110.setTransform(9.15,9.15);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.rf(["rgba(125,206,82,0.545)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.9).s().p("Al7F7QidicABjfQgBjdCdieQCeidDdABQDfgBCcCdQCeCeAADdQAADfieCcQicCejfAAQjdAAieieg");
	this.shape_111.setTransform(9.15,9.15);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.rf(["rgba(125,206,82,0.541)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,54.1).s().p("Al7F9QieieAAjfQAAjeCeidQCdieDeAAQDfAACeCeQCdCdAADeQAADfidCeQieCdjfAAQjeAAididg");
	this.shape_112.setTransform(9.125,9.125);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.rf(["rgba(125,206,82,0.537)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.2).s().p("Al8F+QieifAAjfQAAjfCeidQCdieDfAAQDfAACfCeQCdCdAADfQAADfidCfQifCdjfAAQjfAAididg");
	this.shape_113.setTransform(9.15,9.15);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.rf(["rgba(125,206,82,0.533)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.4).s().p("Al9F/QififAAjgQAAjfCfieQCeifDfAAQDgAACfCfQCdCeAADfQAADgidCfQifCdjgAAQjfAAieidg");
	this.shape_114.setTransform(9.15,9.15);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.rf(["rgba(125,206,82,0.529)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.5).s().p("Al+GAQifigAAjgQAAjgCfieQCeifDgAAQDgAACgCfQCeCeAADgQAADgieCgQigCejgAAQjgAAieieg");
	this.shape_115.setTransform(9.15,9.15);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.rf(["rgba(125,206,82,0.525)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.6).s().p("AmAGBQieigAAjhQAAjhCeifQCfieDhAAQDhAACgCeQCfCfAADhQAADhifCgQigCfjhAAQjhAAififg");
	this.shape_116.setTransform(9.15,9.15);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.rf(["rgba(125,206,82,0.522)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.8).s().p("AmBGCQifigAAjiQAAjhCfigQCgifDhAAQDiAACgCfQCfCgAADhQAADiifCgQigCfjiAAQjhAAigifg");
	this.shape_117.setTransform(9.15,9.15);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.rf(["rgba(125,206,82,0.518)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.9).s().p("AmCGCQigigAAjiQAAjiCgigQCgigDiAAQDiAACgCgQChCgAADiQAADiihCgQigChjiAAQjiAAigihg");
	this.shape_118.setTransform(9.15,9.15);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.rf(["rgba(125,206,82,0.514)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.1).s().p("AmDGDQigigAAjjQAAjiCgihQChigDiAAQDjAACgCgQChChAADiQAADjihCgQigChjjAAQjiAAihihg");
	this.shape_119.setTransform(9.15,9.15);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.rf(["rgba(125,206,82,0.51)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.2).s().p("AmEGEQigigAAjkQAAjiCgiiQCiigDiAAQDkAACgCgQChCiAADiQAADkihCgQigChjkAAQjiAAiiihg");
	this.shape_120.setTransform(9.15,9.15);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.rf(["rgba(125,206,82,0.506)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.4).s().p("AmEGFQiiigAAjlQAAjjCiihQChiiDjAAQDlAACgCiQChChAADjQAADlihCgQigChjlAAQjjAAihihg");
	this.shape_121.setTransform(9.15,9.15);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.rf(["rgba(125,206,82,0.502)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.5).s().p("AmFGHQiiiiAAjlQAAjkCiihQChiiDkAAQDlAACiCiQChChAADkQAADlihCiQiiChjlAAQjkAAihihg");
	this.shape_122.setTransform(9.15,9.15);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.rf(["rgba(125,206,82,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_123.setTransform(9.15,9.15);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.rf(["rgba(124,206,84,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_124.setTransform(9.15,9.15);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.rf(["rgba(123,206,86,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_125.setTransform(9.15,9.15);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.rf(["rgba(123,206,88,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_126.setTransform(9.15,9.15);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.rf(["rgba(122,206,90,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_127.setTransform(9.15,9.15);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.rf(["rgba(121,206,92,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_128.setTransform(9.15,9.15);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.rf(["rgba(120,206,94,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_129.setTransform(9.15,9.15);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.rf(["rgba(119,206,95,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_130.setTransform(9.15,9.15);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.rf(["rgba(118,206,97,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_131.setTransform(9.15,9.15);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.rf(["rgba(118,206,99,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_132.setTransform(9.15,9.15);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.rf(["rgba(117,206,101,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_133.setTransform(9.15,9.15);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.rf(["rgba(116,206,103,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_134.setTransform(9.15,9.15);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.rf(["rgba(115,206,105,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_135.setTransform(9.15,9.15);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.rf(["rgba(114,206,107,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_136.setTransform(9.15,9.15);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.rf(["rgba(113,206,109,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_137.setTransform(9.15,9.15);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.rf(["rgba(113,206,111,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_138.setTransform(9.15,9.15);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.rf(["rgba(112,206,113,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_139.setTransform(9.15,9.15);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.rf(["rgba(111,206,115,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_140.setTransform(9.15,9.15);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.rf(["rgba(110,206,117,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_141.setTransform(9.15,9.15);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.rf(["rgba(109,206,119,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_142.setTransform(9.15,9.15);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.rf(["rgba(108,206,120,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_143.setTransform(9.15,9.15);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.rf(["rgba(108,206,122,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_144.setTransform(9.15,9.15);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.rf(["rgba(107,206,124,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_145.setTransform(9.15,9.15);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.rf(["rgba(106,206,126,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_146.setTransform(9.15,9.15);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.rf(["rgba(105,206,128,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_147.setTransform(9.15,9.15);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.rf(["rgba(104,206,130,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_148.setTransform(9.15,9.15);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.rf(["rgba(104,206,132,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_149.setTransform(9.15,9.15);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.rf(["rgba(103,206,134,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_150.setTransform(9.15,9.15);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.rf(["rgba(102,206,136,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_151.setTransform(9.15,9.15);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.rf(["rgba(101,206,138,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_152.setTransform(9.15,9.15);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.rf(["rgba(100,206,140,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_153.setTransform(9.15,9.15);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.rf(["rgba(99,206,142,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_154.setTransform(9.15,9.15);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.rf(["rgba(99,206,144,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_155.setTransform(9.15,9.15);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.rf(["rgba(98,206,145,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_156.setTransform(9.15,9.15);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.rf(["rgba(97,206,147,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_157.setTransform(9.15,9.15);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.rf(["rgba(96,206,149,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_158.setTransform(9.15,9.15);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.rf(["rgba(95,206,151,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_159.setTransform(9.15,9.15);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.rf(["rgba(94,206,153,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_160.setTransform(9.15,9.15);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.rf(["rgba(94,206,155,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_161.setTransform(9.15,9.15);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.rf(["rgba(93,206,157,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_162.setTransform(9.15,9.15);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.rf(["rgba(92,206,159,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_163.setTransform(9.15,9.15);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.rf(["rgba(91,206,161,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_164.setTransform(9.15,9.15);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.rf(["rgba(90,206,163,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_165.setTransform(9.15,9.15);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.rf(["rgba(89,206,165,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_166.setTransform(9.15,9.15);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.rf(["rgba(89,206,167,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_167.setTransform(9.15,9.15);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.rf(["rgba(88,206,169,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_168.setTransform(9.15,9.15);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.rf(["rgba(87,206,170,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_169.setTransform(9.15,9.15);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.rf(["rgba(86,206,172,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_170.setTransform(9.15,9.15);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.rf(["rgba(85,206,174,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_171.setTransform(9.15,9.15);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.rf(["rgba(84,206,176,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_172.setTransform(9.15,9.15);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.rf(["rgba(84,206,178,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_173.setTransform(9.15,9.15);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.rf(["rgba(83,206,180,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_174.setTransform(9.15,9.15);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_175.setTransform(9.15,9.15);
	this.shape_175._off = true;

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,53.4).s().p("Al3F4QicibAAjdQAAjcCcibQCbicDcAAQDdAACbCcQCcCbgBDcQABDdicCbQibCcjdgBQjcABibicg");
	this.shape_176.setTransform(9.15,9.15);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.2).s().p("AloFoQiUiVAAjTQAAjTCUiVQCViUDTAAQDTAACVCUQCVCVABDTQgBDTiVCVQiVCVjTABQjTgBiViVg");
	this.shape_177.setTransform(9.15,9.15);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,49).s().p("AlYFYQiOiOgBjKQABjJCOiPQCPiODJgBQDKABCOCOQCPCPAADJQAADKiPCOQiOCPjKAAQjJAAiPiPg");
	this.shape_178.setTransform(9.15,9.15);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,46.8).s().p("AlIFJQiJiIAAjBQAAjACJiIQCIiJDAAAQDBAACICJQCICIABDAQgBDBiICIQiICIjBABQjAgBiIiIg");
	this.shape_179.setTransform(9.15,9.15);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.6).s().p("Ak4E6QiDiCAAi4QAAi2CDiCQCCiDC2AAQC4AACCCDQCCCCAAC2QAAC4iCCCQiCCCi4AAQi2AAiCiCg");
	this.shape_180.setTransform(9.1,9.1);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.4).s().p("AkpErQh7h8AAivQAAiuB7h7QB7h7CuAAQCvAAB8B7QB6B7AACuQAACvh6B8Qh8B6ivAAQiuAAh7h6g");
	this.shape_181.setTransform(9.1,9.1);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.2).s().p("AkaEaQh0h1gBilQABikB0h2QB2h0CkgBQClABB1B0QB2B2gBCkQABClh2B1Qh1B2ilgBQikABh2h2g");
	this.shape_182.setTransform(9.1,9.1);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,37.9).s().p("AkKELQhuhuAAidQAAibBuhvQBvhuCbAAQCdAABuBuQBvBvAACbQAACdhvBuQhuBvidAAQibAAhvhvg");
	this.shape_183.setTransform(9.1,9.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_175).wait(175).to({_off:false},0).wait(22).to({_off:true},1).wait(8));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2_Слой_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("rgba(25,131,127,0)").ss(2,1,1).p("AAABPIAAid");
	this.shape.setTransform(9.025,2.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("rgba(26,132,128,0.02)").ss(2,1,1).p("AAAA7IAAh1");
	this.shape_1.setTransform(9.025,0.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("rgba(27,134,129,0.039)").ss(2,1,1).p("AAAAmIAAhL");
	this.shape_2.setTransform(9.025,-1.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("rgba(28,135,130,0.059)").ss(2,1,1).p("AAAASIAAgj");
	this.shape_3.setTransform(9.025,-2.875);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("rgba(29,137,131,0.078)").ss(2,1,1).p("AAAgCIAAAF");
	this.shape_4.setTransform(9.025,-4.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("rgba(30,138,132,0.098)").ss(2,1,1).p("AAAgWIAAAt");
	this.shape_5.setTransform(9.025,-6.35);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("rgba(32,140,133,0.114)").ss(2,1,1).p("AAAgqIAABV");
	this.shape_6.setTransform(9.025,-8.075);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("rgba(33,141,134,0.133)").ss(2,1,1).p("AAAg/IAAB/");
	this.shape_7.setTransform(9.025,-9.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("rgba(34,143,135,0.153)").ss(2,1,1).p("AAAhTIAACn");
	this.shape_8.setTransform(9.025,-11.55);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("rgba(35,144,137,0.173)").ss(2,1,1).p("AAAhoIAADR");
	this.shape_9.setTransform(9.025,-13.25);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("rgba(36,145,138,0.192)").ss(2,1,1).p("AAAh8IAAD5");
	this.shape_10.setTransform(9.025,-15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("rgba(37,147,139,0.212)").ss(2,1,1).p("AAAiQIAAEh");
	this.shape_11.setTransform(9.025,-16.725);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("rgba(38,148,140,0.231)").ss(2,1,1).p("AAAilIAAFL");
	this.shape_12.setTransform(9.025,-18.475);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("rgba(39,150,141,0.251)").ss(2,1,1).p("AAAi5IAAFz");
	this.shape_13.setTransform(9.025,-20.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("rgba(40,151,142,0.271)").ss(2,1,1).p("AAAjNIAAGb");
	this.shape_14.setTransform(9.025,-21.925);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("rgba(41,153,143,0.29)").ss(2,1,1).p("AAAjiIAAHF");
	this.shape_15.setTransform(9.025,-23.675);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("rgba(43,154,144,0.306)").ss(2,1,1).p("AAAj2IAAHt");
	this.shape_16.setTransform(9.025,-25.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("rgba(44,156,145,0.325)").ss(2,1,1).p("AAAkLIAAIX");
	this.shape_17.setTransform(9.025,-27.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("rgba(45,157,146,0.345)").ss(2,1,1).p("AAAkfIAAI/");
	this.shape_18.setTransform(9.025,-28.875);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("rgba(46,158,147,0.365)").ss(2,1,1).p("AAAkzIAAJn");
	this.shape_19.setTransform(9.025,-30.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("rgba(47,160,148,0.384)").ss(2,1,1).p("AAAlIIAAKR");
	this.shape_20.setTransform(9.025,-32.35);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("rgba(48,161,149,0.404)").ss(2,1,1).p("AAAlcIAAK5");
	this.shape_21.setTransform(9.025,-34.075);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("rgba(49,163,150,0.424)").ss(2,1,1).p("AAAlwIAALh");
	this.shape_22.setTransform(9.025,-35.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("rgba(50,164,151,0.443)").ss(2,1,1).p("AAAmFIAAMK");
	this.shape_23.setTransform(9.025,-37.55);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("rgba(51,166,152,0.463)").ss(2,1,1).p("AAAmZIAAMz");
	this.shape_24.setTransform(9.025,-39.275);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("rgba(52,167,153,0.482)").ss(2,1,1).p("AAAmtIAANb");
	this.shape_25.setTransform(9.025,-41.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("rgba(54,169,155,0.502)").ss(2,1,1).p("AAAnCIAAOF");
	this.shape_26.setTransform(9.025,-42.725);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("rgba(55,170,156,0.518)").ss(2,1,1).p("AAAnWIAAOt");
	this.shape_27.setTransform(9,-44.45);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("rgba(56,171,157,0.537)").ss(2,1,1).p("AAAnrIAAPX");
	this.shape_28.setTransform(9,-46.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("rgba(57,173,158,0.557)").ss(2,1,1).p("AAAn/IAAP/");
	this.shape_29.setTransform(9,-47.925);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("rgba(58,174,159,0.576)").ss(2,1,1).p("AAAoTIAAQn");
	this.shape_30.setTransform(9,-49.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("rgba(59,176,160,0.596)").ss(2,1,1).p("AAAooIAARR");
	this.shape_31.setTransform(9,-51.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("rgba(60,177,161,0.616)").ss(2,1,1).p("AAAo8IAAR5");
	this.shape_32.setTransform(9,-53.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("rgba(61,179,162,0.635)").ss(2,1,1).p("AAApQIAASh");
	this.shape_33.setTransform(9,-54.875);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("rgba(62,180,163,0.655)").ss(2,1,1).p("AAAplIAATL");
	this.shape_34.setTransform(9,-56.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("rgba(63,181,164,0.675)").ss(2,1,1).p("AAAp5IAATz");
	this.shape_35.setTransform(9,-58.325);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("rgba(64,183,165,0.694)").ss(2,1,1).p("AAAqNIAAUb");
	this.shape_36.setTransform(9,-60.075);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("rgba(66,184,166,0.71)").ss(2,1,1).p("AAAqiIAAVF");
	this.shape_37.setTransform(9,-61.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("rgba(67,186,167,0.729)").ss(2,1,1).p("AAAq2IAAVt");
	this.shape_38.setTransform(9,-63.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("rgba(68,187,168,0.749)").ss(2,1,1).p("AAArKIAAWV");
	this.shape_39.setTransform(9,-65.275);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("rgba(69,189,169,0.769)").ss(2,1,1).p("AAArfIAAW/");
	this.shape_40.setTransform(9,-67);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("rgba(70,190,170,0.788)").ss(2,1,1).p("AAArzIAAXn");
	this.shape_41.setTransform(9,-68.75);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("rgba(71,192,171,0.808)").ss(2,1,1).p("AAAsHIAAYP");
	this.shape_42.setTransform(9,-70.475);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("rgba(72,193,172,0.827)").ss(2,1,1).p("AAAscIAAY5");
	this.shape_43.setTransform(9,-72.225);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("rgba(73,194,174,0.847)").ss(2,1,1).p("AAAswIAAZh");
	this.shape_44.setTransform(9,-73.925);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("rgba(74,196,175,0.867)").ss(2,1,1).p("AAAtFIAAaL");
	this.shape_45.setTransform(9,-75.65);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("rgba(75,197,176,0.886)").ss(2,1,1).p("AAAtZIAAaz");
	this.shape_46.setTransform(9,-77.4);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("rgba(77,199,177,0.902)").ss(2,1,1).p("AAAttIAAbb");
	this.shape_47.setTransform(9,-79.125);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("rgba(78,200,178,0.922)").ss(2,1,1).p("AAAuCIAAcF");
	this.shape_48.setTransform(9,-80.85);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("rgba(79,202,179,0.941)").ss(2,1,1).p("AAAuWIAAct");
	this.shape_49.setTransform(9,-82.6);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("rgba(80,203,180,0.961)").ss(2,1,1).p("AAAuqIAAdV");
	this.shape_50.setTransform(9,-84.325);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("rgba(81,205,181,0.98)").ss(2,1,1).p("AAAu/IAAd/");
	this.shape_51.setTransform(9,-86.075);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAPUIAA+n");
	this.shape_52.setTransform(9,-87.8);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAs/IAAZ/");
	this.shape_53.setTransform(9,-73.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAqrIAAVX");
	this.shape_54.setTransform(9,-58.225);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAoYIAAQw");
	this.shape_55.setTransform(9,-43.45);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAmEIAAMJ");
	this.shape_56.setTransform(9,-28.675);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#52CEB6").ss(2,1,1).p("AAAjwIAAHh");
	this.shape_57.setTransform(9,-13.875);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#52CEB6").ss(2,1,1).p("AAABdIAAi5");
	this.shape_58.setTransform(9,0.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},8).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_52}]},138).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2_Слой_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#52CEB6").s().p("Ag/BAQgbgbAAglQAAglAbgaQAagbAlAAQAlAAAbAbQAbAagBAlQABAlgbAbQgbAbglgBQglABgagbg");
	this.shape.setTransform(9.05,9.05);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#52CEB6").s().p("AhABBQgbgbAAgmQAAglAbgbQAbgbAlAAQAmAAAbAbQAbAbAAAlQAAAmgbAbQgbAbgmAAQglAAgbgbg");
	this.shape_1.setTransform(9.05,9.05);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#52CEB6").s().p("AhBBCQgcgbAAgnQAAgmAcgbQAbgcAmAAQAnAAAbAcQAdAbAAAmQAAAngdAbQgbAdgnAAQgmAAgbgdg");
	this.shape_2.setTransform(9.05,9.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#52CEB6").s().p("AhDBEQgcgcAAgoQAAgnAcgcQAcgcAnAAQAoAAAcAcQAcAcAAAnQAAAogcAcQgcAcgoAAQgnAAgcgcg");
	this.shape_3.setTransform(9.05,9.05);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#52CEB6").s().p("AhFBGQgcgdAAgpQAAgoAcgdQAdgcAoAAQApAAAdAcQAcAdAAAoQAAApgcAdQgdAcgpAAQgoAAgdgcg");
	this.shape_4.setTransform(9.05,9.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#52CEB6").s().p("AhGBHQgdgdAAgqQAAgpAdgdQAdgdApAAQAqAAAdAdQAdAdAAApQAAAqgdAdQgdAdgqAAQgpAAgdgdg");
	this.shape_5.setTransform(9.05,9.05);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#52CEB6").s().p("AhHBIQgegeAAgqQAAgqAegdQAdgeAqAAQAqAAAeAeQAeAdAAAqQAAAqgeAeQgeAegqAAQgqAAgdgeg");
	this.shape_6.setTransform(9.05,9.05);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#52CEB6").s().p("AhIBJQgfgeAAgrQAAgqAfgeQAegfAqAAQArAAAeAfQAfAeAAAqQAAArgfAeQgeAfgrAAQgqAAgegfg");
	this.shape_7.setTransform(9.05,9.05);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#52CEB6").s().p("AhKBLQgfgfAAgsQAAgrAfgfQAfgfArAAQAsAAAfAfQAfAfAAArQAAAsgfAfQgfAfgsAAQgrAAgfgfg");
	this.shape_8.setTransform(9.05,9.05);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#52CEB6").s().p("AhLBMQgfgfgBgtQABgsAfgfQAfgfAsgBQAtABAfAfQAfAfAAAsQAAAtgfAfQgfAfgtAAQgsAAgfgfg");
	this.shape_9.setTransform(9.05,9.05);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#52CEB6").s().p("AhNBOQgfghAAgtQAAgsAfghQAhgfAsAAQAtAAAhAfQAfAhAAAsQAAAtgfAhQghAfgtAAQgsAAghgfg");
	this.shape_10.setTransform(9.05,9.05);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#52CEB6").s().p("AhOBPQghghABguQgBgtAhghQAhghAtABQAugBAhAhQAhAhgBAtQABAughAhQghAhgugBQgtABghghg");
	this.shape_11.setTransform(9.05,9.05);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#52CEB6").s().p("AhPBQQgighAAgvQAAguAighQAhgiAuAAQAvAAAhAiQAiAhAAAuQAAAvgiAhQghAigvAAQguAAghgig");
	this.shape_12.setTransform(9.05,9.05);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#52CEB6").s().p("AhRBRQgighAAgwQAAgvAigiQAigiAvAAQAwAAAhAiQAjAiAAAvQAAAwgjAhQghAjgwAAQgvAAgigjg");
	this.shape_13.setTransform(9.05,9.05);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#52CEB6").s().p("AhSBTQgigjgBgwQABgvAigjQAjgiAvgBQAwABAjAiQAiAjAAAvQAAAwgiAjQgjAigwAAQgvAAgjgig");
	this.shape_14.setTransform(9.05,9.05);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#52CEB6").s().p("AhTBUQgjgjAAgxQAAgwAjgjQAjgjAwAAQAxAAAjAjQAjAjAAAwQAAAxgjAjQgjAjgxAAQgwAAgjgjg");
	this.shape_15.setTransform(9.05,9.05);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#52CEB6").s().p("AhUBWQgkgkAAgyQAAgxAkgjQAjgkAxAAQAyAAAkAkQAjAjAAAxQAAAygjAkQgkAjgyAAQgxAAgjgjg");
	this.shape_16.setTransform(9.05,9.05);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#52CEB6").s().p("AhWBXQgkgkAAgzQAAgyAkgkQAkgkAyAAQAzAAAkAkQAkAkAAAyQAAAzgkAkQgkAkgzAAQgyAAgkgkg");
	this.shape_17.setTransform(9.05,9.05);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#52CEB6").s().p("AhXBYQglgkAAg0QAAgzAlgkQAkglAzAAQA0AAAkAlQAlAkAAAzQAAA0glAkQgkAlg0AAQgzAAgkglg");
	this.shape_18.setTransform(9.05,9.05);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#52CEB6").s().p("AhZBaQglgmAAg0QAAgzAlgmQAmglAzAAQA0AAAmAlQAlAmAAAzQAAA0glAmQgmAlg0AAQgzAAgmglg");
	this.shape_19.setTransform(9.05,9.05);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#52CEB6").s().p("AhaBbQgmglAAg2QAAg0AmgmQAmgmA0AAQA2AAAlAmQAmAmAAA0QAAA2gmAlQglAmg2AAQg0AAgmgmg");
	this.shape_20.setTransform(9.05,9.05);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#52CEB6").s().p("AhbBcQgngmABg2QgBg1AngmQAmgnA1ABQA2gBAmAnQAnAmAAA1QAAA2gnAmQgmAng2AAQg1AAgmgng");
	this.shape_21.setTransform(9.05,9.05);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#52CEB6").s().p("AhcBdQgogmAAg3QAAg2AogmQAmgoA2AAQA3AAAmAoQAnAmABA2QgBA3gnAmQgmAng3ABQg2gBgmgng");
	this.shape_22.setTransform(9.05,9.05);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#52CEB6").s().p("AheBfQgognAAg4QAAg3AognQAngoA3AAQA4AAAnAoQAoAnAAA3QAAA4goAnQgnAog4AAQg3AAgngog");
	this.shape_23.setTransform(9.05,9.05);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#52CEB6").s().p("AhgBhQgogoABg5QgBg4AogoQAogoA4ABQA5gBAoAoQAoAogBA4QABA5goAoQgoAog5gBQg4ABgogog");
	this.shape_24.setTransform(9.05,9.05);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#52CEB6").s().p("AhhBiQgogoAAg6QAAg5AogoQAogoA5AAQA6AAAoAoQAoAoAAA5QAAA6goAoQgoAog6AAQg5AAgogog");
	this.shape_25.setTransform(9.05,9.05);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#52CEB6").s().p("AhiBjQgqgpAAg6QAAg5AqgpQApgqA5AAQA6AAApAqQAqApAAA5QAAA6gqApQgpAqg6AAQg5AAgpgqg");
	this.shape_26.setTransform(9.05,9.05);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#52CEB6").s().p("AhjBkQgqgpAAg7QAAg6AqgpQApgqA6AAQA7AAApAqQAqApAAA6QAAA7gqApQgpAqg7AAQg6AAgpgqg");
	this.shape_27.setTransform(9.05,9.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#52CEB6").s().p("AhkBlQgrgqAAg7QAAg7ArgpQApgrA7AAQA7AAAqArQArApAAA7QAAA7grAqQgqArg7AAQg7AAgpgrg");
	this.shape_28.setTransform(9.05,9.05);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#52CEB6").s().p("AhmBnQgrgrAAg8QAAg8ArgqQAqgrA8AAQA8AAArArQArAqAAA8QAAA8grArQgrArg8AAQg8AAgqgrg");
	this.shape_29.setTransform(9.05,9.05);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#52CEB6").s().p("AhZBaQglglAAg1QAAg0AlglQAlglA0AAQA1AAAlAlQAlAlAAA0QAAA1glAlQglAlg1AAQg0AAglglg");
	this.shape_30.setTransform(9.05,9.05);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#52CEB6").s().p("AhTBTQgigiAAgxQAAgwAigjQAjgiAwAAQAxAAAiAiQAjAjAAAwQAAAxgjAiQgiAjgxAAQgwAAgjgjg");
	this.shape_31.setTransform(9.075,9.075);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#52CEB6").s().p("AhMBNQggggAAgtQAAgsAgggQAgggAsAAQAtAAAgAgQAgAgAAAsQAAAtggAgQggAggtAAQgsAAggggg");
	this.shape_32.setTransform(9.05,9.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(29).to({_off:false},0).wait(169).to({_off:true},1).wait(6));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,37.9).s().p("AkKELQhuhuAAidQAAibBuhvQBvhuCbAAQCdAABuBuQBvBvAACbQAACdhvBuQhuBvidAAQibAAhvhvg");
	this.shape.setTransform(9.1,9.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,38.6).s().p("AkPEQQhwhxAAifQAAieBwhxQBxhwCeAAQCfAABxBwQBvBxAACeQAACfhvBxQhxBvifAAQieAAhxhvg");
	this.shape_1.setTransform(9.1,9.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.2).s().p("AkTETQhxhxgBiiQABihBxhyQByhxChgBQCiABBxBxQBzByAAChQAACihzBxQhxBziiAAQihAAhyhzg");
	this.shape_2.setTransform(9.1,9.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,39.8).s().p("AkXEYQh0h0AAikQAAijB0h0QB0h0CjAAQCkAAB0B0QB0B0AACjQAACkh0B0Qh0B0ikAAQijAAh0h0g");
	this.shape_3.setTransform(9.125,9.125);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.4).s().p("AkbEcQh2h2AAimQAAimB2h1QB1h2CmAAQCmAAB2B2QB2B1AACmQAACmh2B2Qh2B2imAAQimAAh1h2g");
	this.shape_4.setTransform(9.125,9.125);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41).s().p("AkfEhQh4h4AAipQAAioB4h3QB3h4CoAAQCpAAB4B4QB3B3AACoQAACph3B4Qh4B3ipAAQioAAh3h3g");
	this.shape_5.setTransform(9.1,9.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,41.6).s().p("AkkElQh5h5AAisQAAirB5h5QB5h5CrAAQCsAAB5B5QB5B5AACrQAACsh5B5Qh5B5isAAQirAAh5h5g");
	this.shape_6.setTransform(9.1,9.1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.2).s().p("AkoEpQh7h7AAiuQAAitB7h7QB7h7CtAAQCuAAB7B7QB7B7AACtQAACuh7B7Qh7B7iuAAQitAAh7h7g");
	this.shape_7.setTransform(9.1,9.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,42.8).s().p("AksEtQh9h8AAixQAAiwB9h8QB8h9CwAAQCxAAB8B9QB9B8AACwQAACxh9B8Qh8B9ixAAQiwAAh8h9g");
	this.shape_8.setTransform(9.1,9.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.4).s().p("AkxEyQh+h/AAizQAAiyB+h/QB/h+CyAAQCzAAB/B+QB+B/AACyQAACzh+B/Qh/B+izAAQiyAAh/h+g");
	this.shape_9.setTransform(9.125,9.125);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.1).s().p("Ak1E2QiAiAAAi2QAAi1CAiAQCAiAC1AAQC2AACACAQCACAAAC1QAAC2iACAQiACAi2AAQi1AAiAiAg");
	this.shape_10.setTransform(9.125,9.125);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,44.7).s().p("Ak5E6QiCiCAAi4QAAi3CCiCQCCiCC3AAQC4AACCCCQCCCCAAC3QAAC4iCCCQiCCCi4AAQi3AAiCiCg");
	this.shape_11.setTransform(9.125,9.125);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.3).s().p("Ak+E+QiDiDAAi7QAAi6CDiEQCEiDC6AAQC7AACDCDQCECEAAC6QAAC7iECDQiDCEi7AAQi6AAiEiEg");
	this.shape_12.setTransform(9.125,9.125);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,45.9).s().p("AlCFDQiFiGAAi9QAAi8CFiGQCGiFC8AAQC9AACGCFQCFCGAAC8QAAC9iFCGQiGCFi9AAQi8AAiGiFg");
	this.shape_13.setTransform(9.125,9.125);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,46.5).s().p("AlGFHQiHiHAAjAQAAi/CHiHQCHiHC/AAQDAAACHCHQCHCHAAC/QAADAiHCHQiHCHjAAAQi/AAiHiHg");
	this.shape_14.setTransform(9.125,9.125);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.1).s().p("AlKFLQiKiJAAjCQAAjBCKiJQCJiKDBAAQDCAACJCKQCKCJAADBQAADCiKCJQiJCKjCAAQjBAAiJiKg");
	this.shape_15.setTransform(9.125,9.125);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,47.7).s().p("AlPFQQiLiLAAjFQAAjECLiLQCLiLDEAAQDFAACLCLQCLCLAADEQAADFiLCLQiLCLjFAAQjEAAiLiLg");
	this.shape_16.setTransform(9.125,9.125);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.3).s().p("AlTFUQiNiNAAjHQAAjGCNiNQCNiNDGAAQDHAACNCNQCNCNAADGQAADHiNCNQiNCNjHAAQjGAAiNiNg");
	this.shape_17.setTransform(9.125,9.125);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,48.9).s().p("AlXFYQiPiOAAjKQAAjJCPiOQCOiPDJAAQDKAACOCPQCPCOAADJQAADKiPCOQiOCPjKAAQjJAAiOiPg");
	this.shape_18.setTransform(9.125,9.125);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.6).s().p("AlbFdQiRiRAAjMQAAjLCRiQQCQiRDLAAQDMAACRCRQCQCQAADLQAADMiQCRQiRCQjMAAQjLAAiQiQg");
	this.shape_19.setTransform(9.125,9.125);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,50.2).s().p("AlgFhQiSiSAAjPQAAjOCSiSQCSiSDOAAQDPAACSCSQCSCSAADOQAADPiSCSQiSCSjPAAQjOAAiSiSg");
	this.shape_20.setTransform(9.125,9.125);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,50.8).s().p("AllFlQiTiUAAjRQAAjRCTiUQCUiTDRAAQDRAACUCTQCUCUAADRQAADRiUCUQiUCUjRAAQjRAAiUiUg");
	this.shape_21.setTransform(9.15,9.15);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,51.4).s().p("AlpFpQiViVAAjUQAAjTCViWQCWiVDTAAQDUAACVCVQCWCWAADTQAADUiWCVQiVCWjUAAQjTAAiWiWg");
	this.shape_22.setTransform(9.15,9.15);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52).s().p("AltFuQiXiXAAjXQAAjWCXiXQCXiXDWAAQDXAACXCXQCXCXAADWQAADXiXCXQiXCXjXAAQjWAAiXiXg");
	this.shape_23.setTransform(9.15,9.15);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.6).s().p("AlxFyQiZiZAAjZQAAjYCZiZQCZiZDYAAQDZAACZCZQCZCZAADYQAADZiZCZQiZCZjZAAQjYAAiZiZg");
	this.shape_24.setTransform(9.15,9.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,53.2).s().p("Al1F3QibibAAjcQAAjaCbibQCbibDaAAQDcAACbCbQCaCbAADaQAADciaCbQibCajcAAQjaAAibiag");
	this.shape_25.setTransform(9.125,9.125);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,53.8).s().p("Al5F7QididAAjeQAAjdCdicQCcidDdAAQDeAACdCdQCcCcAADdQAADeicCdQidCcjeAAQjdAAicicg");
	this.shape_26.setTransform(9.125,9.125);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,54.4).s().p("Al+F/QififAAjgQAAjfCfifQCfifDfAAQDgAACfCfQCeCfAADfQAADgieCfQifCejgAAQjfAAifieg");
	this.shape_27.setTransform(9.15,9.15);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55).s().p("AmCGDQihigAAjjQAAjiChigQCgihDiAAQDjAACgChQChCgAADiQAADjihCgQigChjjAAQjiAAigihg");
	this.shape_28.setTransform(9.15,9.15);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,55.7).s().p("AmGGIQiiiiAAjmQAAjkCiiiQCiiiDkAAQDmAACiCiQCiCiAADkQAADmiiCiQiiCijmAAQjkAAiiiig");
	this.shape_29.setTransform(9.15,9.15);
	this.shape_29._off = true;

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,52.7).s().p("AlyFyQiZiZAAjZQAAjYCZiaQCaiZDYAAQDZAACZCZQCaCaAADYQAADZiaCZQiZCajZAAQjYAAiaiag");
	this.shape_30.setTransform(9.15,9.15);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,49.8).s().p("AldFeQiRiRAAjNQAAjMCRiRQCRiRDMAAQDNAACRCRQCRCRAADMQAADNiRCRQiRCRjNAAQjMAAiRiRg");
	this.shape_31.setTransform(9.125,9.125);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],-0.1,-0.1,0,-0.1,-0.1,46.8).s().p("AlIFJQiJiIAAjBQAAjACJiIQCIiJDAAAQDBAACICJQCICIABDAQgBDBiICIQiICIjBABQjAgBiIiIg");
	this.shape_32.setTransform(9.15,9.15);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,43.8).s().p("Ak0E0Qh/h/AAi1QAAi0B/iAQCAh/C0AAQC1AAB/B/QCACAAAC0QAAC1iAB/Qh/CAi1AAQi0AAiAiAg");
	this.shape_33.setTransform(9.125,9.125);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.rf(["rgba(82,206,182,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,40.9).s().p("AkeEgQh4h3AAipQAAioB4h2QB2h4CoAAQCpAAB3B4QB3B2AACoQAACph3B3Qh3B3ipAAQioAAh2h3g");
	this.shape_34.setTransform(9.1,9.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape}]},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.shape_29).wait(29).to({_off:false},0).wait(169).to({_off:true},1).wait(6));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_1__копия_2_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#19837F").ss(2,1,1).p("AqomnIVRFeIw/Hxg");
	this.shape.setTransform(144.125,49.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#19837F").ss(2,1,1).p("AqnmpIVPFfIw3H0g");
	this.shape_1.setTransform(143.475,49.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#19837F").ss(2,1,1).p("AqmmsIVNFfIwwH6g");
	this.shape_2.setTransform(142.875,49.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#19837F").ss(2,1,1).p("AqlmuIVLFfIwoH+g");
	this.shape_3.setTransform(142.225,49.625);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#19837F").ss(2,1,1).p("AqlmxIVLFgIwiIDg");
	this.shape_4.setTransform(141.6,49.75);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#19837F").ss(2,1,1).p("Aqjm0IVHFhIwZIIg");
	this.shape_5.setTransform(140.975,49.85);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#19837F").ss(2,1,1).p("Aqjm2IVHFhIwTIMg");
	this.shape_6.setTransform(140.35,49.975);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#19837F").ss(2,1,1).p("Aqhm5IVDFiIwKIRg");
	this.shape_7.setTransform(139.725,50.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#19837F").ss(2,1,1).p("Aqhm7IVDFiIwEIVg");
	this.shape_8.setTransform(139.1,50.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#19837F").ss(2,1,1).p("Aqfm+IVAFjIv8Iag");
	this.shape_9.setTransform(138.45,50.325);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#19837F").ss(2,1,1).p("AqenAIU9FjIv0Ieg");
	this.shape_10.setTransform(137.825,50.425);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#19837F").ss(2,1,1).p("AqdnDIU8FkIvtIjg");
	this.shape_11.setTransform(137.2,50.55);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#19837F").ss(2,1,1).p("AqdnFIU6FjIvkIog");
	this.shape_12.setTransform(136.55,50.65);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#19837F").ss(2,1,1).p("AqcnIIU5FkIveItg");
	this.shape_13.setTransform(135.95,50.775);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#19837F").ss(2,1,1).p("AqbnLIU3FlIvWIyg");
	this.shape_14.setTransform(135.3,50.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#19837F").ss(2,1,1).p("AqanOIU1FmIvPI3g");
	this.shape_15.setTransform(134.675,51);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#19837F").ss(2,1,1).p("AqZnQIUyFmIvGI7g");
	this.shape_16.setTransform(134.05,51.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#19837F").ss(2,1,1).p("AqYnTIUxFnIvAJAg");
	this.shape_17.setTransform(133.425,51.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#19837F").ss(2,1,1).p("AqXnVIUvFnIu4JEg");
	this.shape_18.setTransform(132.775,51.325);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#19837F").ss(2,1,1).p("AqWnYIUtFoIuxJJg");
	this.shape_19.setTransform(132.15,51.425);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#19837F").ss(2,1,1).p("AqVnbIUrFpIupJOg");
	this.shape_20.setTransform(131.525,51.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#19837F").ss(2,1,1).p("AqTndIUoFoIuhJTg");
	this.shape_21.setTransform(130.9,51.65);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#19837F").ss(2,1,1).p("AqTngIUnFpIuaJYg");
	this.shape_22.setTransform(130.275,51.775);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#19837F").ss(2,1,1).p("AqSniIUlFqIuSJbg");
	this.shape_23.setTransform(129.625,51.875);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#19837F").ss(2,1,1).p("AqRnlIUjFrIuLJgg");
	this.shape_24.setTransform(129.025,51.975);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#19837F").ss(2,1,1).p("AqQnoIUhFrIuDJmg");
	this.shape_25.setTransform(128.375,52.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#19837F").ss(2,1,1).p("AqPnqIUfFsIt8Jpg");
	this.shape_26.setTransform(127.75,52.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#19837F").ss(2,1,1).p("AqOntIUdFsIt0Jvg");
	this.shape_27.setTransform(127.125,52.35);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#19837F").ss(2,1,1).p("AqNnvIUbFsItsJzg");
	this.shape_28.setTransform(126.475,52.45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#19837F").ss(2,1,1).p("AqMnyIUZFtItkJ4g");
	this.shape_29.setTransform(125.85,52.575);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#19837F").ss(2,1,1).p("AqLn0IUXFtItdJ8g");
	this.shape_30.setTransform(125.225,52.675);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#19837F").ss(2,1,1).p("AqKn3IUVFuItVKBg");
	this.shape_31.setTransform(124.6,52.775);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#19837F").ss(2,1,1).p("AqJn6IUTFvItNKGg");
	this.shape_32.setTransform(123.95,52.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#19837F").ss(2,1,1).p("AqIn8IURFuItGKLg");
	this.shape_33.setTransform(123.35,53);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#19837F").ss(2,1,1).p("AqHn/IUPFvIs/KQg");
	this.shape_34.setTransform(122.7,53.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#19837F").ss(2,1,1).p("AqGoBIUNFvIs4KUg");
	this.shape_35.setTransform(122.1,53.225);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#19837F").ss(2,1,1).p("AqFoEIULFwIsvKZg");
	this.shape_36.setTransform(121.45,53.35);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#19837F").ss(2,1,1).p("AqEoHIUJFxIsoKeg");
	this.shape_37.setTransform(120.8,53.45);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#19837F").ss(2,1,1).p("AqDoJIUHFxIsgKig");
	this.shape_38.setTransform(120.2,53.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#19837F").ss(2,1,1).p("AqCoMIUFFyIsZKng");
	this.shape_39.setTransform(119.55,53.675);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#19837F").ss(2,1,1).p("AqBoOIUDFyIsRKrg");
	this.shape_40.setTransform(118.925,53.775);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#19837F").ss(2,1,1).p("AqAoRIUBFzIsKKwg");
	this.shape_41.setTransform(118.3,53.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#19837F").ss(2,1,1).p("Ap/oUIT/F0IsCK1g");
	this.shape_42.setTransform(117.675,54);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#19837F").ss(2,1,1).p("Ap+oWIT9F0Ir6K5g");
	this.shape_43.setTransform(117.025,54.125);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#19837F").ss(2,1,1).p("Ap9oZIT7F1IrzK+g");
	this.shape_44.setTransform(116.425,54.225);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#19837F").ss(2,1,1).p("Ap8obIT5F0IrrLDg");
	this.shape_45.setTransform(115.775,54.375);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#19837F").ss(2,1,1).p("Ap7oeIT3F1IrkLIg");
	this.shape_46.setTransform(115.125,54.475);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#19837F").ss(2,1,1).p("Ap6ogIT1F1IrcLMg");
	this.shape_47.setTransform(114.525,54.575);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#19837F").ss(2,1,1).p("Ap5ojITzF2IrVLRg");
	this.shape_48.setTransform(113.875,54.7);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#19837F").ss(2,1,1).p("Ap4omITxF3IrNLWg");
	this.shape_49.setTransform(113.275,54.8);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#19837F").ss(2,1,1).p("Ap3ooITvF3IrGLag");
	this.shape_50.setTransform(112.625,54.925);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#19837F").ss(2,1,1).p("Ap3orITvF4Iq/Lfg");
	this.shape_51.setTransform(112,55.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#19837F").ss(2,1,1).p("Ap1ouITrF4Iq3Llg");
	this.shape_52.setTransform(111.375,55.15);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#19837F").ss(2,1,1).p("Ap1owITqF5IqvLog");
	this.shape_53.setTransform(110.75,55.25);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#19837F").ss(2,1,1).p("Ap0ozITpF6IqoLtg");
	this.shape_54.setTransform(110.1,55.35);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#19837F").ss(2,1,1).p("Apyo1ITlF6IqgLxg");
	this.shape_55.setTransform(109.475,55.475);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#19837F").ss(2,1,1).p("Apxo4ITkF7IqZL2g");
	this.shape_56.setTransform(108.85,55.575);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#19837F").ss(2,1,1).p("Apxo7ITjF8IqSL7g");
	this.shape_57.setTransform(108.2,55.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#19837F").ss(2,1,1).p("Apwo9IThF7IqKMAg");
	this.shape_58.setTransform(107.6,55.8);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#19837F").ss(2,1,1).p("ApvpAITfF8IqDMFg");
	this.shape_59.setTransform(106.95,55.925);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#19837F").ss(2,1,1).p("AptpCITcF8Ip7MJg");
	this.shape_60.setTransform(106.35,56.025);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#19837F").ss(2,1,1).p("ApspFITaF9IpzMOg");
	this.shape_61.setTransform(105.7,56.125);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#19837F").ss(2,1,1).p("ApspHITZF9IptMSg");
	this.shape_62.setTransform(105.05,56.275);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#19837F").ss(2,1,1).p("AprpKITXF+IpmMXg");
	this.shape_63.setTransform(104.45,56.375);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#19837F").ss(2,1,1).p("ApqpNITVF+IpeMdg");
	this.shape_64.setTransform(103.8,56.5);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#19837F").ss(2,1,1).p("ApppPITTF+IpWMhg");
	this.shape_65.setTransform(103.175,56.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#19837F").ss(2,1,1).p("ApopSITQF/IpNMmg");
	this.shape_66.setTransform(102.55,56.725);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#19837F").ss(2,1,1).p("ApnpUITPF/IpHMqg");
	this.shape_67.setTransform(101.925,56.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#19837F").ss(2,1,1).p("ApmpXITNGAIo/Mvg");
	this.shape_68.setTransform(101.275,56.95);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#19837F").ss(2,1,1).p("AplpaITLGBIo4M0g");
	this.shape_69.setTransform(100.675,57.05);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#19837F").ss(2,1,1).p("ApkpcITJGBIowM4g");
	this.shape_70.setTransform(100.025,57.15);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#19837F").ss(2,1,1).p("ApjpfITHGCIooM9g");
	this.shape_71.setTransform(99.375,57.275);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#19837F").ss(2,1,1).p("ApiphITFGCIohNBg");
	this.shape_72.setTransform(98.775,57.375);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#19837F").ss(2,1,1).p("AphpkITDGDIoZNGg");
	this.shape_73.setTransform(98.125,57.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#19837F").ss(2,1,1).p("ApgpnITBGEIoSNLg");
	this.shape_74.setTransform(97.525,57.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#19837F").ss(2,1,1).p("ApfppIS/GEIoKNPg");
	this.shape_75.setTransform(96.875,57.725);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#19837F").ss(2,1,1).p("ApepsIS9GFIoCNUg");
	this.shape_76.setTransform(96.25,57.825);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#19837F").ss(2,1,1).p("ApdpuIS7GFIn7NYg");
	this.shape_77.setTransform(95.625,57.925);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#19837F").ss(2,1,1).p("ApcpxIS5GFIn0Neg");
	this.shape_78.setTransform(95,58.05);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#19837F").ss(2,1,1).p("Apbp0IS3GGInsNjg");
	this.shape_79.setTransform(94.35,58.15);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#19837F").ss(2,1,1).p("Apap2IS1GGInkNng");
	this.shape_80.setTransform(93.725,58.3);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#19837F").ss(2,1,1).p("ApZp5ISzGHIndNsg");
	this.shape_81.setTransform(93.1,58.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#19837F").ss(2,1,1).p("ApYp7ISxGHInVNwg");
	this.shape_82.setTransform(92.45,58.525);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#19837F").ss(2,1,1).p("ApXp+ISvGIInON1g");
	this.shape_83.setTransform(91.85,58.625);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#19837F").ss(2,1,1).p("ApWqAIStGIInGN5g");
	this.shape_84.setTransform(91.2,58.725);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#19837F").ss(2,1,1).p("ApVqDISrGJIm+N+g");
	this.shape_85.setTransform(90.575,58.85);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#19837F").ss(2,1,1).p("ApUqFISpGJIm3ODg");
	this.shape_86.setTransform(89.95,58.95);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#19837F").ss(2,1,1).p("ApTqIISnGKImvOHg");
	this.shape_87.setTransform(89.325,59.075);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#19837F").ss(2,1,1).p("ApSqLISlGLImoOMg");
	this.shape_88.setTransform(88.7,59.175);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#19837F").ss(2,1,1).p("ApRqOISjGMImgORg");
	this.shape_89.setTransform(88.05,59.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#19837F").ss(2,1,1).p("ApQqQIShGLImZOWg");
	this.shape_90.setTransform(87.425,59.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#19837F").ss(2,1,1).p("ApPqTISfGMImRObg");
	this.shape_91.setTransform(86.8,59.5);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#19837F").ss(2,1,1).p("ApOqVISdGMImKOfg");
	this.shape_92.setTransform(86.175,59.625);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#19837F").ss(2,1,1).p("ApNqYISbGNImCOkg");
	this.shape_93.setTransform(85.525,59.725);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#19837F").ss(2,1,1).p("ApMqbISZGOIl7Opg");
	this.shape_94.setTransform(84.925,59.85);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#19837F").ss(2,1,1).p("ApLqdISXGOIlzOtg");
	this.shape_95.setTransform(84.275,59.95);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#19837F").ss(2,1,1).p("ApLqgISXGPIlsOyg");
	this.shape_96.setTransform(83.65,60.075);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#19837F").ss(2,1,1).p("ApJqiISTGPIlkO2g");
	this.shape_97.setTransform(83.025,60.175);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#19837F").ss(2,1,1).p("ApIqlISRGPIlcO8g");
	this.shape_98.setTransform(82.375,60.325);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#19837F").ss(2,1,1).p("ApIqnISQGQIlVO/g");
	this.shape_99.setTransform(81.75,60.425);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#19837F").ss(2,1,1).p("ApGqqISNGRIlNPEg");
	this.shape_100.setTransform(81.125,60.525);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#19837F").ss(2,1,1).p("ApGqtISNGSIlGPJg");
	this.shape_101.setTransform(80.5,60.65);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#19837F").ss(2,1,1).p("ApEqvISJGRIk+POg");
	this.shape_102.setTransform(79.875,60.75);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#19837F").ss(2,1,1).p("ApEqyISJGSIk3PTg");
	this.shape_103.setTransform(79.25,60.875);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#19837F").ss(2,1,1).p("ApDq0ISHGSIkwPXg");
	this.shape_104.setTransform(78.6,60.975);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#19837F").ss(2,1,1).p("ApCq3ISFGTIkoPcg");
	this.shape_105.setTransform(78,61.1);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#19837F").ss(2,1,1).p("ApAq6ISCGUIkgPhg");
	this.shape_106.setTransform(77.35,61.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#19837F").ss(2,1,1).p("Ao/qwIR/GEIkKPdg");
	this.shape_107.setTransform(76.5,60.85);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#19837F").ss(2,1,1).p("Ao9qmIR7F1Ij1PYg");
	this.shape_108.setTransform(75.65,60.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#19837F").ss(2,1,1).p("Ao7qdIR2FmIjdPVg");
	this.shape_109.setTransform(74.8,60.15);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#19837F").ss(2,1,1).p("Ao5qUIRzFYIjJPRg");
	this.shape_110.setTransform(73.975,59.775);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#19837F").ss(2,1,1).p("Ao3qKIRvFJIizPNg");
	this.shape_111.setTransform(73.15,59.45);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#19837F").ss(2,1,1).p("Ao1qBIRrE6IicPJg");
	this.shape_112.setTransform(72.3,59.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#19837F").ss(2,1,1).p("Aozp4IRnEsIiGPFg");
	this.shape_113.setTransform(71.45,58.75);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#19837F").ss(2,1,1).p("AowpuIRiEdIhwPAg");
	this.shape_114.setTransform(70.6,58.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#19837F").ss(2,1,1).p("AovplIRfEOIhaO9g");
	this.shape_115.setTransform(69.75,58.05);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#19837F").ss(2,1,1).p("AotpbIRbD/IhFO4g");
	this.shape_116.setTransform(68.9,57.7);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#19837F").ss(2,1,1).p("AorpSIRXDwIguO1g");
	this.shape_117.setTransform(68.05,57.35);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#19837F").ss(2,1,1).p("AoppIIRTDhIgZOwg");
	this.shape_118.setTransform(67.225,56.975);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#19837F").ss(2,1,1).p("Aono/IRODTIgCOsg");
	this.shape_119.setTransform(66.4,56.625);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#19837F").ss(2,1,1).p("Aovo2IRLDEIAUOpg");
	this.shape_120.setTransform(66.55,56.3);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#19837F").ss(2,1,1).p("Ao4osIRHC0IAqOlg");
	this.shape_121.setTransform(66.8,55.95);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#19837F").ss(2,1,1).p("ApBoiIRDClIBAOhg");
	this.shape_122.setTransform(67.05,55.6);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#19837F").ss(2,1,1).p("ApKoZIQ/CWIBWOdg");
	this.shape_123.setTransform(67.3,55.25);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#19837F").ss(2,1,1).p("ApToQIQ7CIIBsOZg");
	this.shape_124.setTransform(67.55,54.9);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#19837F").ss(2,1,1).p("ApcoGIQ3B5ICCOUg");
	this.shape_125.setTransform(67.8,54.525);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#19837F").ss(2,1,1).p("Apln9IQzBqICYORg");
	this.shape_126.setTransform(68.05,54.175);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#19837F").ss(2,1,1).p("AptnzIQuBbICuOMg");
	this.shape_127.setTransform(68.35,53.825);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#19837F").ss(2,1,1).p("Ap2nqIQqBNIDEOIg");
	this.shape_128.setTransform(68.6,53.475);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#19837F").ss(2,1,1).p("AqAngIQmA9IDbOEg");
	this.shape_129.setTransform(68.85,53.125);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#19837F").ss(2,1,1).p("AqJnXIQiAuIDxOBg");
	this.shape_130.setTransform(69.1,52.8);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#19837F").ss(2,1,1).p("AqSnOIQfAgIEGN9g");
	this.shape_131.setTransform(69.35,52.45);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#19837F").ss(2,1,1).p("AqbnEIQbARIEcN4g");
	this.shape_132.setTransform(69.6,52.075);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#19837F").ss(2,1,1).p("Aqjm7IQWACIEyN1g");
	this.shape_133.setTransform(69.85,51.725);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#19837F").ss(2,1,1).p("AqtmrIQTgNIFINxg");
	this.shape_134.setTransform(70.1,50.725);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#19837F").ss(2,1,1).p("Aq1maIQOgcIFeNtg");
	this.shape_135.setTransform(70.4,49.65);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#19837F").ss(2,1,1).p("Aq/mJIQKgrIF1Npg");
	this.shape_136.setTransform(70.65,48.55);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#19837F").ss(2,1,1).p("ArIl4IQGg6IGLNlg");
	this.shape_137.setTransform(70.9,47.45);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#19837F").ss(2,1,1).p("ArRlnIQDhIIGgNgg");
	this.shape_138.setTransform(71.15,46.35);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#19837F").ss(2,1,1).p("AralWIP/hYIG2Ndg");
	this.shape_139.setTransform(71.4,45.275);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#19837F").ss(2,1,1).p("ArilGIP6hmIHMNZg");
	this.shape_140.setTransform(71.65,44.175);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#19837F").ss(2,1,1).p("Arsk1IP3h1IHiNVg");
	this.shape_141.setTransform(71.9,43.075);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#19837F").ss(2,1,1).p("Ar1kkIPziEIH4NRg");
	this.shape_142.setTransform(72.15,41.975);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#19837F").ss(2,1,1).p("Ar+kTIPuiTIIONNg");
	this.shape_143.setTransform(72.45,40.9);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#19837F").ss(2,1,1).p("AsHkCIPriiIIkNJg");
	this.shape_144.setTransform(72.7,39.8);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#19837F").ss(2,1,1).p("AsQjxIPniwII6NEg");
	this.shape_145.setTransform(72.95,38.7);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#19837F").ss(2,1,1).p("AsZjgIPijAIJRNBg");
	this.shape_146.setTransform(73.2,37.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#19837F").ss(2,1,1).p("AshjQIPejOIJmM9g");
	this.shape_147.setTransform(73.45,36.5);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#19837F").ss(2,1,1).p("Asri/IPbjdIJ7M5g");
	this.shape_148.setTransform(73.7,35.425);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#19837F").ss(2,1,1).p("As0iuIPXjsIKSM1g");
	this.shape_149.setTransform(73.95,34.325);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#19837F").ss(2,1,1).p("As9idIPTj7IKoMxg");
	this.shape_150.setTransform(74.2,33.225);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#19837F").ss(2,1,1).p("AtGiMIPPkKIK+Mtg");
	this.shape_151.setTransform(74.45,32.125);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#19837F").ss(2,1,1).p("AtPh7IPKkZILVMpg");
	this.shape_152.setTransform(74.75,31.05);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#19837F").ss(2,1,1).p("AtYhqIPGkoILrMlg");
	this.shape_153.setTransform(75,29.95);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#19837F").ss(2,1,1).p("AthhZIPDk3IMAMhg");
	this.shape_154.setTransform(75.25,28.85);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#19837F").ss(2,1,1).p("AtqhIIO/lFIMVMbg");
	this.shape_155.setTransform(75.5,27.75);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#19837F").ss(2,1,1).p("Atzg3IO7lVIMsMZg");
	this.shape_156.setTransform(75.75,26.65);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#19837F").ss(2,1,1).p("At8gnIO3ljINCMVg");
	this.shape_157.setTransform(76,25.575);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#19837F").ss(2,1,1).p("AuFgWIOzlyINYMRg");
	this.shape_158.setTransform(76.25,24.475);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#19837F").ss(2,1,1).p("AuOgFIOvmBINuMNg");
	this.shape_159.setTransform(76.5,23.375);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#19837F").ss(2,1,1).p("AuXALIOrmOIOEMIg");
	this.shape_160.setTransform(76.8,22.3);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#19837F").ss(2,1,1).p("AugAcIOnmeIOaMFg");
	this.shape_161.setTransform(77.05,21.2);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#19837F").ss(2,1,1).p("AupAtIOkmtIOvMBg");
	this.shape_162.setTransform(77.3,20.1);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#19837F").ss(2,1,1).p("AuyA9IOgm7IPEL9g");
	this.shape_163.setTransform(77.55,19);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#19837F").ss(2,1,1).p("Au7BOIOcnKIPbL5g");
	this.shape_164.setTransform(77.8,17.9);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#19837F").ss(2,1,1).p("AvDBgIOXnZIPxL0g");
	this.shape_165.setTransform(78.05,16.8);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#19837F").ss(2,1,1).p("AvNBwIOUnoIQHLxg");
	this.shape_166.setTransform(78.3,15.7);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#19837F").ss(2,1,1).p("AvWCBIOQn3IQdLtg");
	this.shape_167.setTransform(78.55,14.625);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#19837F").ss(2,1,1).p("AveCSIOLoGIQzLpg");
	this.shape_168.setTransform(78.85,13.55);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#19837F").ss(2,1,1).p("AvoCjIOIoVIRJLlg");
	this.shape_169.setTransform(79.1,12.45);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#19837F").ss(2,1,1).p("AvxC0IOEokIRfLhg");
	this.shape_170.setTransform(79.35,11.35);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#19837F").ss(2,1,1).p("Av6DFIOAozIR1Ldg");
	this.shape_171.setTransform(79.6,10.25);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#19837F").ss(2,1,1).p("AwDDWIN8pCISLLZg");
	this.shape_172.setTransform(79.85,9.15);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#19837F").ss(2,1,1).p("AwMDnIN4pRIShLVg");
	this.shape_173.setTransform(80.1,8.05);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#19837F").ss(2,1,1).p("AwVD4IN0pgIS3LRg");
	this.shape_174.setTransform(80.35,6.95);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#19837F").ss(2,1,1).p("AweEIINwpuITNLNg");
	this.shape_175.setTransform(80.6,5.85);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#19837F").ss(2,1,1).p("AwnEZINrp9ITkLJg");
	this.shape_176.setTransform(80.9,4.8);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#19837F").ss(2,1,1).p("AwwEqINoqMIT5LFg");
	this.shape_177.setTransform(81.15,3.7);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#19837F").ss(2,1,1).p("Aw5E6INkqaIUPLBg");
	this.shape_178.setTransform(81.4,2.6);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#19837F").ss(2,1,1).p("AxBFMINfqqIUlK9g");
	this.shape_179.setTransform(81.65,1.5);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#19837F").ss(2,1,1).p("AjvlcIU7K5MgiXAAAg");
	this.shape_180.setTransform(81.9,0.4);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("#19837F").ss(2,1,1).p("AxEFWINfqxIUqK3g");
	this.shape_181.setTransform(81.95,0.85);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#19837F").ss(2,1,1).p("Aw+FQINjqqIUaK1g");
	this.shape_182.setTransform(82,1.3);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("#19837F").ss(2,1,1).p("Aw3FJINmqjIUJK1g");
	this.shape_183.setTransform(82.05,1.75);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#19837F").ss(2,1,1).p("AwwFDINpqcIT4Kzg");
	this.shape_184.setTransform(82.125,2.225);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("#19837F").ss(2,1,1).p("AwqE9INtqVIToKxg");
	this.shape_185.setTransform(82.175,2.65);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#19837F").ss(2,1,1).p("AwjE2INwqOITXKxg");
	this.shape_186.setTransform(82.225,3.1);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("#19837F").ss(2,1,1).p("AwdEvIN0qGITHKvg");
	this.shape_187.setTransform(82.275,3.575);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#19837F").ss(2,1,1).p("AwWEpIN3p/IS2Ktg");
	this.shape_188.setTransform(82.325,4);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#19837F").ss(2,1,1).p("AwQEiIN7p3ISmKrg");
	this.shape_189.setTransform(82.375,4.475);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#19837F").ss(2,1,1).p("AwJEcIN+pxISVKrg");
	this.shape_190.setTransform(82.45,4.925);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("#19837F").ss(2,1,1).p("AwDEWIOCpqISFKpg");
	this.shape_191.setTransform(82.5,5.35);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#19837F").ss(2,1,1).p("Av8EPIOFpiIR0Kng");
	this.shape_192.setTransform(82.55,5.825);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("#19837F").ss(2,1,1).p("Av2EJIOIpcIRlKng");
	this.shape_193.setTransform(82.6,6.275);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#19837F").ss(2,1,1).p("AvvECIOMpUIRTKlg");
	this.shape_194.setTransform(82.65,6.725);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("#19837F").ss(2,1,1).p("AvoD8IOPpNIRCKjg");
	this.shape_195.setTransform(82.675,7.175);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#19837F").ss(2,1,1).p("AviD1IOTpGIQyKjg");
	this.shape_196.setTransform(82.725,7.625);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("#19837F").ss(2,1,1).p("AvbDvIOWo/IQhKhg");
	this.shape_197.setTransform(82.8,8.075);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#19837F").ss(2,1,1).p("AvUDpIOZo4IQRKfg");
	this.shape_198.setTransform(82.85,8.525);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("#19837F").ss(2,1,1).p("AvODiIOcoxIQBKfg");
	this.shape_199.setTransform(82.9,9);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#19837F").ss(2,1,1).p("AvIDcIOhoqIPwKdg");
	this.shape_200.setTransform(82.95,9.425);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("#19837F").ss(2,1,1).p("AvBDVIOkoiIPfKbg");
	this.shape_201.setTransform(83,9.875);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#19837F").ss(2,1,1).p("Au7DPIOoocIPPKbg");
	this.shape_202.setTransform(83.05,10.35);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#19837F").ss(2,1,1).p("Au0DIIOqoUIO/KZg");
	this.shape_203.setTransform(83.125,10.775);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#19837F").ss(2,1,1).p("AutDCIOtoNIOuKXg");
	this.shape_204.setTransform(83.175,11.225);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("#19837F").ss(2,1,1).p("AunC8IOwoHIOfKXg");
	this.shape_205.setTransform(83.225,11.7);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#19837F").ss(2,1,1).p("AugC1IOzn/IOOKVg");
	this.shape_206.setTransform(83.275,12.15);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("#19837F").ss(2,1,1).p("AuaCvIO3n4IN+KTg");
	this.shape_207.setTransform(83.325,12.6);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#19837F").ss(2,1,1).p("AuTCoIO6nxINtKTg");
	this.shape_208.setTransform(83.375,13.05);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("#19837F").ss(2,1,1).p("AuNCiIO+nqINdKRg");
	this.shape_209.setTransform(83.45,13.5);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#19837F").ss(2,1,1).p("AuGCbIPBniINMKPg");
	this.shape_210.setTransform(83.5,13.95);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("#19837F").ss(2,1,1).p("At/CVIPEncIM7KPg");
	this.shape_211.setTransform(83.55,14.4);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#19837F").ss(2,1,1).p("At5COIPInUIMrKNg");
	this.shape_212.setTransform(83.6,14.875);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("#19837F").ss(2,1,1).p("AtzCIIPMnNIMbKLg");
	this.shape_213.setTransform(83.65,15.3);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#19837F").ss(2,1,1).p("AtsCCIPPnHIMKKLg");
	this.shape_214.setTransform(83.7,15.75);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f().s("#19837F").ss(2,1,1).p("AtmB7IPTm/IL6KJg");
	this.shape_215.setTransform(83.75,16.225);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#19837F").ss(2,1,1).p("AtfB1IPWm4ILpKHg");
	this.shape_216.setTransform(83.825,16.65);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("#19837F").ss(2,1,1).p("AtYBuIPZmwILYKFg");
	this.shape_217.setTransform(83.875,17.125);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#19837F").ss(2,1,1).p("AtSBoIPdmqILIKFg");
	this.shape_218.setTransform(83.925,17.575);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("#19837F").ss(2,1,1).p("AtLBiIPgmjIK3KDg");
	this.shape_219.setTransform(83.975,18);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#19837F").ss(2,1,1).p("AtFBbIPkmbIKnKBg");
	this.shape_220.setTransform(84.025,18.475);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("#19837F").ss(2,1,1).p("As+BUIPnmUIKWKBg");
	this.shape_221.setTransform(84.075,18.925);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#19837F").ss(2,1,1).p("As3BOIPqmNIKGJ/g");
	this.shape_222.setTransform(84.15,19.375);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("#19837F").ss(2,1,1).p("AsxBHIPtmFIJ2J9g");
	this.shape_223.setTransform(84.2,19.825);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#19837F").ss(2,1,1).p("AsrBBIPxl/IJmJ9g");
	this.shape_224.setTransform(84.25,20.275);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#19837F").ss(2,1,1).p("AskA7IP1l4IJUJ7g");
	this.shape_225.setTransform(84.275,20.725);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#19837F").ss(2,1,1).p("AsdA0IP4lwIJDJ5g");
	this.shape_226.setTransform(84.325,21.175);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f().s("#19837F").ss(2,1,1).p("AsXAuIP8lqIIzJ5g");
	this.shape_227.setTransform(84.375,21.65);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#19837F").ss(2,1,1).p("AsQAnIP/liIIiJ3g");
	this.shape_228.setTransform(84.45,22.075);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("#19837F").ss(2,1,1).p("AsKAhIQClbIITJ1g");
	this.shape_229.setTransform(84.5,22.525);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#19837F").ss(2,1,1).p("AsDAaIQGlUIIBJ1g");
	this.shape_230.setTransform(84.55,23);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f().s("#19837F").ss(2,1,1).p("Ar9AUIQJlNIHyJzg");
	this.shape_231.setTransform(84.6,23.425);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("#19837F").ss(2,1,1).p("Ar2ANIQMlFIHhJxg");
	this.shape_232.setTransform(84.65,23.9);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("#19837F").ss(2,1,1).p("ArvAHIQQk/IHQJxg");
	this.shape_233.setTransform(84.7,24.35);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f().s("#19837F").ss(2,1,1).p("ArpABIQTk4IHAJvg");
	this.shape_234.setTransform(84.75,24.775);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f().s("#19837F").ss(2,1,1).p("ArigFIQWkxIGvJtg");
	this.shape_235.setTransform(84.825,25.25);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f().s("#19837F").ss(2,1,1).p("ArcgMIQakqIGfJtg");
	this.shape_236.setTransform(84.875,25.7);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f().s("#19837F").ss(2,1,1).p("ArVgRIQdkkIGOJrg");
	this.shape_237.setTransform(84.925,26.125);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("#19837F").ss(2,1,1).p("ArPgYIQhkcIF+Jpg");
	this.shape_238.setTransform(84.975,26.6);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f().s("#19837F").ss(2,1,1).p("ArIgfIQkkVIFtJpg");
	this.shape_239.setTransform(85.025,27.05);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("#19837F").ss(2,1,1).p("ArCglIQokOIFdJng");
	this.shape_240.setTransform(85.075,27.5);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("#19837F").ss(2,1,1).p("Aq7grIQrkHIFMJlg");
	this.shape_241.setTransform(85.15,27.95);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("#19837F").ss(2,1,1).p("Aq1gyIQvkAIE8Jlg");
	this.shape_242.setTransform(85.2,28.4);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f().s("#19837F").ss(2,1,1).p("Aqug4IQyj5IErJjg");
	this.shape_243.setTransform(85.25,28.85);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f().s("#19837F").ss(2,1,1).p("Aqog+IQ2jyIEbJhg");
	this.shape_244.setTransform(85.3,29.3);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f().s("#19837F").ss(2,1,1).p("AqhhFIQ5jqIEKJfg");
	this.shape_245.setTransform(85.35,29.775);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("#19837F").ss(2,1,1).p("AqbhLIQ9jkID6Jfg");
	this.shape_246.setTransform(85.4,30.2);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f().s("#19837F").ss(2,1,1).p("AqUhSIRAjcIDpJdg");
	this.shape_247.setTransform(85.45,30.65);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f().s("#19837F").ss(2,1,1).p("AqNhZIRDjUIDYJbg");
	this.shape_248.setTransform(85.525,31.125);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("#19837F").ss(2,1,1).p("AqHhfIRHjOIDIJbg");
	this.shape_249.setTransform(85.575,31.55);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f().s("#19837F").ss(2,1,1).p("AqAhmIRKjGIC3JZg");
	this.shape_250.setTransform(85.625,32.025);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("#19837F").ss(2,1,1).p("Ap6hsIROi/ICnJXg");
	this.shape_251.setTransform(85.675,32.475);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#19837F").ss(2,1,1).p("ApzhyIRRi5ICWJXg");
	this.shape_252.setTransform(85.725,32.9);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("#19837F").ss(2,1,1).p("Apth5IRVixICGJVg");
	this.shape_253.setTransform(85.775,33.375);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("#19837F").ss(2,1,1).p("Apmh/IRYiqIB1JTg");
	this.shape_254.setTransform(85.825,33.825);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f().s("#19837F").ss(2,1,1).p("ApfiGIRbiiIBkJSg");
	this.shape_255.setTransform(85.875,34.3);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f().s("#19837F").ss(2,1,1).p("ApZiMIRficIBUJRg");
	this.shape_256.setTransform(85.925,34.725);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f().s("#19837F").ss(2,1,1).p("ApSiSIRiiVIBDJPg");
	this.shape_257.setTransform(85.975,35.175);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("#19837F").ss(2,1,1).p("ApMiZIRmiOIAzJPg");
	this.shape_258.setTransform(86.025,35.65);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("#19837F").ss(2,1,1).p("ApFifIRpiHIAiJNg");
	this.shape_259.setTransform(86.075,36.075);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("#19837F").ss(2,1,1).p("Ao+imIRsh/IASJLg");
	this.shape_260.setTransform(86.15,36.55);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("#19837F").ss(2,1,1).p("Ao4itIRvh4IACJKg");
	this.shape_261.setTransform(86.2,37);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("#19837F").ss(2,1,1).p("Ao5izIRzhxIgPJJg");
	this.shape_262.setTransform(87,37.425);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("#19837F").ss(2,1,1).p("Ao7i6IR3hpIggJHg");
	this.shape_263.setTransform(87.875,37.9);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#19837F").ss(2,1,1).p("Ao9jAIR7hjIgwJHg");
	this.shape_264.setTransform(88.75,38.35);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f().s("#19837F").ss(2,1,1).p("Ao+jGIR9hcIhAJFg");
	this.shape_265.setTransform(89.625,38.8);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f().s("#19837F").ss(2,1,1).p("ApAjNISBhUIhRJDg");
	this.shape_266.setTransform(90.5,39.25);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f().s("#19837F").ss(2,1,1).p("ApCjTISFhOIhiJDg");
	this.shape_267.setTransform(91.4,39.7);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f().s("#19837F").ss(2,1,1).p("ApDjZISHhHIhyJBg");
	this.shape_268.setTransform(92.275,40.15);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f().s("#19837F").ss(2,1,1).p("ApFjgISLg/IiCI/g");
	this.shape_269.setTransform(93.15,40.6);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f().s("#19837F").ss(2,1,1).p("ApHjnISPg3IiTI9g");
	this.shape_270.setTransform(94.025,41.075);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f().s("#19837F").ss(2,1,1).p("ApIjtISSgxIikI9g");
	this.shape_271.setTransform(94.9,41.5);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f().s("#19837F").ss(2,1,1).p("ApKjzISVgqIi0I7g");
	this.shape_272.setTransform(95.775,41.95);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f().s("#19837F").ss(2,1,1).p("ApMj6ISZgiIjFI5g");
	this.shape_273.setTransform(96.675,42.425);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f().s("#19837F").ss(2,1,1).p("ApOkAISdgcIjVI4g");
	this.shape_274.setTransform(97.55,42.85);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f().s("#19837F").ss(2,1,1).p("ApPkHISfgUIjlI3g");
	this.shape_275.setTransform(98.425,43.3);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f().s("#19837F").ss(2,1,1).p("ApRkNISjgNIj2I1g");
	this.shape_276.setTransform(99.3,43.775);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f().s("#19837F").ss(2,1,1).p("ApTkTISngHIkHI1g");
	this.shape_277.setTransform(100.175,44.2);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f().s("#19837F").ss(2,1,1).p("ApVkZISrABIkYIyg");
	this.shape_278.setTransform(101.05,44.625);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f().s("#19837F").ss(2,1,1).p("ApWkcIStAIIknIxg");
	this.shape_279.setTransform(101.925,44.725);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f().s("#19837F").ss(2,1,1).p("ApYkfISxAPIk4Iwg");
	this.shape_280.setTransform(102.825,44.8);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#19837F").ss(2,1,1).p("ApZkiIS0AWIlJIvg");
	this.shape_281.setTransform(103.7,44.9);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f().s("#19837F").ss(2,1,1).p("ApbklIS3AdIlZIug");
	this.shape_282.setTransform(104.575,45);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f().s("#19837F").ss(2,1,1).p("ApdkoIS7AlIlqIsg");
	this.shape_283.setTransform(105.45,45.075);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f().s("#19837F").ss(2,1,1).p("ApfkrIS/AsIl7Irg");
	this.shape_284.setTransform(106.325,45.2);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f().s("#19837F").ss(2,1,1).p("AphktITDAyImLIqg");
	this.shape_285.setTransform(107.2,45.3);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f().s("#19837F").ss(2,1,1).p("ApikwITFA6ImbIng");
	this.shape_286.setTransform(108.1,45.375);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f().s("#19837F").ss(2,1,1).p("ApkkzITJBBImsImg");
	this.shape_287.setTransform(108.975,45.475);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f().s("#19837F").ss(2,1,1).p("Apmk2ITNBIIm9Ilg");
	this.shape_288.setTransform(109.85,45.575);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f().s("#19837F").ss(2,1,1).p("Apnk5ITPBPInNIkg");
	this.shape_289.setTransform(110.725,45.65);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f().s("#19837F").ss(2,1,1).p("Appk8ITTBWIndIjg");
	this.shape_290.setTransform(111.6,45.75);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f().s("#19837F").ss(2,1,1).p("Aprk/ITXBeInuIhg");
	this.shape_291.setTransform(112.475,45.875);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f().s("#19837F").ss(2,1,1).p("ApslCITZBlIn+Igg");
	this.shape_292.setTransform(113.375,45.95);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f().s("#19837F").ss(2,1,1).p("ApulFITdBtIoPIeg");
	this.shape_293.setTransform(114.25,46.05);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f().s("#19837F").ss(2,1,1).p("ApwlHIThBzIogIdg");
	this.shape_294.setTransform(115.125,46.15);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f().s("#19837F").ss(2,1,1).p("ApylKITlB6IowIbg");
	this.shape_295.setTransform(116,46.225);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f().s("#19837F").ss(2,1,1).p("ApzlNITnCBIpAIag");
	this.shape_296.setTransform(116.875,46.325);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f().s("#19837F").ss(2,1,1).p("Ap1lQITrCIIpRIZg");
	this.shape_297.setTransform(117.75,46.45);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f().s("#19837F").ss(2,1,1).p("Ap3lTITvCQIpiIXg");
	this.shape_298.setTransform(118.625,46.525);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f().s("#19837F").ss(2,1,1).p("Ap4lWITxCXIpyIWg");
	this.shape_299.setTransform(119.525,46.625);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#19837F").ss(2,1,1).p("Ap6lZIT1CeIqCIVg");
	this.shape_300.setTransform(120.4,46.725);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#19837F").ss(2,1,1).p("Ap8lcIT5ClIqSIUg");
	this.shape_301.setTransform(121.275,46.8);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f().s("#19837F").ss(2,1,1).p("Ap+lfIT9CsIqjITg");
	this.shape_302.setTransform(122.15,46.9);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#19837F").ss(2,1,1).p("Ap/liIT/C0IqzIRg");
	this.shape_303.setTransform(123.025,47);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f().s("#19837F").ss(2,1,1).p("AqBlkIUDC6IrEIPg");
	this.shape_304.setTransform(123.9,47.125);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f().s("#19837F").ss(2,1,1).p("AqDlnIUHDBIrVIOg");
	this.shape_305.setTransform(124.8,47.2);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f().s("#19837F").ss(2,1,1).p("AqElqIUJDJIrkIMg");
	this.shape_306.setTransform(125.675,47.3);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f().s("#19837F").ss(2,1,1).p("AqGltIUNDQIr1ILg");
	this.shape_307.setTransform(126.55,47.4);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f().s("#19837F").ss(2,1,1).p("AqIlwIURDXIsGIKg");
	this.shape_308.setTransform(127.425,47.475);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f().s("#19837F").ss(2,1,1).p("AqKlzIUUDeIsWIJg");
	this.shape_309.setTransform(128.3,47.575);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f().s("#19837F").ss(2,1,1).p("AqLl2IUXDlIsmIIg");
	this.shape_310.setTransform(129.175,47.675);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f().s("#19837F").ss(2,1,1).p("AqNl4IUbDsIs3IFg");
	this.shape_311.setTransform(130.075,47.775);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f().s("#19837F").ss(2,1,1).p("AqOl7IUeDzItIIEg");
	this.shape_312.setTransform(130.95,47.875);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f().s("#19837F").ss(2,1,1).p("AqQl+IUhD6ItYIDg");
	this.shape_313.setTransform(131.825,47.975);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f().s("#19837F").ss(2,1,1).p("AqSmBIUlEBItpICg");
	this.shape_314.setTransform(132.7,48.05);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f().s("#19837F").ss(2,1,1).p("AqUmEIUpEJIt6IAg");
	this.shape_315.setTransform(133.575,48.15);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f().s("#19837F").ss(2,1,1).p("AqVmHIUsEQIuKH/g");
	this.shape_316.setTransform(134.45,48.25);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f().s("#19837F").ss(2,1,1).p("AqXmKIUvEXIuaH9g");
	this.shape_317.setTransform(135.325,48.35);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f().s("#19837F").ss(2,1,1).p("AqZmNIUzEeIurH9g");
	this.shape_318.setTransform(136.225,48.45);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f().s("#19837F").ss(2,1,1).p("AqbmQIU3ElIu8H8g");
	this.shape_319.setTransform(137.1,48.55);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f().s("#19837F").ss(2,1,1).p("AqcmSIU5EsIvMH5g");
	this.shape_320.setTransform(137.975,48.625);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f().s("#19837F").ss(2,1,1).p("AqemVIU9EzIvcH4g");
	this.shape_321.setTransform(138.85,48.725);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f().s("#19837F").ss(2,1,1).p("AqgmYIVBE6IvtH3g");
	this.shape_322.setTransform(139.725,48.825);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f().s("#19837F").ss(2,1,1).p("AqimbIVEFCIv9H1g");
	this.shape_323.setTransform(140.6,48.9);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f().s("#19837F").ss(2,1,1).p("AqjmeIVHFJIwOH0g");
	this.shape_324.setTransform(141.5,49.025);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f().s("#19837F").ss(2,1,1).p("AqlmhIVLFQIwfHzg");
	this.shape_325.setTransform(142.375,49.125);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f().s("#19837F").ss(2,1,1).p("AqnmkIVOFXIwvHyg");
	this.shape_326.setTransform(143.25,49.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_214}]},1).to({state:[{t:this.shape_215}]},1).to({state:[{t:this.shape_216}]},1).to({state:[{t:this.shape_217}]},1).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).to({state:[{t:this.shape_250}]},1).to({state:[{t:this.shape_251}]},1).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_263}]},1).to({state:[{t:this.shape_264}]},1).to({state:[{t:this.shape_265}]},1).to({state:[{t:this.shape_266}]},1).to({state:[{t:this.shape_267}]},1).to({state:[{t:this.shape_268}]},1).to({state:[{t:this.shape_269}]},1).to({state:[{t:this.shape_270}]},1).to({state:[{t:this.shape_271}]},1).to({state:[{t:this.shape_272}]},1).to({state:[{t:this.shape_273}]},1).to({state:[{t:this.shape_274}]},1).to({state:[{t:this.shape_275}]},1).to({state:[{t:this.shape_276}]},1).to({state:[{t:this.shape_277}]},1).to({state:[{t:this.shape_278}]},1).to({state:[{t:this.shape_279}]},1).to({state:[{t:this.shape_280}]},1).to({state:[{t:this.shape_281}]},1).to({state:[{t:this.shape_282}]},1).to({state:[{t:this.shape_283}]},1).to({state:[{t:this.shape_284}]},1).to({state:[{t:this.shape_285}]},1).to({state:[{t:this.shape_286}]},1).to({state:[{t:this.shape_287}]},1).to({state:[{t:this.shape_288}]},1).to({state:[{t:this.shape_289}]},1).to({state:[{t:this.shape_290}]},1).to({state:[{t:this.shape_291}]},1).to({state:[{t:this.shape_292}]},1).to({state:[{t:this.shape_293}]},1).to({state:[{t:this.shape_294}]},1).to({state:[{t:this.shape_295}]},1).to({state:[{t:this.shape_296}]},1).to({state:[{t:this.shape_297}]},1).to({state:[{t:this.shape_298}]},1).to({state:[{t:this.shape_299}]},1).to({state:[{t:this.shape_300}]},1).to({state:[{t:this.shape_301}]},1).to({state:[{t:this.shape_302}]},1).to({state:[{t:this.shape_303}]},1).to({state:[{t:this.shape_304}]},1).to({state:[{t:this.shape_305}]},1).to({state:[{t:this.shape_306}]},1).to({state:[{t:this.shape_307}]},1).to({state:[{t:this.shape_308}]},1).to({state:[{t:this.shape_309}]},1).to({state:[{t:this.shape_310}]},1).to({state:[{t:this.shape_311}]},1).to({state:[{t:this.shape_312}]},1).to({state:[{t:this.shape_313}]},1).to({state:[{t:this.shape_314}]},1).to({state:[{t:this.shape_315}]},1).to({state:[{t:this.shape_316}]},1).to({state:[{t:this.shape_317}]},1).to({state:[{t:this.shape_318}]},1).to({state:[{t:this.shape_319}]},1).to({state:[{t:this.shape_320}]},1).to({state:[{t:this.shape_321}]},1).to({state:[{t:this.shape_322}]},1).to({state:[{t:this.shape_323}]},1).to({state:[{t:this.shape_324}]},1).to({state:[{t:this.shape_325}]},1).to({state:[{t:this.shape_326}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_1__копия_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#19837F").ss(2,1,1).p("AwBj4MAgDAAAIw/Hwg");
	this.shape.setTransform(109.625,66.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#19837F").ss(2,1,1).p("Av+j4If9gFIwzH7g");
	this.shape_1.setTransform(108.8,66.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#19837F").ss(2,1,1).p("Av7j3If3gMIwnIHg");
	this.shape_2.setTransform(107.95,66.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#19837F").ss(2,1,1).p("Av4j4IfxgRIwcITg");
	this.shape_3.setTransform(107.125,67);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#19837F").ss(2,1,1).p("Av1j3IfrgYIwQIfg");
	this.shape_4.setTransform(106.275,67.075);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#19837F").ss(2,1,1).p("Avyj4IflgdIwEIrg");
	this.shape_5.setTransform(105.45,67.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#19837F").ss(2,1,1).p("Avvj3IffgkIv4I3g");
	this.shape_6.setTransform(104.6,67.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#19837F").ss(2,1,1).p("Avrj3IfXgqIvsJDg");
	this.shape_7.setTransform(103.775,67.275);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#19837F").ss(2,1,1).p("Avoj3IfRgwIvgJPg");
	this.shape_8.setTransform(102.925,67.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#19837F").ss(2,1,1).p("Avlj3IfLg2IvVJag");
	this.shape_9.setTransform(102.1,67.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#19837F").ss(2,1,1).p("Avij3IfFg7IvIJlg");
	this.shape_10.setTransform(101.225,67.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#19837F").ss(2,1,1).p("Avfj3Ie/hBIu9Jxg");
	this.shape_11.setTransform(100.4,67.525);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#19837F").ss(2,1,1).p("Avcj3Ie5hHIuwJ9g");
	this.shape_12.setTransform(99.55,67.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#19837F").ss(2,1,1).p("AvYj3IexhNIukKJg");
	this.shape_13.setTransform(98.725,67.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#19837F").ss(2,1,1).p("AvVj3IerhTIuYKVg");
	this.shape_14.setTransform(97.875,67.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#19837F").ss(2,1,1).p("AvSj3IelhZIuMKhg");
	this.shape_15.setTransform(97.05,67.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#19837F").ss(2,1,1).p("AvPj3IefhfIuBKtg");
	this.shape_16.setTransform(96.225,67.875);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#19837F").ss(2,1,1).p("AvMj3IeZhlIt1K4g");
	this.shape_17.setTransform(95.375,67.95);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#19837F").ss(2,1,1).p("AvJj3IeThrItpLFg");
	this.shape_18.setTransform(94.55,68);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#19837F").ss(2,1,1).p("AvGj2IeMhyItcLRg");
	this.shape_19.setTransform(93.7,68.1);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#19837F").ss(2,1,1).p("AvCj3IeFh2ItQLbg");
	this.shape_20.setTransform(92.875,68.175);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#19837F").ss(2,1,1).p("Au/j2Id/h9ItELng");
	this.shape_21.setTransform(92.025,68.225);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#19837F").ss(2,1,1).p("Au8j3Id5iCIs4Lzg");
	this.shape_22.setTransform(91.2,68.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#19837F").ss(2,1,1).p("Au5j2IdziJIssL/g");
	this.shape_23.setTransform(90.35,68.35);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#19837F").ss(2,1,1).p("Au2j2IdtiPIshMLg");
	this.shape_24.setTransform(89.525,68.425);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#19837F").ss(2,1,1).p("Auzj2IdniVIsVMXg");
	this.shape_25.setTransform(88.675,68.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#19837F").ss(2,1,1).p("Auwj2IdhibIsJMjg");
	this.shape_26.setTransform(87.85,68.55);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#19837F").ss(2,1,1).p("Autj2IdbihIr9Mvg");
	this.shape_27.setTransform(87,68.65);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#19837F").ss(2,1,1).p("Aupj2IdTinIrwM6g");
	this.shape_28.setTransform(86.175,68.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#19837F").ss(2,1,1).p("Aumj2IdNisIrkNFg");
	this.shape_29.setTransform(85.325,68.775);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#19837F").ss(2,1,1).p("Aujj2IdHiyIrZNRg");
	this.shape_30.setTransform(84.5,68.85);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#19837F").ss(2,1,1).p("Augj2IdBi4IrMNdg");
	this.shape_31.setTransform(83.65,68.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#19837F").ss(2,1,1).p("Audj2Ic7i+IrANpg");
	this.shape_32.setTransform(82.8,68.975);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#19837F").ss(2,1,1).p("AuZj2IczjEIq0N1g");
	this.shape_33.setTransform(81.975,69.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#19837F").ss(2,1,1).p("AuWj2IctjKIqoOBg");
	this.shape_34.setTransform(81.125,69.125);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#19837F").ss(2,1,1).p("AuTj2IcnjQIqcONg");
	this.shape_35.setTransform(80.3,69.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#19837F").ss(2,1,1).p("AuQj2IchjWIqQOZg");
	this.shape_36.setTransform(79.45,69.25);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#19837F").ss(2,1,1).p("AuNj2IcbjbIqEOjg");
	this.shape_37.setTransform(78.625,69.325);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#19837F").ss(2,1,1).p("AuKj1IcVjiIp4Ovg");
	this.shape_38.setTransform(77.775,69.375);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#19837F").ss(2,1,1).p("AuHj2IcPjnIptO7g");
	this.shape_39.setTransform(76.95,69.45);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#19837F").ss(2,1,1).p("AuEj1IcJjuIphPHg");
	this.shape_40.setTransform(76.1,69.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#19837F").ss(2,1,1).p("AuAj1IcBj0IpUPTg");
	this.shape_41.setTransform(75.275,69.575);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#19837F").ss(2,1,1).p("At9j1Ib7j6IpIPfg");
	this.shape_42.setTransform(74.425,69.675);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#19837F").ss(2,1,1).p("At6j1Ib1kAIo8Prg");
	this.shape_43.setTransform(73.6,69.725);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#19837F").ss(2,1,1).p("At3j1IbvkGIowP3g");
	this.shape_44.setTransform(72.75,69.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#19837F").ss(2,1,1).p("At0j1IbpkMIokQDg");
	this.shape_45.setTransform(71.925,69.85);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#19837F").ss(2,1,1).p("Atwj1IbikRIoZQNg");
	this.shape_46.setTransform(71.1,69.925);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#19837F").ss(2,1,1).p("Atuj1IbdkXIoNQZg");
	this.shape_47.setTransform(70.25,69.975);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#19837F").ss(2,1,1).p("Atqj1IbVkdIoAQlg");
	this.shape_48.setTransform(69.425,70.05);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#19837F").ss(2,1,1).p("Atnj1IbPkjIn0Qxg");
	this.shape_49.setTransform(68.575,70.15);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#19837F").ss(2,1,1).p("Atkj1IbJkpInoQ9g");
	this.shape_50.setTransform(67.75,70.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#19837F").ss(2,1,1).p("Athj1IbDkvIncRJg");
	this.shape_51.setTransform(66.875,70.275);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#19837F").ss(2,1,1).p("Atej1Ia9k1InRRVg");
	this.shape_52.setTransform(66.05,70.325);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#19837F").ss(2,1,1).p("Atbj1Ia3k7InERhg");
	this.shape_53.setTransform(65.2,70.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#19837F").ss(2,1,1).p("AtXj1IavlAIm4Rrg");
	this.shape_54.setTransform(64.375,70.475);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#19837F").ss(2,1,1).p("AtUj0IaplHImsR3g");
	this.shape_55.setTransform(63.525,70.525);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#19837F").ss(2,1,1).p("AtRj1IajlMImgSDg");
	this.shape_56.setTransform(62.7,70.6);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#19837F").ss(2,1,1).p("AtOj0IadlTImUSPg");
	this.shape_57.setTransform(61.85,70.675);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#19837F").ss(2,1,1).p("AtLj0IaXlZImISbg");
	this.shape_58.setTransform(61.025,70.75);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#19837F").ss(2,1,1).p("AtIj0IaRlfIl8Sng");
	this.shape_59.setTransform(60.175,70.8);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#19837F").ss(2,1,1).p("AtFj0IaLllIlwSzg");
	this.shape_60.setTransform(59.35,70.875);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#19837F").ss(2,1,1).p("As9jcIZ7l7IlaSvg");
	this.shape_61.setTransform(58.3,69.45);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#19837F").ss(2,1,1).p("As2jDIZtmTIlEStg");
	this.shape_62.setTransform(57.275,68);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#19837F").ss(2,1,1).p("AsuirIZdmpIksSpg");
	this.shape_63.setTransform(56.225,66.575);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#19837F").ss(2,1,1).p("AsniSIZPnAIkWSlg");
	this.shape_64.setTransform(55.175,65.125);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#19837F").ss(2,1,1).p("Asfh6IY/nXIkASjg");
	this.shape_65.setTransform(54.15,63.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#19837F").ss(2,1,1).p("AsYhhIYxnuIjqSfg");
	this.shape_66.setTransform(53.125,62.275);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#19837F").ss(2,1,1).p("AsQhJIYhoEIjTSbg");
	this.shape_67.setTransform(52.075,60.825);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#19837F").ss(2,1,1).p("AsJgxIYTobIi9SZg");
	this.shape_68.setTransform(51.025,59.425);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#19837F").ss(2,1,1).p("AsBgYIYDoyIilSVg");
	this.shape_69.setTransform(49.975,58);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#19837F").ss(2,1,1).p("Ar6AAIX1pJIiPSTg");
	this.shape_70.setTransform(48.95,56.55);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#19837F").ss(2,1,1).p("ArzAYIXnpfIh6SPg");
	this.shape_71.setTransform(47.9,55.125);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#19837F").ss(2,1,1).p("ArrAwIXXp1IhjSLg");
	this.shape_72.setTransform(46.85,53.675);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#19837F").ss(2,1,1).p("ArjBJIXHqNIhMSJg");
	this.shape_73.setTransform(45.825,52.25);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#19837F").ss(2,1,1).p("ArcBhIW5qjIg1SFg");
	this.shape_74.setTransform(44.8,50.825);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#19837F").ss(2,1,1).p("ArVB6IWrq6IgfSBg");
	this.shape_75.setTransform(43.75,49.375);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#19837F").ss(2,1,1).p("ArNCSIWbrRIgIR/g");
	this.shape_76.setTransform(42.7,47.95);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#19837F").ss(2,1,1).p("ArNCqIWNrnIAOR7g");
	this.shape_77.setTransform(42.35,46.5);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#19837F").ss(2,1,1).p("ArQDDIV9r+IAkR3g");
	this.shape_78.setTransform(42.425,45.075);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#19837F").ss(2,1,1).p("ArUDbIVvsVIA6R1g");
	this.shape_79.setTransform(42.5,43.65);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#19837F").ss(2,1,1).p("ArYD0IVgssIBRRxg");
	this.shape_80.setTransform(42.6,42.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#19837F").ss(2,1,1).p("ArcEMIVRtCIBoRtg");
	this.shape_81.setTransform(42.675,40.775);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#19837F").ss(2,1,1).p("ArfElIVBtaIB+Rrg");
	this.shape_82.setTransform(42.775,39.35);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#19837F").ss(2,1,1).p("ArjE9IUztwICURng");
	this.shape_83.setTransform(42.85,37.925);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#19837F").ss(2,1,1).p("ArnFWIUkuIICrRlg");
	this.shape_84.setTransform(42.925,36.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#19837F").ss(2,1,1).p("ArrFuIUVueIDCRhg");
	this.shape_85.setTransform(43.025,35.05);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#19837F").ss(2,1,1).p("ArvGHIUHu1IDYRdg");
	this.shape_86.setTransform(43.1,33.625);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#19837F").ss(2,1,1).p("AryGfIT3vMIDuRbg");
	this.shape_87.setTransform(43.175,32.2);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#19837F").ss(2,1,1).p("Ar2G4ITovjIEFRXg");
	this.shape_88.setTransform(43.25,30.75);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#19837F").ss(2,1,1).p("Ar6HQITav5IEbRTg");
	this.shape_89.setTransform(43.325,29.325);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#19837F").ss(2,1,1).p("Ar+HoITLwQIEyRRg");
	this.shape_90.setTransform(43.45,27.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#19837F").ss(2,1,1).p("AsBIBIS7wnIFIRNg");
	this.shape_91.setTransform(43.525,26.45);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#19837F").ss(2,1,1).p("AsFIZIStw9IFeRJg");
	this.shape_92.setTransform(43.6,25.025);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#19837F").ss(2,1,1).p("AsJIrISexVIF1RHg");
	this.shape_93.setTransform(43.675,24.275);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#19837F").ss(2,1,1).p("AsNI2ISPxrIGMRDg");
	this.shape_94.setTransform(43.75,24.15);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#19837F").ss(2,1,1).p("AsQJCIR/yDIGiRAg");
	this.shape_95.setTransform(43.825,24.05);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#19837F").ss(2,1,1).p("AsUJNIRxyZIG4Q9g");
	this.shape_96.setTransform(43.925,23.9);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#19837F").ss(2,1,1).p("AsYJYIRiyvIHPQ5g");
	this.shape_97.setTransform(44,23.775);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#19837F").ss(2,1,1).p("AscJkIRTzHIHmQ3g");
	this.shape_98.setTransform(44.075,23.625);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#19837F").ss(2,1,1).p("AsfJvIRDzdIH8Qzg");
	this.shape_99.setTransform(44.175,23.525);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#19837F").ss(2,1,1).p("AsjJ7IQ1z1IISQwg");
	this.shape_100.setTransform(44.25,23.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#19837F").ss(2,1,1).p("AsnKGIQm0LIIpQsg");
	this.shape_101.setTransform(44.35,23.25);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#19837F").ss(2,1,1).p("AsrKRIQX0hIJAQpg");
	this.shape_102.setTransform(44.425,23.125);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#19837F").ss(2,1,1).p("AsvKdIQJ05IJWQmg");
	this.shape_103.setTransform(44.5,23.025);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#19837F").ss(2,1,1).p("AsyKoIP51PIJsQig");
	this.shape_104.setTransform(44.575,22.875);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#19837F").ss(2,1,1).p("As2K0IPq1nIKDQgg");
	this.shape_105.setTransform(44.65,22.75);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#19837F").ss(2,1,1).p("As6K/IPc19IKZQcg");
	this.shape_106.setTransform(44.725,22.6);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#19837F").ss(2,1,1).p("As+LLIPN2VIKwQZg");
	this.shape_107.setTransform(44.825,22.5);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#19837F").ss(2,1,1).p("AtBLWIO92rILGQVg");
	this.shape_108.setTransform(44.925,22.375);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#19837F").ss(2,1,1).p("AtFLhIOu3BILdQSg");
	this.shape_109.setTransform(45,22.225);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#19837F").ss(2,1,1).p("AtJLtIOg3ZILzQPg");
	this.shape_110.setTransform(45.075,22.1);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#19837F").ss(2,1,1).p("AtML4IOR3vIMJQLg");
	this.shape_111.setTransform(45.15,21.975);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#19837F").ss(2,1,1).p("AtQMEIOC4HIMfQJg");
	this.shape_112.setTransform(45.25,21.85);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#19837F").ss(2,1,1).p("AtUMPINz4dIM2QFg");
	this.shape_113.setTransform(45.325,21.725);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#19837F").ss(2,1,1).p("AtYMaINk4zINNQCg");
	this.shape_114.setTransform(45.4,21.575);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#19837F").ss(2,1,1).p("AtcMmINX5LINiP/g");
	this.shape_115.setTransform(45.475,21.475);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#19837F").ss(2,1,1).p("AtfMxINH5hIN4P7g");
	this.shape_116.setTransform(45.575,21.35);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#19837F").ss(2,1,1).p("AtjM9IM455IOPP4g");
	this.shape_117.setTransform(45.65,21.2);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#19837F").ss(2,1,1).p("AtnNIIMp6PIOmP1g");
	this.shape_118.setTransform(45.75,21.075);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#19837F").ss(2,1,1).p("AtrNUIMb6nIO8Pyg");
	this.shape_119.setTransform(45.825,20.95);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#19837F").ss(2,1,1).p("AhjteIPSPuI7dLPg");
	this.shape_120.setTransform(45.9,20.825);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#19837F").ss(2,1,1).p("AttNbIMS61IPJPsg");
	this.shape_121.setTransform(45.95,20.925);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#19837F").ss(2,1,1).p("AtrNWIMY6rIO/Ppg");
	this.shape_122.setTransform(45.975,21.025);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#19837F").ss(2,1,1).p("AtpNSIMe6jIO1Pmg");
	this.shape_123.setTransform(46.025,21.125);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#19837F").ss(2,1,1).p("AtnNOIMk6bIOrPkg");
	this.shape_124.setTransform(46.075,21.225);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#19837F").ss(2,1,1).p("AtlNKIMq6TIOhPig");
	this.shape_125.setTransform(46.125,21.35);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#19837F").ss(2,1,1).p("AtjNGIMx6LIOWPgg");
	this.shape_126.setTransform(46.15,21.425);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#19837F").ss(2,1,1).p("AthNCIM26DIONPdg");
	this.shape_127.setTransform(46.2,21.55);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#19837F").ss(2,1,1).p("AtfM9IM955IOCPag");
	this.shape_128.setTransform(46.25,21.65);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#19837F").ss(2,1,1).p("AtdM5INC5xIN5PYg");
	this.shape_129.setTransform(46.325,21.725);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#19837F").ss(2,1,1).p("AtcM1INJ5pINwPVg");
	this.shape_130.setTransform(46.35,21.85);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#19837F").ss(2,1,1).p("AtaMxINQ5hINlPTg");
	this.shape_131.setTransform(46.4,21.95);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#19837F").ss(2,1,1).p("AtYMtINW5ZINbPRg");
	this.shape_132.setTransform(46.45,22.05);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#19837F").ss(2,1,1).p("AtVMpINa5RINRPPg");
	this.shape_133.setTransform(46.5,22.15);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#19837F").ss(2,1,1).p("AtUMlINh5JINIPMg");
	this.shape_134.setTransform(46.525,22.25);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#19837F").ss(2,1,1).p("AtSMgINn4/IM+PJg");
	this.shape_135.setTransform(46.575,22.375);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#19837F").ss(2,1,1).p("AtQMcINt43IM0PHg");
	this.shape_136.setTransform(46.625,22.45);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#19837F").ss(2,1,1).p("AtOMYINz4vIMqPEg");
	this.shape_137.setTransform(46.675,22.55);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#19837F").ss(2,1,1).p("AtMMUIN64nIMfPCg");
	this.shape_138.setTransform(46.7,22.675);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#19837F").ss(2,1,1).p("AtKMQIN/4fIMWPAg");
	this.shape_139.setTransform(46.75,22.75);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#19837F").ss(2,1,1).p("AtIMLIOF4VIMMO8g");
	this.shape_140.setTransform(46.8,22.875);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#19837F").ss(2,1,1).p("AtGMHIOL4NIMCO6g");
	this.shape_141.setTransform(46.85,22.975);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#19837F").ss(2,1,1).p("AtEMDIOS4FIL3O4g");
	this.shape_142.setTransform(46.875,23.075);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#19837F").ss(2,1,1).p("AtCL/IOY39ILtO1g");
	this.shape_143.setTransform(46.925,23.175);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#19837F").ss(2,1,1).p("AtAL7IOe31ILjOzg");
	this.shape_144.setTransform(46.975,23.275);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#19837F").ss(2,1,1).p("As/L3IOl3tILaOxg");
	this.shape_145.setTransform(47,23.375);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#19837F").ss(2,1,1).p("As9LyIOr3jILQOug");
	this.shape_146.setTransform(47.075,23.475);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#19837F").ss(2,1,1).p("As7LuIOx3bILGOrg");
	this.shape_147.setTransform(47.125,23.575);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#19837F").ss(2,1,1).p("As5LqIO33TIK8Opg");
	this.shape_148.setTransform(47.175,23.7);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#19837F").ss(2,1,1).p("As3LmIO93LIKyOng");
	this.shape_149.setTransform(47.2,23.775);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#19837F").ss(2,1,1).p("As1LiIPD3DIKoOkg");
	this.shape_150.setTransform(47.25,23.875);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#19837F").ss(2,1,1).p("AszLeIPJ27IKeOig");
	this.shape_151.setTransform(47.3,24);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#19837F").ss(2,1,1).p("AsxLaIPP2zIKUOgg");
	this.shape_152.setTransform(47.35,24.1);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#19837F").ss(2,1,1).p("AsvLVIPV2pIKKOdg");
	this.shape_153.setTransform(47.375,24.175);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#19837F").ss(2,1,1).p("AstLRIPb2hIKAOag");
	this.shape_154.setTransform(47.425,24.3);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#19837F").ss(2,1,1).p("AsrLNIPh2ZIJ2OYg");
	this.shape_155.setTransform(47.475,24.4);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#19837F").ss(2,1,1).p("AspLJIPn2RIJsOVg");
	this.shape_156.setTransform(47.525,24.5);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#19837F").ss(2,1,1).p("AsoLFIPv2JIJiOUg");
	this.shape_157.setTransform(47.55,24.6);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#19837F").ss(2,1,1).p("AsmLBIP12BIJYORg");
	this.shape_158.setTransform(47.6,24.7);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#19837F").ss(2,1,1).p("AsjK8IP513IJOOOg");
	this.shape_159.setTransform(47.65,24.825);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#19837F").ss(2,1,1).p("AsiK4IQB1vIJEOMg");
	this.shape_160.setTransform(47.7,24.9);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#19837F").ss(2,1,1).p("AsgK0IQH1nII6OJg");
	this.shape_161.setTransform(47.725,25);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#19837F").ss(2,1,1).p("AseKwIQN1fIIwOHg");
	this.shape_162.setTransform(47.775,25.125);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#19837F").ss(2,1,1).p("AscKsIQT1XIImOFg");
	this.shape_163.setTransform(47.825,25.2);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#19837F").ss(2,1,1).p("AsaKnIQZ1NIIcOBg");
	this.shape_164.setTransform(47.9,25.325);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#19837F").ss(2,1,1).p("AsYKjIQf1FIISN/g");
	this.shape_165.setTransform(47.925,25.425);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#19837F").ss(2,1,1).p("AsWKfIQl09IIIN9g");
	this.shape_166.setTransform(47.975,25.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#19837F").ss(2,1,1).p("AsUKbIQr01IH+N6g");
	this.shape_167.setTransform(48.025,25.625);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#19837F").ss(2,1,1).p("AsTKXIQz0tIH0N4g");
	this.shape_168.setTransform(48.05,25.725);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#19837F").ss(2,1,1).p("AsRKTIQ50lIHqN2g");
	this.shape_169.setTransform(48.1,25.825);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#19837F").ss(2,1,1).p("AsPKOIQ/0bIHgNyg");
	this.shape_170.setTransform(48.15,25.925);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#19837F").ss(2,1,1).p("AsMKKIRE0TIHWNwg");
	this.shape_171.setTransform(48.2,26.025);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#19837F").ss(2,1,1).p("AsLKGIRL0LIHMNug");
	this.shape_172.setTransform(48.225,26.15);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#19837F").ss(2,1,1).p("AsJKCIRR0DIHCNsg");
	this.shape_173.setTransform(48.275,26.225);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#19837F").ss(2,1,1).p("AsHJ+IRXz7IG4Npg");
	this.shape_174.setTransform(48.325,26.325);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#19837F").ss(2,1,1).p("AsFJ6IRdzzIGuNng");
	this.shape_175.setTransform(48.375,26.45);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#19837F").ss(2,1,1).p("AsDJ1IRjzpIGkNkg");
	this.shape_176.setTransform(48.4,26.525);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#19837F").ss(2,1,1).p("AsBJxIRpzhIGaNig");
	this.shape_177.setTransform(48.45,26.625);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#19837F").ss(2,1,1).p("Ar/JtIRvzZIGQNfg");
	this.shape_178.setTransform(48.5,26.75);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#19837F").ss(2,1,1).p("Ar9JpIR1zRIGGNdg");
	this.shape_179.setTransform(48.55,26.85);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#19837F").ss(2,1,1).p("Ar7JlIR7zJIF8Nbg");
	this.shape_180.setTransform(48.575,26.95);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("#19837F").ss(2,1,1).p("Ar6JhISCzBIFzNYg");
	this.shape_181.setTransform(48.65,27.05);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#19837F").ss(2,1,1).p("Ar4JdISIy5IFpNWg");
	this.shape_182.setTransform(48.7,27.15);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("#19837F").ss(2,1,1).p("Ar2JYISOyvIFfNTg");
	this.shape_183.setTransform(48.75,27.25);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#19837F").ss(2,1,1).p("Ar0JUISUynIFVNRg");
	this.shape_184.setTransform(48.775,27.35);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("#19837F").ss(2,1,1).p("AryJQISbyfIFKNOg");
	this.shape_185.setTransform(48.825,27.45);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#19837F").ss(2,1,1).p("ArwJMIShyXIFANMg");
	this.shape_186.setTransform(48.875,27.575);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("#19837F").ss(2,1,1).p("AruJIISnyPIE2NKg");
	this.shape_187.setTransform(48.925,27.65);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#19837F").ss(2,1,1).p("ArsJDIStyFIEsNGg");
	this.shape_188.setTransform(48.95,27.775);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#19837F").ss(2,1,1).p("ArqI/ISzx9IEiNEg");
	this.shape_189.setTransform(49,27.875);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#19837F").ss(2,1,1).p("AroI7IS5x1IEYNCg");
	this.shape_190.setTransform(49.05,27.95);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("#19837F").ss(2,1,1).p("ArmI3IS/xtIEOM/g");
	this.shape_191.setTransform(49.075,28.075);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#19837F").ss(2,1,1).p("ArkIzITFxlIEEM9g");
	this.shape_192.setTransform(49.125,28.175);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("#19837F").ss(2,1,1).p("AriIuITLxbID6M6g");
	this.shape_193.setTransform(49.175,28.275);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#19837F").ss(2,1,1).p("ArgIqITRxTIDwM3g");
	this.shape_194.setTransform(49.225,28.375);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("#19837F").ss(2,1,1).p("ArfImITZxLIDmM1g");
	this.shape_195.setTransform(49.25,28.475);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#19837F").ss(2,1,1).p("ArdIiITfxDIDcMzg");
	this.shape_196.setTransform(49.3,28.6);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("#19837F").ss(2,1,1).p("ArbIeITlw7IDSMxg");
	this.shape_197.setTransform(49.35,28.675);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#19837F").ss(2,1,1).p("ArZIaITqwzIDJMug");
	this.shape_198.setTransform(49.425,28.775);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("#19837F").ss(2,1,1).p("ArXIWITxwrIC+Msg");
	this.shape_199.setTransform(49.45,28.9);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#19837F").ss(2,1,1).p("ArVIRIT3whIC0Mpg");
	this.shape_200.setTransform(49.5,28.975);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("#19837F").ss(2,1,1).p("ArTINIT9wZICqMmg");
	this.shape_201.setTransform(49.55,29.1);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#19837F").ss(2,1,1).p("ArRIJIUDwRICgMkg");
	this.shape_202.setTransform(49.6,29.2);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#19837F").ss(2,1,1).p("ArPIFIUJwJICWMig");
	this.shape_203.setTransform(49.625,29.3);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#19837F").ss(2,1,1).p("ArNIBIUPwBICMMfg");
	this.shape_204.setTransform(49.675,29.4);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("#19837F").ss(2,1,1).p("ArLH8IUVv3ICCMcg");
	this.shape_205.setTransform(49.725,29.5);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#19837F").ss(2,1,1).p("ArJH5IUbvxIB4Mbg");
	this.shape_206.setTransform(49.775,29.6);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("#19837F").ss(2,1,1).p("ArIH0IUivnIBvMYg");
	this.shape_207.setTransform(49.8,29.7);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#19837F").ss(2,1,1).p("ArGHwIUovfIBlMVg");
	this.shape_208.setTransform(49.85,29.8);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("#19837F").ss(2,1,1).p("ArEHsIUuvXIBbMTg");
	this.shape_209.setTransform(49.9,29.925);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#19837F").ss(2,1,1).p("ArBHoIUzvPIBRMRg");
	this.shape_210.setTransform(49.95,30);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("#19837F").ss(2,1,1).p("ArAHkIU7vHIBGMOg");
	this.shape_211.setTransform(49.975,30.1);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#19837F").ss(2,1,1).p("Aq+HfIVBu9IA8MLg");
	this.shape_212.setTransform(50.025,30.225);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("#19837F").ss(2,1,1).p("Aq8HbIVHu1IAyMJg");
	this.shape_213.setTransform(50.075,30.325);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#19837F").ss(2,1,1).p("Aq6HXIVNutIAoMHg");
	this.shape_214.setTransform(50.1,30.4);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f().s("#19837F").ss(2,1,1).p("Aq4HTIVTulIAeMEg");
	this.shape_215.setTransform(50.175,30.525);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#19837F").ss(2,1,1).p("Aq2HPIVZudIAUMCg");
	this.shape_216.setTransform(50.225,30.625);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("#19837F").ss(2,1,1).p("Aq0HKIVfuTIAKL/g");
	this.shape_217.setTransform(50.275,30.725);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#19837F").ss(2,1,1).p("AqzHGIVmuLIABL8g");
	this.shape_218.setTransform(50.3,30.825);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("#19837F").ss(2,1,1).p("Aq1HCIVruDIgJL6g");
	this.shape_219.setTransform(50.825,30.925);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#19837F").ss(2,1,1).p("Aq4G+IVxt7IgTL3g");
	this.shape_220.setTransform(51.375,31.05);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("#19837F").ss(2,1,1).p("Aq7G6IV3tzIgdL1g");
	this.shape_221.setTransform(51.925,31.125);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#19837F").ss(2,1,1).p("Aq/G2IV/trIgoLzg");
	this.shape_222.setTransform(52.45,31.225);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("#19837F").ss(2,1,1).p("ArCGyIWFtjIgyLwg");
	this.shape_223.setTransform(53,31.35);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#19837F").ss(2,1,1).p("ArEGtIWKtZIg8Lug");
	this.shape_224.setTransform(53.55,31.425);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#19837F").ss(2,1,1).p("ArIGpIWRtRIhGLrg");
	this.shape_225.setTransform(54.1,31.55);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#19837F").ss(2,1,1).p("ArLGlIWXtJIhQLpg");
	this.shape_226.setTransform(54.625,31.65);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f().s("#19837F").ss(2,1,1).p("ArOGhIWdtBIhaLng");
	this.shape_227.setTransform(55.175,31.725);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#19837F").ss(2,1,1).p("ArRGdIWjs5IhkLlg");
	this.shape_228.setTransform(55.725,31.85);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("#19837F").ss(2,1,1).p("ArUGYIWpswIhuLig");
	this.shape_229.setTransform(56.275,31.95);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#19837F").ss(2,1,1).p("ArXGVIWvsoIh3Lfg");
	this.shape_230.setTransform(56.8,32.05);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f().s("#19837F").ss(2,1,1).p("AraGQIW1sfIiBLcg");
	this.shape_231.setTransform(57.35,32.15);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("#19837F").ss(2,1,1).p("ArdGMIW7sXIiMLag");
	this.shape_232.setTransform(57.9,32.25);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("#19837F").ss(2,1,1).p("ArgGIIXBsPIiVLYg");
	this.shape_233.setTransform(58.45,32.375);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f().s("#19837F").ss(2,1,1).p("ArjGEIXHsHIifLVg");
	this.shape_234.setTransform(58.975,32.45);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f().s("#19837F").ss(2,1,1).p("ArmGAIXNr/IipLTg");
	this.shape_235.setTransform(59.525,32.55);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f().s("#19837F").ss(2,1,1).p("ArpF7IXTr1IizLQg");
	this.shape_236.setTransform(60.075,32.675);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f().s("#19837F").ss(2,1,1).p("ArtF3IXbrtIi+LOg");
	this.shape_237.setTransform(60.625,32.775);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("#19837F").ss(2,1,1).p("ArwFzIXhrlIjILMg");
	this.shape_238.setTransform(61.175,32.85);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f().s("#19837F").ss(2,1,1).p("ArzFvIXnrdIjSLJg");
	this.shape_239.setTransform(61.725,32.975);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("#19837F").ss(2,1,1).p("Ar2FrIXtrVIjcLHg");
	this.shape_240.setTransform(62.275,33.075);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("#19837F").ss(2,1,1).p("Ar5FmIXzrLIjlLDg");
	this.shape_241.setTransform(62.8,33.175);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("#19837F").ss(2,1,1).p("Ar8FiIX5rDIjvLBg");
	this.shape_242.setTransform(63.35,33.275);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f().s("#19837F").ss(2,1,1).p("Ar/FdIX/q8Ij5K/g");
	this.shape_243.setTransform(63.9,33.55);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f().s("#19837F").ss(2,1,1).p("AsCFVIYFqzIkEK9g");
	this.shape_244.setTransform(64.45,33.975);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f().s("#19837F").ss(2,1,1).p("AsFFOIYLqrIkNK6g");
	this.shape_245.setTransform(64.975,34.35);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("#19837F").ss(2,1,1).p("AsIFHIYRqjIkXK4g");
	this.shape_246.setTransform(65.525,34.75);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f().s("#19837F").ss(2,1,1).p("AsLFAIYXqaIkhK1g");
	this.shape_247.setTransform(66.075,35.15);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f().s("#19837F").ss(2,1,1).p("AsOE4IYdqRIkrKzg");
	this.shape_248.setTransform(66.625,35.55);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("#19837F").ss(2,1,1).p("AsSEyIYlqKIk2Kxg");
	this.shape_249.setTransform(67.15,35.95);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f().s("#19837F").ss(2,1,1).p("AsVErIYrqBIk/Ktg");
	this.shape_250.setTransform(67.7,36.325);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("#19837F").ss(2,1,1).p("AsYEjIYxp4IlKKrg");
	this.shape_251.setTransform(68.25,36.725);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#19837F").ss(2,1,1).p("AsbEcIY3pwIlTKpg");
	this.shape_252.setTransform(68.8,37.125);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("#19837F").ss(2,1,1).p("AseEVIY9poIldKng");
	this.shape_253.setTransform(69.325,37.525);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("#19837F").ss(2,1,1).p("AshEPIZDphIlnKlg");
	this.shape_254.setTransform(69.875,37.9);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f().s("#19837F").ss(2,1,1).p("AskEHIZJpXIlxKhg");
	this.shape_255.setTransform(70.425,38.325);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f().s("#19837F").ss(2,1,1).p("AsnEAIZPpPIl7Kfg");
	this.shape_256.setTransform(70.975,38.7);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f().s("#19837F").ss(2,1,1).p("AsqD5IZVpHImFKdg");
	this.shape_257.setTransform(71.5,39.125);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("#19837F").ss(2,1,1).p("AstDyIZbo/ImPKag");
	this.shape_258.setTransform(72.05,39.5);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("#19837F").ss(2,1,1).p("AswDrIZho2ImZKXg");
	this.shape_259.setTransform(72.6,39.875);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("#19837F").ss(2,1,1).p("AszDjIZnotImjKVg");
	this.shape_260.setTransform(73.125,40.3);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("#19837F").ss(2,1,1).p("As2DcIZtolImtKTg");
	this.shape_261.setTransform(73.675,40.675);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("#19837F").ss(2,1,1).p("As5DVIZzodIm3KRg");
	this.shape_262.setTransform(74.225,41.1);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("#19837F").ss(2,1,1).p("As9DOIZ7oUInCKNg");
	this.shape_263.setTransform(74.8,41.475);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#19837F").ss(2,1,1).p("AtADHIaBoMInMKLg");
	this.shape_264.setTransform(75.325,41.875);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f().s("#19837F").ss(2,1,1).p("AtDDAIaHoEInWKJg");
	this.shape_265.setTransform(75.875,42.275);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f().s("#19837F").ss(2,1,1).p("AtGC5IaNn8IngKHg");
	this.shape_266.setTransform(76.425,42.675);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f().s("#19837F").ss(2,1,1).p("AtJCyIaTn0InpKFg");
	this.shape_267.setTransform(76.975,43.05);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f().s("#19837F").ss(2,1,1).p("AtMCrIaZnrInzKBg");
	this.shape_268.setTransform(77.5,43.45);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f().s("#19837F").ss(2,1,1).p("AtPCkIafnjIn9J/g");
	this.shape_269.setTransform(78.05,43.85);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f().s("#19837F").ss(2,1,1).p("AtSCdIalnbIoHJ8g");
	this.shape_270.setTransform(78.6,44.25);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f().s("#19837F").ss(2,1,1).p("AtVCVIarnSIoRJ7g");
	this.shape_271.setTransform(79.15,44.65);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f().s("#19837F").ss(2,1,1).p("AtYCOIaxnJIobJ3g");
	this.shape_272.setTransform(79.675,45.025);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f().s("#19837F").ss(2,1,1).p("AtbCHIa3nBIolJ1g");
	this.shape_273.setTransform(80.225,45.45);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f().s("#19837F").ss(2,1,1).p("AteCAIa9m5IovJzg");
	this.shape_274.setTransform(80.775,45.825);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f().s("#19837F").ss(2,1,1).p("AthB5IbDmxIo5Jxg");
	this.shape_275.setTransform(81.325,46.225);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f().s("#19837F").ss(2,1,1).p("AtlByIbLmoIpDJtg");
	this.shape_276.setTransform(81.85,46.625);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f().s("#19837F").ss(2,1,1).p("AtoBrIbRmgIpOJrg");
	this.shape_277.setTransform(82.4,47.025);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f().s("#19837F").ss(2,1,1).p("AtrBjIbXmXIpYJpg");
	this.shape_278.setTransform(82.95,47.425);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f().s("#19837F").ss(2,1,1).p("AtuBdIbdmPIphJmg");
	this.shape_279.setTransform(83.5,47.8);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f().s("#19837F").ss(2,1,1).p("AtxBWIbjmHIprJkg");
	this.shape_280.setTransform(84.025,48.2);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#19837F").ss(2,1,1).p("At0BPIbpl/Ip1Jhg");
	this.shape_281.setTransform(84.575,48.6);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f().s("#19837F").ss(2,1,1).p("At3BHIbvl2Ip/Jfg");
	this.shape_282.setTransform(85.125,49);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f().s("#19837F").ss(2,1,1).p("At6BAIb1luIqJJdg");
	this.shape_283.setTransform(85.65,49.375);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f().s("#19837F").ss(2,1,1).p("At9A5Ib7lmIqTJbg");
	this.shape_284.setTransform(86.2,49.8);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f().s("#19837F").ss(2,1,1).p("AuAAyIcBldIqdJXg");
	this.shape_285.setTransform(86.75,50.175);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f().s("#19837F").ss(2,1,1).p("AuDArIcHlVIqnJVg");
	this.shape_286.setTransform(87.3,50.6);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f().s("#19837F").ss(2,1,1).p("AuGAkIcNlNIqwJTg");
	this.shape_287.setTransform(87.825,50.975);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f().s("#19837F").ss(2,1,1).p("AuKAdIcVlFIq7JRg");
	this.shape_288.setTransform(88.4,51.35);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f().s("#19837F").ss(2,1,1).p("AuNAVIcbk7IrGJNg");
	this.shape_289.setTransform(88.95,51.775);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f().s("#19837F").ss(2,1,1).p("AuQAPIchk0IrQJLg");
	this.shape_290.setTransform(89.5,52.15);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f().s("#19837F").ss(2,1,1).p("AuTAIIcnksIrZJJg");
	this.shape_291.setTransform(90.025,52.55);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f().s("#19837F").ss(2,1,1).p("AuWAAIctkiIrjJGg");
	this.shape_292.setTransform(90.575,52.95);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f().s("#19837F").ss(2,1,1).p("AuZgGIczkcIrtJFg");
	this.shape_293.setTransform(91.125,53.35);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f().s("#19837F").ss(2,1,1).p("AucgNIc5kTIr3JBg");
	this.shape_294.setTransform(91.675,53.75);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f().s("#19837F").ss(2,1,1).p("AufgVIc/kKIsBI/g");
	this.shape_295.setTransform(92.2,54.15);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f().s("#19837F").ss(2,1,1).p("AuigbIdFkDIsLI9g");
	this.shape_296.setTransform(92.75,54.525);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f().s("#19837F").ss(2,1,1).p("AulgjIdLj6IsVI7g");
	this.shape_297.setTransform(93.3,54.95);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f().s("#19837F").ss(2,1,1).p("AuogpIdRjyIsfI3g");
	this.shape_298.setTransform(93.85,55.325);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f().s("#19837F").ss(2,1,1).p("AurgxIdXjpIspI1g");
	this.shape_299.setTransform(94.375,55.7);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#19837F").ss(2,1,1).p("Auug4IddjhIszIzg");
	this.shape_300.setTransform(94.925,56.125);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#19837F").ss(2,1,1).p("Auxg/IdjjZIs9Ixg");
	this.shape_301.setTransform(95.475,56.5);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f().s("#19837F").ss(2,1,1).p("Au0hGIdpjQItGItg");
	this.shape_302.setTransform(96.025,56.925);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#19837F").ss(2,1,1).p("Au4hNIdxjIItRIrg");
	this.shape_303.setTransform(96.55,57.3);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f().s("#19837F").ss(2,1,1).p("Au7hUId3jAItbIpg");
	this.shape_304.setTransform(97.1,57.7);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f().s("#19837F").ss(2,1,1).p("Au+hcId9i3ItlIng");
	this.shape_305.setTransform(97.65,58.1);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f().s("#19837F").ss(2,1,1).p("AvBhjIeDivItvIlg");
	this.shape_306.setTransform(98.175,58.5);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f().s("#19837F").ss(2,1,1).p("AvEhpIeJinIt5Ihg");
	this.shape_307.setTransform(98.725,58.875);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f().s("#19837F").ss(2,1,1).p("AvHhwIePifIuDIfg");
	this.shape_308.setTransform(99.275,59.275);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f().s("#19837F").ss(2,1,1).p("AvKh4IeViWIuNIdg");
	this.shape_309.setTransform(99.825,59.675);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f().s("#19837F").ss(2,1,1).p("AvNh/IebiNIuWIZg");
	this.shape_310.setTransform(100.35,60.075);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f().s("#19837F").ss(2,1,1).p("AvQiGIehiFIugIXg");
	this.shape_311.setTransform(100.9,60.475);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f().s("#19837F").ss(2,1,1).p("AvTiNIenh9IuqIVg");
	this.shape_312.setTransform(101.45,60.85);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f().s("#19837F").ss(2,1,1).p("AvWiUIeth1Iu0ITg");
	this.shape_313.setTransform(102,61.275);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f().s("#19837F").ss(2,1,1).p("AvZibIezhsIu+IPg");
	this.shape_314.setTransform(102.525,61.65);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f().s("#19837F").ss(2,1,1).p("AvdiiIe7hlIvKIPg");
	this.shape_315.setTransform(103.1,62.05);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f().s("#19837F").ss(2,1,1).p("AvgiqIfBhbIvUILg");
	this.shape_316.setTransform(103.65,62.45);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f().s("#19837F").ss(2,1,1).p("AvjixIfHhTIveIJg");
	this.shape_317.setTransform(104.2,62.85);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f().s("#19837F").ss(2,1,1).p("Avmi4IfNhLIvnIHg");
	this.shape_318.setTransform(104.725,63.25);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f().s("#19837F").ss(2,1,1).p("Avpi/IfThCIvwIDg");
	this.shape_319.setTransform(105.275,63.625);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f().s("#19837F").ss(2,1,1).p("AvsjGIfZg6Iv6IBg");
	this.shape_320.setTransform(105.825,64.025);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f().s("#19837F").ss(2,1,1).p("AvvjNIffgyIwEH/g");
	this.shape_321.setTransform(106.375,64.425);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f().s("#19837F").ss(2,1,1).p("AvyjUIflgqIwOH9g");
	this.shape_322.setTransform(106.9,64.825);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f().s("#19837F").ss(2,1,1).p("Av1jbIfrghIwYH5g");
	this.shape_323.setTransform(107.45,65.225);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f().s("#19837F").ss(2,1,1).p("Av4jiIfxgZIwiH3g");
	this.shape_324.setTransform(108,65.625);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f().s("#19837F").ss(2,1,1).p("Av7jpIf3gRIwsH1g");
	this.shape_325.setTransform(108.55,66);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f().s("#19837F").ss(2,1,1).p("Av+jxIf9gIIw1Hzg");
	this.shape_326.setTransform(109.075,66.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_214}]},1).to({state:[{t:this.shape_215}]},1).to({state:[{t:this.shape_216}]},1).to({state:[{t:this.shape_217}]},1).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).to({state:[{t:this.shape_250}]},1).to({state:[{t:this.shape_251}]},1).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_263}]},1).to({state:[{t:this.shape_264}]},1).to({state:[{t:this.shape_265}]},1).to({state:[{t:this.shape_266}]},1).to({state:[{t:this.shape_267}]},1).to({state:[{t:this.shape_268}]},1).to({state:[{t:this.shape_269}]},1).to({state:[{t:this.shape_270}]},1).to({state:[{t:this.shape_271}]},1).to({state:[{t:this.shape_272}]},1).to({state:[{t:this.shape_273}]},1).to({state:[{t:this.shape_274}]},1).to({state:[{t:this.shape_275}]},1).to({state:[{t:this.shape_276}]},1).to({state:[{t:this.shape_277}]},1).to({state:[{t:this.shape_278}]},1).to({state:[{t:this.shape_279}]},1).to({state:[{t:this.shape_280}]},1).to({state:[{t:this.shape_281}]},1).to({state:[{t:this.shape_282}]},1).to({state:[{t:this.shape_283}]},1).to({state:[{t:this.shape_284}]},1).to({state:[{t:this.shape_285}]},1).to({state:[{t:this.shape_286}]},1).to({state:[{t:this.shape_287}]},1).to({state:[{t:this.shape_288}]},1).to({state:[{t:this.shape_289}]},1).to({state:[{t:this.shape_290}]},1).to({state:[{t:this.shape_291}]},1).to({state:[{t:this.shape_292}]},1).to({state:[{t:this.shape_293}]},1).to({state:[{t:this.shape_294}]},1).to({state:[{t:this.shape_295}]},1).to({state:[{t:this.shape_296}]},1).to({state:[{t:this.shape_297}]},1).to({state:[{t:this.shape_298}]},1).to({state:[{t:this.shape_299}]},1).to({state:[{t:this.shape_300}]},1).to({state:[{t:this.shape_301}]},1).to({state:[{t:this.shape_302}]},1).to({state:[{t:this.shape_303}]},1).to({state:[{t:this.shape_304}]},1).to({state:[{t:this.shape_305}]},1).to({state:[{t:this.shape_306}]},1).to({state:[{t:this.shape_307}]},1).to({state:[{t:this.shape_308}]},1).to({state:[{t:this.shape_309}]},1).to({state:[{t:this.shape_310}]},1).to({state:[{t:this.shape_311}]},1).to({state:[{t:this.shape_312}]},1).to({state:[{t:this.shape_313}]},1).to({state:[{t:this.shape_314}]},1).to({state:[{t:this.shape_315}]},1).to({state:[{t:this.shape_316}]},1).to({state:[{t:this.shape_317}]},1).to({state:[{t:this.shape_318}]},1).to({state:[{t:this.shape_319}]},1).to({state:[{t:this.shape_320}]},1).to({state:[{t:this.shape_321}]},1).to({state:[{t:this.shape_322}]},1).to({state:[{t:this.shape_323}]},1).to({state:[{t:this.shape_324}]},1).to({state:[{t:this.shape_325}]},1).to({state:[{t:this.shape_326}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_1_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#19837F").ss(2,1,1).p("AmEnvIQ7IiI1tG9g");
	this.shape.setTransform(69.475,49.55);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#19837F").ss(2,1,1).p("AquHoIFCvPIQcIpg");
	this.shape_1.setTransform(68.95,48.95);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#19837F").ss(2,1,1).p("AqoHgIFUu/IP9Iyg");
	this.shape_2.setTransform(68.45,48.325);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#19837F").ss(2,1,1).p("AqgHYIFkuvIPdI5g");
	this.shape_3.setTransform(67.925,47.725);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#19837F").ss(2,1,1).p("AqaHQIF2ufIO/JBg");
	this.shape_4.setTransform(67.4,47.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#19837F").ss(2,1,1).p("AqSHIIGGuPIOfJJg");
	this.shape_5.setTransform(66.875,46.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#19837F").ss(2,1,1).p("AqLHAIGXt/IOAJRg");
	this.shape_6.setTransform(66.375,45.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#19837F").ss(2,1,1).p("AqEG5IGotxINhJag");
	this.shape_7.setTransform(65.85,45.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#19837F").ss(2,1,1).p("Ap9GxIG4thINDJig");
	this.shape_8.setTransform(65.35,44.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#19837F").ss(2,1,1).p("Ap2GpIHJtRIMkJpg");
	this.shape_9.setTransform(64.825,44.075);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#19837F").ss(2,1,1).p("ApvGhIHbtBIMEJxg");
	this.shape_10.setTransform(64.3,43.475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#19837F").ss(2,1,1).p("ApoGZIHrsxILmJ5g");
	this.shape_11.setTransform(63.8,42.85);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#19837F").ss(2,1,1).p("AphGRIH9shILGKBg");
	this.shape_12.setTransform(63.25,42.25);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#19837F").ss(2,1,1).p("ApaGJIINsRIKoKJg");
	this.shape_13.setTransform(62.75,41.625);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#19837F").ss(2,1,1).p("ApSGBIIdsBIKIKRg");
	this.shape_14.setTransform(62.225,41.025);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#19837F").ss(2,1,1).p("ApLF5IIurxIJpKYg");
	this.shape_15.setTransform(61.725,40.425);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#19837F").ss(2,1,1).p("ApEFyII/riIJKKgg");
	this.shape_16.setTransform(61.2,39.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#19837F").ss(2,1,1).p("Ao9FqIJPrTIIsKpg");
	this.shape_17.setTransform(60.7,39.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#19837F").ss(2,1,1).p("Ao2FiIJgrDIINKxg");
	this.shape_18.setTransform(60.175,38.575);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#19837F").ss(2,1,1).p("AovFXIJwqzIHvK5g");
	this.shape_19.setTransform(59.65,38.275);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#19837F").ss(2,1,1).p("AooFEIKCqkIHPLBg");
	this.shape_20.setTransform(59.125,38.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#19837F").ss(2,1,1).p("AohEwIKTqUIGwLJg");
	this.shape_21.setTransform(58.6,39.425);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#19837F").ss(2,1,1).p("AoaEcIKjqEIGSLRg");
	this.shape_22.setTransform(58.1,39.975);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#19837F").ss(2,1,1).p("AoSEIIKzp0IFyLZg");
	this.shape_23.setTransform(57.575,40.575);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().s("#19837F").ss(2,1,1).p("AoLD0ILEpkIFTLhg");
	this.shape_24.setTransform(57.075,41.15);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#19837F").ss(2,1,1).p("AoEDhILWpVIEzLpg");
	this.shape_25.setTransform(56.55,41.725);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().s("#19837F").ss(2,1,1).p("An9DNILmpFIEVLxg");
	this.shape_26.setTransform(56.05,42.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().s("#19837F").ss(2,1,1).p("An2C5IL3o1ID2L5g");
	this.shape_27.setTransform(55.5,42.875);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().s("#19837F").ss(2,1,1).p("AnvClIMIolIDXMBg");
	this.shape_28.setTransform(55,43.45);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().s("#19837F").ss(2,1,1).p("AnoCSIMZoWIC4MJg");
	this.shape_29.setTransform(54.475,44.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().s("#19837F").ss(2,1,1).p("AnhB/IMqoGICZMQg");
	this.shape_30.setTransform(53.975,44.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().s("#19837F").ss(2,1,1).p("AnaBrIM7n2IB6MXg");
	this.shape_31.setTransform(53.45,45.175);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().s("#19837F").ss(2,1,1).p("AnSBXINLnnIBaMhg");
	this.shape_32.setTransform(52.925,45.75);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().s("#19837F").ss(2,1,1).p("AnLBDINcnWIA7Mng");
	this.shape_33.setTransform(52.425,46.325);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().s("#19837F").ss(2,1,1).p("AnEAwINtnIIAcMxg");
	this.shape_34.setTransform(51.875,46.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().s("#19837F").ss(2,1,1).p("Am+AcIN9m3IgCM3g");
	this.shape_35.setTransform(51.475,47.475);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().s("#19837F").ss(2,1,1).p("AnHAIIOPmoIgiNBg");
	this.shape_36.setTransform(52.525,48.05);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().s("#19837F").ss(2,1,1).p("AnPgLIOfmYIhANHg");
	this.shape_37.setTransform(53.575,48.625);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().s("#19837F").ss(2,1,1).p("AnXgfIOwmIIhgNPg");
	this.shape_38.setTransform(54.6,49.225);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().s("#19837F").ss(2,1,1).p("AnggyIPBl5Ih+NXg");
	this.shape_39.setTransform(55.625,49.775);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().s("#19837F").ss(2,1,1).p("AnohGIPRlpIidNfg");
	this.shape_40.setTransform(56.675,50.375);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().s("#19837F").ss(2,1,1).p("AnxhaIPjlZIi9Nng");
	this.shape_41.setTransform(57.725,50.925);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().s("#19837F").ss(2,1,1).p("An5htIPzlKIjbNvg");
	this.shape_42.setTransform(58.725,51.525);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().s("#19837F").ss(2,1,1).p("AoCiBIQFk6Ij7N3g");
	this.shape_43.setTransform(59.75,52.075);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().s("#19837F").ss(2,1,1).p("AoKiVIQVkqIkZN/g");
	this.shape_44.setTransform(60.8,52.675);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().s("#19837F").ss(2,1,1).p("AoTipIQnkaIk5OHg");
	this.shape_45.setTransform(61.85,53.25);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().s("#19837F").ss(2,1,1).p("Aobi8IQ3kLIlYOPg");
	this.shape_46.setTransform(62.875,53.8);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().s("#19837F").ss(2,1,1).p("AojjQIRHj7Il3OXg");
	this.shape_47.setTransform(63.925,54.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().s("#19837F").ss(2,1,1).p("AosjjIRYjsImVOfg");
	this.shape_48.setTransform(64.95,54.95);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().s("#19837F").ss(2,1,1).p("Ao0j3IRpjcIm1Ong");
	this.shape_49.setTransform(65.95,55.55);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().s("#19837F").ss(2,1,1).p("Ao9kLIR7jMInUOvg");
	this.shape_50.setTransform(67,56.1);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().s("#19837F").ss(2,1,1).p("ApFkfISLi8InzO3g");
	this.shape_51.setTransform(68.05,56.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().s("#19837F").ss(2,1,1).p("ApNkzISbisIoSO/g");
	this.shape_52.setTransform(69.075,57.25);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().s("#19837F").ss(2,1,1).p("ApWlHISticIoxPHg");
	this.shape_53.setTransform(70.1,57.85);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().s("#19837F").ss(2,1,1).p("ApelaIS9iNIpQPPg");
	this.shape_54.setTransform(71.15,58.425);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().s("#19837F").ss(2,1,1).p("ApnluITPh9IpvPXg");
	this.shape_55.setTransform(72.2,59);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().s("#19837F").ss(2,1,1).p("ApvmBITfhuIqNPfg");
	this.shape_56.setTransform(73.225,59.575);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().s("#19837F").ss(2,1,1).p("Ap3mVITvheIqrPng");
	this.shape_57.setTransform(74.225,60.15);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f().s("#19837F").ss(2,1,1).p("AqAmpIUBhOIrLPvg");
	this.shape_58.setTransform(75.275,60.725);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f().s("#19837F").ss(2,1,1).p("AqIm9IURg+IrqP3g");
	this.shape_59.setTransform(76.325,61.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f().s("#19837F").ss(2,1,1).p("AqRnQIUjgvIsJP/g");
	this.shape_60.setTransform(77.35,61.875);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f().s("#19837F").ss(2,1,1).p("AqSnVIUlgnIsKP5g");
	this.shape_61.setTransform(77.075,61.975);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f().s("#19837F").ss(2,1,1).p("AqTnZIUnggIsLPzg");
	this.shape_62.setTransform(76.825,62.05);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f().s("#19837F").ss(2,1,1).p("AqUneIUpgXIsMPrg");
	this.shape_63.setTransform(76.55,62.175);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f().s("#19837F").ss(2,1,1).p("AqVnjIUrgPIsNPlg");
	this.shape_64.setTransform(76.3,62.275);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f().s("#19837F").ss(2,1,1).p("AqWnnIUtgIIsNPfg");
	this.shape_65.setTransform(76.025,62.35);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f().s("#19837F").ss(2,1,1).p("AqXnsIUvAAIsOPZg");
	this.shape_66.setTransform(75.75,62.45);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f().s("#19837F").ss(2,1,1).p("AqYntIUxAIIsOPTg");
	this.shape_67.setTransform(75.475,62.175);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().s("#19837F").ss(2,1,1).p("AqantIU0APIsPPMg");
	this.shape_68.setTransform(75.2,61.875);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().s("#19837F").ss(2,1,1).p("AqanuIU2AXIsRPGg");
	this.shape_69.setTransform(74.95,61.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().s("#19837F").ss(2,1,1).p("AqcnvIU5AfIsSPAg");
	this.shape_70.setTransform(74.675,61.3);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().s("#19837F").ss(2,1,1).p("AqdnwIU7AnIsTO6g");
	this.shape_71.setTransform(74.425,61.025);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().s("#19837F").ss(2,1,1).p("AqenwIU9AuIsTOzg");
	this.shape_72.setTransform(74.15,60.725);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().s("#19837F").ss(2,1,1).p("AqfnxIU/A1IsUOug");
	this.shape_73.setTransform(73.9,60.45);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().s("#19837F").ss(2,1,1).p("AqgnyIVBA+IsVOng");
	this.shape_74.setTransform(73.625,60.15);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().s("#19837F").ss(2,1,1).p("AqhnzIVDBGIsWOgg");
	this.shape_75.setTransform(73.375,59.85);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().s("#19837F").ss(2,1,1).p("AqjnzIVHBNIsYOag");
	this.shape_76.setTransform(73.1,59.575);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().s("#19837F").ss(2,1,1).p("Aqkn0IVJBVIsYOUg");
	this.shape_77.setTransform(72.825,59.275);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().s("#19837F").ss(2,1,1).p("Aqln1IVLBdIsZOOg");
	this.shape_78.setTransform(72.55,58.975);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().s("#19837F").ss(2,1,1).p("Aqmn2IVNBkIsZOJg");
	this.shape_79.setTransform(72.275,58.7);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().s("#19837F").ss(2,1,1).p("Aqnn2IVPBsIsaOBg");
	this.shape_80.setTransform(72.025,58.425);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f().s("#19837F").ss(2,1,1).p("Aqon3IVRB0IsbN7g");
	this.shape_81.setTransform(71.75,58.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f().s("#19837F").ss(2,1,1).p("Aqpn4IVTB8IscN1g");
	this.shape_82.setTransform(71.5,57.825);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f().s("#19837F").ss(2,1,1).p("Aqqn5IVVCEIscNvg");
	this.shape_83.setTransform(71.225,57.55);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f().s("#19837F").ss(2,1,1).p("Aqsn5IVZCKIseNpg");
	this.shape_84.setTransform(70.95,57.25);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f().s("#19837F").ss(2,1,1).p("Aqtn6IVbCTIsfNig");
	this.shape_85.setTransform(70.7,56.95);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f().s("#19837F").ss(2,1,1).p("Aqun7IVdCbIsfNcg");
	this.shape_86.setTransform(70.425,56.675);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f().s("#19837F").ss(2,1,1).p("Aqvn7IVfCiIsgNVg");
	this.shape_87.setTransform(70.175,56.375);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f().s("#19837F").ss(2,1,1).p("Aqwn8IVhCpIshNQg");
	this.shape_88.setTransform(69.9,56.1);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f().s("#19837F").ss(2,1,1).p("Aqxn9IVjCxIsiNKg");
	this.shape_89.setTransform(69.65,55.8);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f().s("#19837F").ss(2,1,1).p("Aqyn+IVlC6IsiNDg");
	this.shape_90.setTransform(69.375,55.525);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f().s("#19837F").ss(2,1,1).p("Aqzn+IVnDBIsjM8g");
	this.shape_91.setTransform(69.075,55.225);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f().s("#19837F").ss(2,1,1).p("Aq0n/IVpDJIskM2g");
	this.shape_92.setTransform(68.825,54.925);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f().s("#19837F").ss(2,1,1).p("Aq2oAIVtDQIslMxg");
	this.shape_93.setTransform(68.55,54.65);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f().s("#19837F").ss(2,1,1).p("Aq3oBIVvDYIsmMrg");
	this.shape_94.setTransform(68.3,54.35);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f().s("#19837F").ss(2,1,1).p("Aq4oBIVxDfIsnMkg");
	this.shape_95.setTransform(68.025,54.075);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#19837F").ss(2,1,1).p("Aq5oCIVzDoIsoMdg");
	this.shape_96.setTransform(67.775,53.775);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f().s("#19837F").ss(2,1,1).p("Aq6oDIV1DwIsoMXg");
	this.shape_97.setTransform(67.5,53.475);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f().s("#19837F").ss(2,1,1).p("Aq7oEIV3D4IspMRg");
	this.shape_98.setTransform(67.225,53.2);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f().s("#19837F").ss(2,1,1).p("Aq8oEIV5D+IsqMLg");
	this.shape_99.setTransform(66.975,52.925);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f().s("#19837F").ss(2,1,1).p("Aq9oFIV8EGIsrMFg");
	this.shape_100.setTransform(66.7,52.6);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f().s("#19837F").ss(2,1,1).p("Aq/oGIV/EPIstL+g");
	this.shape_101.setTransform(66.45,52.325);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f().s("#19837F").ss(2,1,1).p("ArAoHIWBEWIstL5g");
	this.shape_102.setTransform(66.175,52.05);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f().s("#19837F").ss(2,1,1).p("ArBoHIWDEdIsuLyg");
	this.shape_103.setTransform(65.9,51.75);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f().s("#19837F").ss(2,1,1).p("ArCoIIWFEmIsuLrg");
	this.shape_104.setTransform(65.625,51.45);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f().s("#19837F").ss(2,1,1).p("ArDoJIWHEtIsvLmg");
	this.shape_105.setTransform(65.375,51.175);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f().s("#19837F").ss(2,1,1).p("ArEoJIWJE0IswLfg");
	this.shape_106.setTransform(65.1,50.875);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f().s("#19837F").ss(2,1,1).p("ArFoKIWLE9IsxLYg");
	this.shape_107.setTransform(64.825,50.575);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f().s("#19837F").ss(2,1,1).p("ArGoLIWNFEIsyLTg");
	this.shape_108.setTransform(64.575,50.3);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f().s("#19837F").ss(2,1,1).p("ArIoMIWRFMIszLNg");
	this.shape_109.setTransform(64.3,50);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f().s("#19837F").ss(2,1,1).p("ArJoMIWTFTIs0LGg");
	this.shape_110.setTransform(64.05,49.725);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f().s("#19837F").ss(2,1,1).p("ArKoNIWVFbIs1LAg");
	this.shape_111.setTransform(63.775,49.425);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f().s("#19837F").ss(2,1,1).p("ArLoOIWXFjIs2K6g");
	this.shape_112.setTransform(63.525,49.15);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f().s("#19837F").ss(2,1,1).p("ArMoOIWZFrIs2Kzg");
	this.shape_113.setTransform(63.25,48.85);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f().s("#19837F").ss(2,1,1).p("ArNoPIWbFyIs3Ktg");
	this.shape_114.setTransform(62.975,48.575);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f().s("#19837F").ss(2,1,1).p("ArOoQIWdF6Is3Kng");
	this.shape_115.setTransform(62.7,48.275);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f().s("#19837F").ss(2,1,1).p("ArPoRIWfGCIs4Khg");
	this.shape_116.setTransform(62.425,47.975);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f().s("#19837F").ss(2,1,1).p("ArQoSIWhGKIs5Kbg");
	this.shape_117.setTransform(62.175,47.7);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f().s("#19837F").ss(2,1,1).p("ArSoSIWlGRIs7KUg");
	this.shape_118.setTransform(61.9,47.425);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f().s("#19837F").ss(2,1,1).p("ArToTIWnGZIs7KOg");
	this.shape_119.setTransform(61.65,47.1);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f().s("#19837F").ss(2,1,1).p("ArUoUIWpGhIs8KIg");
	this.shape_120.setTransform(61.375,46.825);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f().s("#19837F").ss(2,1,1).p("ArRoQIWjGaIszKHg");
	this.shape_121.setTransform(61.15,46.975);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f().s("#19837F").ss(2,1,1).p("ArOoNIWdGUIspKHg");
	this.shape_122.setTransform(60.925,47.1);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f().s("#19837F").ss(2,1,1).p("ArLoJIWYGNIsgKGg");
	this.shape_123.setTransform(60.7,47.275);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f().s("#19837F").ss(2,1,1).p("ArJoFIWTGFIsXKGg");
	this.shape_124.setTransform(60.475,47.4);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f().s("#19837F").ss(2,1,1).p("ArGoCIWNF/IsNKGg");
	this.shape_125.setTransform(60.25,47.55);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f().s("#19837F").ss(2,1,1).p("ArDn+IWHF5IsEKEg");
	this.shape_126.setTransform(60.025,47.7);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f().s("#19837F").ss(2,1,1).p("ArAn6IWBFxIr7KEg");
	this.shape_127.setTransform(59.825,47.825);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f().s("#19837F").ss(2,1,1).p("Aq+n3IV9FrIryKDg");
	this.shape_128.setTransform(59.6,48);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f().s("#19837F").ss(2,1,1).p("Aq7nzIV3FkIrpKDg");
	this.shape_129.setTransform(59.375,48.125);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f().s("#19837F").ss(2,1,1).p("Aq4nvIVxFdIrfKCg");
	this.shape_130.setTransform(59.15,48.275);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f().s("#19837F").ss(2,1,1).p("Aq1nsIVrFXIrWKCg");
	this.shape_131.setTransform(58.925,48.425);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f().s("#19837F").ss(2,1,1).p("AqynoIVmFPIrNKCg");
	this.shape_132.setTransform(58.7,48.55);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f().s("#19837F").ss(2,1,1).p("AqwnkIVhFIIrEKBg");
	this.shape_133.setTransform(58.475,48.725);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f().s("#19837F").ss(2,1,1).p("AqtnhIVbFCIq7KBg");
	this.shape_134.setTransform(58.25,48.875);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f().s("#19837F").ss(2,1,1).p("AqqndIVVE7IqxKAg");
	this.shape_135.setTransform(58.025,49);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f().s("#19837F").ss(2,1,1).p("AqonZIVRE0IqpJ/g");
	this.shape_136.setTransform(57.8,49.15);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f().s("#19837F").ss(2,1,1).p("AqlnWIVLEuIqgJ/g");
	this.shape_137.setTransform(57.575,49.275);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f().s("#19837F").ss(2,1,1).p("AqinSIVFEmIqWJ/g");
	this.shape_138.setTransform(57.35,49.45);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f().s("#19837F").ss(2,1,1).p("AqfnPIU/EgIqNJ/g");
	this.shape_139.setTransform(57.125,49.6);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f().s("#19837F").ss(2,1,1).p("AqdnLIU6EZIqDJ+g");
	this.shape_140.setTransform(56.9,49.725);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f().s("#19837F").ss(2,1,1).p("AqZnHIU0ESIp7J9g");
	this.shape_141.setTransform(56.7,49.875);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f().s("#19837F").ss(2,1,1).p("AqXnEIUvEMIpyJ9g");
	this.shape_142.setTransform(56.5,50);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f().s("#19837F").ss(2,1,1).p("AqUnAIUpEFIpoJ8g");
	this.shape_143.setTransform(56.275,50.175);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f().s("#19837F").ss(2,1,1).p("AqSm8IUlD9IpgJ8g");
	this.shape_144.setTransform(56.05,50.325);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f().s("#19837F").ss(2,1,1).p("AqPm5IUfD4IpWJ7g");
	this.shape_145.setTransform(55.825,50.45);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f().s("#19837F").ss(2,1,1).p("AqMm1IUZDwIpNJ7g");
	this.shape_146.setTransform(55.6,50.6);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f().s("#19837F").ss(2,1,1).p("AqJmxIUTDpIpDJ6g");
	this.shape_147.setTransform(55.375,50.725);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f().s("#19837F").ss(2,1,1).p("AqHmuIUPDjIo7J6g");
	this.shape_148.setTransform(55.15,50.9);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f().s("#19837F").ss(2,1,1).p("AqEmqIUJDcIoxJ5g");
	this.shape_149.setTransform(54.925,51.05);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f().s("#19837F").ss(2,1,1).p("AqBmmIUDDVIooJ4g");
	this.shape_150.setTransform(54.7,51.175);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f().s("#19837F").ss(2,1,1).p("Ap+mjIT9DOIoeJ5g");
	this.shape_151.setTransform(54.475,51.325);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f().s("#19837F").ss(2,1,1).p("Ap8mfIT5DIIoWJ3g");
	this.shape_152.setTransform(54.25,51.45);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f().s("#19837F").ss(2,1,1).p("Ap5mbITzDAIoMJ3g");
	this.shape_153.setTransform(54.025,51.625);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f().s("#19837F").ss(2,1,1).p("Ap2mYITtC6IoDJ3g");
	this.shape_154.setTransform(53.8,51.775);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f().s("#19837F").ss(2,1,1).p("ApzmUITnCzIn6J2g");
	this.shape_155.setTransform(53.6,51.9);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f().s("#19837F").ss(2,1,1).p("ApwmRIThCsInwJ3g");
	this.shape_156.setTransform(53.375,52.05);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f().s("#19837F").ss(2,1,1).p("ApumNITdClInoJ2g");
	this.shape_157.setTransform(53.15,52.2);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f().s("#19837F").ss(2,1,1).p("AprmJITXCeIneJ1g");
	this.shape_158.setTransform(52.925,52.35);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f().s("#19837F").ss(2,1,1).p("ApomGITRCYInVJ1g");
	this.shape_159.setTransform(52.7,52.5);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f().s("#19837F").ss(2,1,1).p("AplmCITLCRInLJ0g");
	this.shape_160.setTransform(52.475,52.625);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f().s("#19837F").ss(2,1,1).p("Apjl+ITHCKInCJzg");
	this.shape_161.setTransform(52.25,52.775);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f().s("#19837F").ss(2,1,1).p("Apgl7ITBCEIm5Jzg");
	this.shape_162.setTransform(52.025,52.925);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f().s("#19837F").ss(2,1,1).p("Apdl3IS7B9ImwJyg");
	this.shape_163.setTransform(51.8,53.075);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f().s("#19837F").ss(2,1,1).p("ApalzIS1B1ImmJyg");
	this.shape_164.setTransform(51.575,53.225);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f().s("#19837F").ss(2,1,1).p("ApYlwISxBvImeJyg");
	this.shape_165.setTransform(51.35,53.35);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f().s("#19837F").ss(2,1,1).p("ApVlsISrBoImUJxg");
	this.shape_166.setTransform(51.125,53.5);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f().s("#19837F").ss(2,1,1).p("ApSlpISlBiImLJxg");
	this.shape_167.setTransform(50.9,53.65);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f().s("#19837F").ss(2,1,1).p("ApPllISfBbImBJwg");
	this.shape_168.setTransform(50.675,53.8);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f().s("#19837F").ss(2,1,1).p("ApMlhISZBTIl4Jwg");
	this.shape_169.setTransform(50.475,53.95);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f().s("#19837F").ss(2,1,1).p("ApKldISVBNIlvJug");
	this.shape_170.setTransform(50.25,54.075);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f().s("#19837F").ss(2,1,1).p("ApHlaISPBGIlmJvg");
	this.shape_171.setTransform(50.025,54.225);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f().s("#19837F").ss(2,1,1).p("ApElWISJA/IldJug");
	this.shape_172.setTransform(49.8,54.375);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f().s("#19837F").ss(2,1,1).p("ApBlSISDA4IlTJtg");
	this.shape_173.setTransform(49.575,54.525);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f().s("#19837F").ss(2,1,1).p("Ao/lPIR/AyIlKJtg");
	this.shape_174.setTransform(49.35,54.675);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f().s("#19837F").ss(2,1,1).p("Ao8lLIR5ArIlBJsg");
	this.shape_175.setTransform(49.125,54.8);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f().s("#19837F").ss(2,1,1).p("Ao5lIIRzAkIk4Jsg");
	this.shape_176.setTransform(48.9,54.95);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f().s("#19837F").ss(2,1,1).p("Ao2lEIRtAeIkuJrg");
	this.shape_177.setTransform(48.675,55.1);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f().s("#19837F").ss(2,1,1).p("Ao0lAIRpAWIkmJrg");
	this.shape_178.setTransform(48.45,55.225);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f().s("#19837F").ss(2,1,1).p("Aoxk9IRjAQIkcJrg");
	this.shape_179.setTransform(48.225,55.4);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f().s("#19837F").ss(2,1,1).p("Aouk5IRdAJIkSJqg");
	this.shape_180.setTransform(48,55.55);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f().s("#19837F").ss(2,1,1).p("Aork1IRXACIkJJpg");
	this.shape_181.setTransform(47.775,55.675);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f().s("#19837F").ss(2,1,1).p("AopkwIRTgEIkBJpg");
	this.shape_182.setTransform(47.575,55.6);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f().s("#19837F").ss(2,1,1).p("AomkoIRNgMIj3Jpg");
	this.shape_183.setTransform(47.375,55.375);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f().s("#19837F").ss(2,1,1).p("AojkhIRHgTIjuJog");
	this.shape_184.setTransform(47.15,55.2);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f().s("#19837F").ss(2,1,1).p("AogkaIRBgZIjkJng");
	this.shape_185.setTransform(46.925,55.025);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f().s("#19837F").ss(2,1,1).p("AoekTIQ9ggIjcJng");
	this.shape_186.setTransform(46.7,54.8);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f().s("#19837F").ss(2,1,1).p("AobkMIQ3gnIjSJng");
	this.shape_187.setTransform(46.475,54.625);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f().s("#19837F").ss(2,1,1).p("AoYkFIQxguIjJJng");
	this.shape_188.setTransform(46.25,54.4);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f().s("#19837F").ss(2,1,1).p("AoVj+IQrg0Ii/Jlg");
	this.shape_189.setTransform(46.025,54.225);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f().s("#19837F").ss(2,1,1).p("AoTj3IQng7Ii3Jlg");
	this.shape_190.setTransform(45.8,54.05);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f().s("#19837F").ss(2,1,1).p("AoQjwIQhhCIitJlg");
	this.shape_191.setTransform(45.575,53.825);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f().s("#19837F").ss(2,1,1).p("AoNjpIQbhJIikJlg");
	this.shape_192.setTransform(45.35,53.65);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f().s("#19837F").ss(2,1,1).p("AoKjiIQVhPIiaJjg");
	this.shape_193.setTransform(45.125,53.425);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f().s("#19837F").ss(2,1,1).p("AoIjbIQRhWIiSJjg");
	this.shape_194.setTransform(44.9,53.25);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f().s("#19837F").ss(2,1,1).p("AoFjUIQLhdIiIJjg");
	this.shape_195.setTransform(44.675,53.075);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f().s("#19837F").ss(2,1,1).p("AoCjNIQFhkIh/Jjg");
	this.shape_196.setTransform(44.475,52.85);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f().s("#19837F").ss(2,1,1).p("An/jGIP/hqIh1Jhg");
	this.shape_197.setTransform(44.25,52.675);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f().s("#19837F").ss(2,1,1).p("An8i/IP5hxIhsJhg");
	this.shape_198.setTransform(44.025,52.45);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f().s("#19837F").ss(2,1,1).p("An6i3IP1h5IhkJhg");
	this.shape_199.setTransform(43.8,52.275);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f().s("#19837F").ss(2,1,1).p("An3iwIPvh/IhaJgg");
	this.shape_200.setTransform(43.575,52.1);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f().s("#19837F").ss(2,1,1).p("An0ipIPpiGIhQJfg");
	this.shape_201.setTransform(43.35,51.875);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f().s("#19837F").ss(2,1,1).p("AnxiiIPjiNIhHJfg");
	this.shape_202.setTransform(43.125,51.7);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f().s("#19837F").ss(2,1,1).p("AnvicIPfiTIg+Jfg");
	this.shape_203.setTransform(42.9,51.5);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f().s("#19837F").ss(2,1,1).p("AnsiUIPZibIg1Jfg");
	this.shape_204.setTransform(42.675,51.3);

	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f().s("#19837F").ss(2,1,1).p("AnpiNIPTihIgsJdg");
	this.shape_205.setTransform(42.45,51.125);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f().s("#19837F").ss(2,1,1).p("AnmiGIPNioIgiJdg");
	this.shape_206.setTransform(42.225,50.9);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f().s("#19837F").ss(2,1,1).p("Ankh/IPJivIgZJdg");
	this.shape_207.setTransform(42,50.725);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f().s("#19837F").ss(2,1,1).p("Anhh4IPDi2IgQJdg");
	this.shape_208.setTransform(41.775,50.525);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f().s("#19837F").ss(2,1,1).p("AnehxIO9i8IgHJbg");
	this.shape_209.setTransform(41.55,50.325);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f().s("#19837F").ss(2,1,1).p("AnchqIO3jDIACJbg");
	this.shape_210.setTransform(41.475,50.125);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f().s("#19837F").ss(2,1,1).p("AnehjIOxjKIAMJbg");
	this.shape_211.setTransform(41.725,49.925);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f().s("#19837F").ss(2,1,1).p("AnghcIOsjRIAVJbg");
	this.shape_212.setTransform(41.95,49.75);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f().s("#19837F").ss(2,1,1).p("AnihVIOnjYIAeJbg");
	this.shape_213.setTransform(42.2,49.55);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f().s("#19837F").ss(2,1,1).p("AnkhOIOhjeIAoJZg");
	this.shape_214.setTransform(42.425,49.35);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f().s("#19837F").ss(2,1,1).p("AnmhGIOcjmIAxJZg");
	this.shape_215.setTransform(42.675,49.15);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f().s("#19837F").ss(2,1,1).p("AnohAIOXjsIA6JZg");
	this.shape_216.setTransform(42.9,48.95);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f().s("#19837F").ss(2,1,1).p("Anqg5IORjyIBEJXg");
	this.shape_217.setTransform(43.15,48.775);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f().s("#19837F").ss(2,1,1).p("AnrgyIOLj5IBMJXg");
	this.shape_218.setTransform(43.375,48.575);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f().s("#19837F").ss(2,1,1).p("AntgqIOFkBIBWJXg");
	this.shape_219.setTransform(43.625,48.375);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f().s("#19837F").ss(2,1,1).p("AnvgjIOAkIIBfJXg");
	this.shape_220.setTransform(43.85,48.175);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f().s("#19837F").ss(2,1,1).p("AnxgcIN7kOIBoJVg");
	this.shape_221.setTransform(44.1,47.975);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f().s("#19837F").ss(2,1,1).p("AnzgWIN1kUIByJVg");
	this.shape_222.setTransform(44.325,47.8);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f().s("#19837F").ss(2,1,1).p("An1gPINwkbIB7JVg");
	this.shape_223.setTransform(44.575,47.6);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f().s("#19837F").ss(2,1,1).p("An2gHINqkjICDJVg");
	this.shape_224.setTransform(44.825,47.4);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#19837F").ss(2,1,1).p("An4AAINkkqICNJUg");
	this.shape_225.setTransform(45.075,47.2);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f().s("#19837F").ss(2,1,1).p("An6AGINfkvICWJTg");
	this.shape_226.setTransform(45.3,47.025);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f().s("#19837F").ss(2,1,1).p("An8ANINZk2ICgJTg");
	this.shape_227.setTransform(45.55,46.825);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f().s("#19837F").ss(2,1,1).p("An+AUINUk9ICpJTg");
	this.shape_228.setTransform(45.775,46.625);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f().s("#19837F").ss(2,1,1).p("AoAAbINPlDICyJRg");
	this.shape_229.setTransform(46.025,46.425);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f().s("#19837F").ss(2,1,1).p("AoCAiINKlKIC7JRg");
	this.shape_230.setTransform(46.25,46.225);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f().s("#19837F").ss(2,1,1).p("AoEApINElRIDFJRg");
	this.shape_231.setTransform(46.5,46.05);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f().s("#19837F").ss(2,1,1).p("AoFAwIM+lYIDNJRg");
	this.shape_232.setTransform(46.725,45.85);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f().s("#19837F").ss(2,1,1).p("AoHA3IM4lfIDXJRg");
	this.shape_233.setTransform(46.975,45.65);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f().s("#19837F").ss(2,1,1).p("AoJA/IMzlmIDgJPg");
	this.shape_234.setTransform(47.2,45.45);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f().s("#19837F").ss(2,1,1).p("AoLBGIMultIDpJPg");
	this.shape_235.setTransform(47.45,45.25);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f().s("#19837F").ss(2,1,1).p("AoNBMIMolzIDzJPg");
	this.shape_236.setTransform(47.675,45.075);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f().s("#19837F").ss(2,1,1).p("AoPBTIMjl5ID8JNg");
	this.shape_237.setTransform(47.925,44.875);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f().s("#19837F").ss(2,1,1).p("AoQBaIMcmAIEFJNg");
	this.shape_238.setTransform(48.175,44.675);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f().s("#19837F").ss(2,1,1).p("AoSBiIMXmIIEOJNg");
	this.shape_239.setTransform(48.425,44.475);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f().s("#19837F").ss(2,1,1).p("AoUBpIMSmPIEXJNg");
	this.shape_240.setTransform(48.65,44.275);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("#19837F").ss(2,1,1).p("AoWBvIMMmVIEhJMg");
	this.shape_241.setTransform(48.9,44.1);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f().s("#19837F").ss(2,1,1).p("AoYB3IMHmcIEqJLg");
	this.shape_242.setTransform(49.125,43.875);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f().s("#19837F").ss(2,1,1).p("AoaB+IMBmjIE0JLg");
	this.shape_243.setTransform(49.375,43.7);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f().s("#19837F").ss(2,1,1).p("AocCFIL8mqIE9JKg");
	this.shape_244.setTransform(49.6,43.5);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f().s("#19837F").ss(2,1,1).p("AodCMIL2mxIFGJLg");
	this.shape_245.setTransform(49.85,43.3);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("#19837F").ss(2,1,1).p("AofCTILwm3IFPJJg");
	this.shape_246.setTransform(50.075,43.125);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f().s("#19837F").ss(2,1,1).p("AohCaILrm+IFYJJg");
	this.shape_247.setTransform(50.325,42.9);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f().s("#19837F").ss(2,1,1).p("AojChILmnFIFhJJg");
	this.shape_248.setTransform(50.55,42.725);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("#19837F").ss(2,1,1).p("AolCoILgnLIFrJIg");
	this.shape_249.setTransform(50.8,42.55);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f().s("#19837F").ss(2,1,1).p("AonCvILbnSIF0JHg");
	this.shape_250.setTransform(51.025,42.325);

	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f().s("#19837F").ss(2,1,1).p("AopC2ILVnZIF+JHg");
	this.shape_251.setTransform(51.275,42.15);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#19837F").ss(2,1,1).p("AoqC9ILPngIGGJHg");
	this.shape_252.setTransform(51.525,41.925);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f().s("#19837F").ss(2,1,1).p("AosDEILJnnIGQJHg");
	this.shape_253.setTransform(51.775,41.75);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f().s("#19837F").ss(2,1,1).p("AouDLILEntIGZJFg");
	this.shape_254.setTransform(52,41.575);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f().s("#19837F").ss(2,1,1).p("AowDSIK/n0IGiJFg");
	this.shape_255.setTransform(52.25,41.35);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f().s("#19837F").ss(2,1,1).p("AoyDZIK5n7IGsJFg");
	this.shape_256.setTransform(52.475,41.175);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f().s("#19837F").ss(2,1,1).p("Ao0DgIK0oCIG1JFg");
	this.shape_257.setTransform(52.725,40.95);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f().s("#19837F").ss(2,1,1).p("Ao2DnIKvoIIG+JDg");
	this.shape_258.setTransform(52.95,40.775);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f().s("#19837F").ss(2,1,1).p("Ao4DvIKpoQIHIJDg");
	this.shape_259.setTransform(53.2,40.6);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f().s("#19837F").ss(2,1,1).p("Ao5D2IKjoXIHQJDg");
	this.shape_260.setTransform(53.425,40.375);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f().s("#19837F").ss(2,1,1).p("Ao7D9IKdoeIHaJDg");
	this.shape_261.setTransform(53.675,40.2);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f().s("#19837F").ss(2,1,1).p("Ao9EEIKYokIHjJBg");
	this.shape_262.setTransform(53.9,39.975);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f().s("#19837F").ss(2,1,1).p("Ao/ELIKTorIHsJBg");
	this.shape_263.setTransform(54.15,39.8);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f().s("#19837F").ss(2,1,1).p("ApBESIKNoyIH2JBg");
	this.shape_264.setTransform(54.375,39.625);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f().s("#19837F").ss(2,1,1).p("ApDEZIKIo5IH/JBg");
	this.shape_265.setTransform(54.65,39.4);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f().s("#19837F").ss(2,1,1).p("ApEEgIKCo/IIHI/g");
	this.shape_266.setTransform(54.875,39.225);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f().s("#19837F").ss(2,1,1).p("ApGEkIJ8pHIIRI/g");
	this.shape_267.setTransform(55.125,39.35);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f().s("#19837F").ss(2,1,1).p("ApIEnIJ3pNIIaI/g");
	this.shape_268.setTransform(55.35,39.525);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f().s("#19837F").ss(2,1,1).p("ApKEqIJxpTIIkI+g");
	this.shape_269.setTransform(55.6,39.725);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f().s("#19837F").ss(2,1,1).p("ApMEuIJspbIItI+g");
	this.shape_270.setTransform(55.825,39.875);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f().s("#19837F").ss(2,1,1).p("ApOExIJnphII2I9g");
	this.shape_271.setTransform(56.075,40.05);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f().s("#19837F").ss(2,1,1).p("ApQE1IJipoII/I9g");
	this.shape_272.setTransform(56.3,40.2);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f().s("#19837F").ss(2,1,1).p("ApSE4IJcpvIJJI8g");
	this.shape_273.setTransform(56.55,40.375);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f().s("#19837F").ss(2,1,1).p("ApTE7IJWp1IJRI8g");
	this.shape_274.setTransform(56.775,40.55);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f().s("#19837F").ss(2,1,1).p("ApVE/IJRp9IJaI7g");
	this.shape_275.setTransform(57.025,40.725);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f().s("#19837F").ss(2,1,1).p("ApXFCIJMqDIJjI6g");
	this.shape_276.setTransform(57.25,40.9);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f().s("#19837F").ss(2,1,1).p("ApZFGIJGqLIJtI7g");
	this.shape_277.setTransform(57.5,41.05);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f().s("#19837F").ss(2,1,1).p("ApbFJIJBqRIJ2I6g");
	this.shape_278.setTransform(57.725,41.225);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f().s("#19837F").ss(2,1,1).p("ApdFMII7qXIKAI5g");
	this.shape_279.setTransform(58,41.375);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f().s("#19837F").ss(2,1,1).p("ApeFQII1qfIKII5g");
	this.shape_280.setTransform(58.225,41.575);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f().s("#19837F").ss(2,1,1).p("ApgFTIIwqlIKRI4g");
	this.shape_281.setTransform(58.475,41.75);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f().s("#19837F").ss(2,1,1).p("ApiFXIIrqtIKaI4g");
	this.shape_282.setTransform(58.7,41.9);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f().s("#19837F").ss(2,1,1).p("ApkFaIIlqzIKkI3g");
	this.shape_283.setTransform(58.95,42.075);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f().s("#19837F").ss(2,1,1).p("ApmFdIIgq5IKtI3g");
	this.shape_284.setTransform(59.175,42.225);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f().s("#19837F").ss(2,1,1).p("ApoFhIIarBIK3I2g");
	this.shape_285.setTransform(59.425,42.425);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f().s("#19837F").ss(2,1,1).p("ApqFkIIVrHILAI1g");
	this.shape_286.setTransform(59.65,42.6);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f().s("#19837F").ss(2,1,1).p("ApsFoIIPrPILKI2g");
	this.shape_287.setTransform(59.9,42.75);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f().s("#19837F").ss(2,1,1).p("AptFrIIJrVILSI1g");
	this.shape_288.setTransform(60.125,42.925);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f().s("#19837F").ss(2,1,1).p("ApvFuIIErbILbI0g");
	this.shape_289.setTransform(60.375,43.075);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f().s("#19837F").ss(2,1,1).p("ApxFyIH+rjILlI0g");
	this.shape_290.setTransform(60.6,43.275);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f().s("#19837F").ss(2,1,1).p("ApzF1IH5rpILuIzg");
	this.shape_291.setTransform(60.85,43.45);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f().s("#19837F").ss(2,1,1).p("Ap1F5IH0rxIL3I0g");
	this.shape_292.setTransform(61.075,43.6);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f().s("#19837F").ss(2,1,1).p("Ap3F8IHur3IMBIyg");
	this.shape_293.setTransform(61.35,43.775);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f().s("#19837F").ss(2,1,1).p("Ap4F/IHor9IMJIyg");
	this.shape_294.setTransform(61.575,43.925);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f().s("#19837F").ss(2,1,1).p("Ap6GDIHisFIMTIyg");
	this.shape_295.setTransform(61.825,44.125);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f().s("#19837F").ss(2,1,1).p("Ap8GGIHdsLIMcIxg");
	this.shape_296.setTransform(62.05,44.3);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f().s("#19837F").ss(2,1,1).p("Ap+GKIHXsSIMmIwg");
	this.shape_297.setTransform(62.3,44.45);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f().s("#19837F").ss(2,1,1).p("AqAGNIHSsZIMvIwg");
	this.shape_298.setTransform(62.525,44.625);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f().s("#19837F").ss(2,1,1).p("AqCGQIHNsfIM4Ivg");
	this.shape_299.setTransform(62.775,44.775);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f().s("#19837F").ss(2,1,1).p("AqDGUIHHsnINBIvg");
	this.shape_300.setTransform(63,44.975);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f().s("#19837F").ss(2,1,1).p("AqGGXIHCstINLIug");
	this.shape_301.setTransform(63.25,45.15);

	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f().s("#19837F").ss(2,1,1).p("AqHGbIG8s1INTIvg");
	this.shape_302.setTransform(63.475,45.3);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#19837F").ss(2,1,1).p("AqJGeIG2s7INdItg");
	this.shape_303.setTransform(63.725,45.475);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f().s("#19837F").ss(2,1,1).p("AqLGhIGxtBINmItg");
	this.shape_304.setTransform(63.95,45.625);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f().s("#19837F").ss(2,1,1).p("AqNGlIGrtJINwItg");
	this.shape_305.setTransform(64.2,45.825);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f().s("#19837F").ss(2,1,1).p("AqPGoIGntPIN4Isg");
	this.shape_306.setTransform(64.425,46);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f().s("#19837F").ss(2,1,1).p("AqQGsIGgtXIOCIsg");
	this.shape_307.setTransform(64.7,46.15);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f().s("#19837F").ss(2,1,1).p("AqSGvIGbtdIOKIrg");
	this.shape_308.setTransform(64.925,46.325);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f().s("#19837F").ss(2,1,1).p("AqUGyIGVtjIOUIqg");
	this.shape_309.setTransform(65.175,46.475);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f().s("#19837F").ss(2,1,1).p("AqWG2IGQtrIOdIqg");
	this.shape_310.setTransform(65.4,46.675);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f().s("#19837F").ss(2,1,1).p("AqYG5IGKtxIOnIpg");
	this.shape_311.setTransform(65.65,46.825);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f().s("#19837F").ss(2,1,1).p("AqaG9IGFt5IOwIqg");
	this.shape_312.setTransform(65.875,47);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f().s("#19837F").ss(2,1,1).p("AqcHAIGAt/IO5Iog");
	this.shape_313.setTransform(66.125,47.175);

	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f().s("#19837F").ss(2,1,1).p("AqeHDIF6uFIPDIog");
	this.shape_314.setTransform(66.35,47.325);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f().s("#19837F").ss(2,1,1).p("AqgHHIF1uNIPMIog");
	this.shape_315.setTransform(66.6,47.525);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f().s("#19837F").ss(2,1,1).p("AqhHKIFvuTIPUIng");
	this.shape_316.setTransform(66.825,47.675);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f().s("#19837F").ss(2,1,1).p("AqjHOIFpubIPeIng");
	this.shape_317.setTransform(67.075,47.85);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f().s("#19837F").ss(2,1,1).p("AqlHRIFkuhIPnImg");
	this.shape_318.setTransform(67.3,48.025);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f().s("#19837F").ss(2,1,1).p("AqnHUIFeunIPxIlg");
	this.shape_319.setTransform(67.55,48.175);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f().s("#19837F").ss(2,1,1).p("AqpHYIFZuvIP6Ilg");
	this.shape_320.setTransform(67.775,48.375);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f().s("#19837F").ss(2,1,1).p("AqrHbIFUu1IQDIkg");
	this.shape_321.setTransform(68.05,48.525);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f().s("#19837F").ss(2,1,1).p("AqsHfIFNu8IQMIkg");
	this.shape_322.setTransform(68.275,48.7);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f().s("#19837F").ss(2,1,1).p("AquHiIFIvDIQVIkg");
	this.shape_323.setTransform(68.525,48.875);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f().s("#19837F").ss(2,1,1).p("AqwHlIFCvJIQfIjg");
	this.shape_324.setTransform(68.75,49.025);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f().s("#19837F").ss(2,1,1).p("AqyHpIE9vRIQoIjg");
	this.shape_325.setTransform(69,49.225);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f().s("#19837F").ss(2,1,1).p("Aq0HsIE4vXIQxIig");
	this.shape_326.setTransform(69.225,49.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).to({state:[{t:this.shape_119}]},1).to({state:[{t:this.shape_120}]},1).to({state:[{t:this.shape_121}]},1).to({state:[{t:this.shape_122}]},1).to({state:[{t:this.shape_123}]},1).to({state:[{t:this.shape_124}]},1).to({state:[{t:this.shape_125}]},1).to({state:[{t:this.shape_126}]},1).to({state:[{t:this.shape_127}]},1).to({state:[{t:this.shape_128}]},1).to({state:[{t:this.shape_129}]},1).to({state:[{t:this.shape_130}]},1).to({state:[{t:this.shape_131}]},1).to({state:[{t:this.shape_132}]},1).to({state:[{t:this.shape_133}]},1).to({state:[{t:this.shape_134}]},1).to({state:[{t:this.shape_135}]},1).to({state:[{t:this.shape_136}]},1).to({state:[{t:this.shape_137}]},1).to({state:[{t:this.shape_138}]},1).to({state:[{t:this.shape_139}]},1).to({state:[{t:this.shape_140}]},1).to({state:[{t:this.shape_141}]},1).to({state:[{t:this.shape_142}]},1).to({state:[{t:this.shape_143}]},1).to({state:[{t:this.shape_144}]},1).to({state:[{t:this.shape_145}]},1).to({state:[{t:this.shape_146}]},1).to({state:[{t:this.shape_147}]},1).to({state:[{t:this.shape_148}]},1).to({state:[{t:this.shape_149}]},1).to({state:[{t:this.shape_150}]},1).to({state:[{t:this.shape_151}]},1).to({state:[{t:this.shape_152}]},1).to({state:[{t:this.shape_153}]},1).to({state:[{t:this.shape_154}]},1).to({state:[{t:this.shape_155}]},1).to({state:[{t:this.shape_156}]},1).to({state:[{t:this.shape_157}]},1).to({state:[{t:this.shape_158}]},1).to({state:[{t:this.shape_159}]},1).to({state:[{t:this.shape_160}]},1).to({state:[{t:this.shape_161}]},1).to({state:[{t:this.shape_162}]},1).to({state:[{t:this.shape_163}]},1).to({state:[{t:this.shape_164}]},1).to({state:[{t:this.shape_165}]},1).to({state:[{t:this.shape_166}]},1).to({state:[{t:this.shape_167}]},1).to({state:[{t:this.shape_168}]},1).to({state:[{t:this.shape_169}]},1).to({state:[{t:this.shape_170}]},1).to({state:[{t:this.shape_171}]},1).to({state:[{t:this.shape_172}]},1).to({state:[{t:this.shape_173}]},1).to({state:[{t:this.shape_174}]},1).to({state:[{t:this.shape_175}]},1).to({state:[{t:this.shape_176}]},1).to({state:[{t:this.shape_177}]},1).to({state:[{t:this.shape_178}]},1).to({state:[{t:this.shape_179}]},1).to({state:[{t:this.shape_180}]},1).to({state:[{t:this.shape_181}]},1).to({state:[{t:this.shape_182}]},1).to({state:[{t:this.shape_183}]},1).to({state:[{t:this.shape_184}]},1).to({state:[{t:this.shape_185}]},1).to({state:[{t:this.shape_186}]},1).to({state:[{t:this.shape_187}]},1).to({state:[{t:this.shape_188}]},1).to({state:[{t:this.shape_189}]},1).to({state:[{t:this.shape_190}]},1).to({state:[{t:this.shape_191}]},1).to({state:[{t:this.shape_192}]},1).to({state:[{t:this.shape_193}]},1).to({state:[{t:this.shape_194}]},1).to({state:[{t:this.shape_195}]},1).to({state:[{t:this.shape_196}]},1).to({state:[{t:this.shape_197}]},1).to({state:[{t:this.shape_198}]},1).to({state:[{t:this.shape_199}]},1).to({state:[{t:this.shape_200}]},1).to({state:[{t:this.shape_201}]},1).to({state:[{t:this.shape_202}]},1).to({state:[{t:this.shape_203}]},1).to({state:[{t:this.shape_204}]},1).to({state:[{t:this.shape_205}]},1).to({state:[{t:this.shape_206}]},1).to({state:[{t:this.shape_207}]},1).to({state:[{t:this.shape_208}]},1).to({state:[{t:this.shape_209}]},1).to({state:[{t:this.shape_210}]},1).to({state:[{t:this.shape_211}]},1).to({state:[{t:this.shape_212}]},1).to({state:[{t:this.shape_213}]},1).to({state:[{t:this.shape_214}]},1).to({state:[{t:this.shape_215}]},1).to({state:[{t:this.shape_216}]},1).to({state:[{t:this.shape_217}]},1).to({state:[{t:this.shape_218}]},1).to({state:[{t:this.shape_219}]},1).to({state:[{t:this.shape_220}]},1).to({state:[{t:this.shape_221}]},1).to({state:[{t:this.shape_222}]},1).to({state:[{t:this.shape_223}]},1).to({state:[{t:this.shape_224}]},1).to({state:[{t:this.shape_225}]},1).to({state:[{t:this.shape_226}]},1).to({state:[{t:this.shape_227}]},1).to({state:[{t:this.shape_228}]},1).to({state:[{t:this.shape_229}]},1).to({state:[{t:this.shape_230}]},1).to({state:[{t:this.shape_231}]},1).to({state:[{t:this.shape_232}]},1).to({state:[{t:this.shape_233}]},1).to({state:[{t:this.shape_234}]},1).to({state:[{t:this.shape_235}]},1).to({state:[{t:this.shape_236}]},1).to({state:[{t:this.shape_237}]},1).to({state:[{t:this.shape_238}]},1).to({state:[{t:this.shape_239}]},1).to({state:[{t:this.shape_240}]},1).to({state:[{t:this.shape_241}]},1).to({state:[{t:this.shape_242}]},1).to({state:[{t:this.shape_243}]},1).to({state:[{t:this.shape_244}]},1).to({state:[{t:this.shape_245}]},1).to({state:[{t:this.shape_246}]},1).to({state:[{t:this.shape_247}]},1).to({state:[{t:this.shape_248}]},1).to({state:[{t:this.shape_249}]},1).to({state:[{t:this.shape_250}]},1).to({state:[{t:this.shape_251}]},1).to({state:[{t:this.shape_252}]},1).to({state:[{t:this.shape_253}]},1).to({state:[{t:this.shape_254}]},1).to({state:[{t:this.shape_255}]},1).to({state:[{t:this.shape_256}]},1).to({state:[{t:this.shape_257}]},1).to({state:[{t:this.shape_258}]},1).to({state:[{t:this.shape_259}]},1).to({state:[{t:this.shape_260}]},1).to({state:[{t:this.shape_261}]},1).to({state:[{t:this.shape_262}]},1).to({state:[{t:this.shape_263}]},1).to({state:[{t:this.shape_264}]},1).to({state:[{t:this.shape_265}]},1).to({state:[{t:this.shape_266}]},1).to({state:[{t:this.shape_267}]},1).to({state:[{t:this.shape_268}]},1).to({state:[{t:this.shape_269}]},1).to({state:[{t:this.shape_270}]},1).to({state:[{t:this.shape_271}]},1).to({state:[{t:this.shape_272}]},1).to({state:[{t:this.shape_273}]},1).to({state:[{t:this.shape_274}]},1).to({state:[{t:this.shape_275}]},1).to({state:[{t:this.shape_276}]},1).to({state:[{t:this.shape_277}]},1).to({state:[{t:this.shape_278}]},1).to({state:[{t:this.shape_279}]},1).to({state:[{t:this.shape_280}]},1).to({state:[{t:this.shape_281}]},1).to({state:[{t:this.shape_282}]},1).to({state:[{t:this.shape_283}]},1).to({state:[{t:this.shape_284}]},1).to({state:[{t:this.shape_285}]},1).to({state:[{t:this.shape_286}]},1).to({state:[{t:this.shape_287}]},1).to({state:[{t:this.shape_288}]},1).to({state:[{t:this.shape_289}]},1).to({state:[{t:this.shape_290}]},1).to({state:[{t:this.shape_291}]},1).to({state:[{t:this.shape_292}]},1).to({state:[{t:this.shape_293}]},1).to({state:[{t:this.shape_294}]},1).to({state:[{t:this.shape_295}]},1).to({state:[{t:this.shape_296}]},1).to({state:[{t:this.shape_297}]},1).to({state:[{t:this.shape_298}]},1).to({state:[{t:this.shape_299}]},1).to({state:[{t:this.shape_300}]},1).to({state:[{t:this.shape_301}]},1).to({state:[{t:this.shape_302}]},1).to({state:[{t:this.shape_303}]},1).to({state:[{t:this.shape_304}]},1).to({state:[{t:this.shape_305}]},1).to({state:[{t:this.shape_306}]},1).to({state:[{t:this.shape_307}]},1).to({state:[{t:this.shape_308}]},1).to({state:[{t:this.shape_309}]},1).to({state:[{t:this.shape_310}]},1).to({state:[{t:this.shape_311}]},1).to({state:[{t:this.shape_312}]},1).to({state:[{t:this.shape_313}]},1).to({state:[{t:this.shape_314}]},1).to({state:[{t:this.shape_315}]},1).to({state:[{t:this.shape_316}]},1).to({state:[{t:this.shape_317}]},1).to({state:[{t:this.shape_318}]},1).to({state:[{t:this.shape_319}]},1).to({state:[{t:this.shape_320}]},1).to({state:[{t:this.shape_321}]},1).to({state:[{t:this.shape_322}]},1).to({state:[{t:this.shape_323}]},1).to({state:[{t:this.shape_324}]},1).to({state:[{t:this.shape_325}]},1).to({state:[{t:this.shape_326}]},1).to({state:[{t:this.shape}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Анимация16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(82,206,120,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,68.4).s().p("AgVMJQgIlCAAnHQAAnGAIlDQAJlCAMAAQAMAAAJFCQAJFDAAHGQAAHHgJFCQgJFDgMAAQgMAAgJlDg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-3,-109.9,6,219.9);
p.frameBounds = [rect];


(lib.Анимация15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.rf(["rgba(82,206,120,0.498)","rgba(82,206,182,0)"],[0,0.78],0,0,0,0,0,68.4).s().p("AgVHjQgIjIAAkbQAAkaAIjJQAJjIAMAAQAMAAAJDIQAJDJAAEaQAAEbgJDIQgJDJgMAAQgMAAgJjJg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-3,-68.3,6,136.7);
p.frameBounds = [rect];


(lib.Символ4копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_4__копия_2_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(23.1,16.5,1,1,0,0,0,23.1,16.5);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4копия2, rect = new cjs.Rectangle(-6.2,0,58.7,33.1), [rect]);


(lib.Символ4копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_4__копия_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(23.1,16.5,1,1,0,0,0,23.1,16.5);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4копия, rect = new cjs.Rectangle(-6.2,0,58.7,33.1), [rect]);


(lib.Символ4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_4_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(23.1,16,1,1,0,0,0,23.1,16);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(1));

}).prototype = getMCSymbolPrototype(lib.Символ4, rect = new cjs.Rectangle(-1,-1,48.2,34.1), [rect]);


(lib.Символ3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Анимация15("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(3,68.35);
	this.instance.alpha = 0;

	this.instance_1 = new lib.Анимация16("synched",0);
	this.instance_1.parent = this;
	this.instance_1.setTransform(3,68.4,1,1.5132);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true,scaleY:1.5132,y:68.4,alpha:1},21).to({_off:false,scaleY:0.2977,y:68.35,alpha:0.1992},62).wait(621).to({scaleY:1},0).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).to({_off:false},21).to({_off:true,scaleY:0.2977,y:68.35,alpha:0.1992},62).wait(622));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(0,0,6,136.7);
p.frameBounds = [rect, new cjs.Rectangle(0,-1.6,6,140.1), new cjs.Rectangle(0,-3.3,6,143.4), new cjs.Rectangle(0,-5,6,146.7), new cjs.Rectangle(0,-6.6,6,150.1), new cjs.Rectangle(0,-8.3,6,153.4), new cjs.Rectangle(0,-10,6,156.8), new cjs.Rectangle(0,-11.6,6,160.1), new cjs.Rectangle(0,-13.3,6,163.4), new cjs.Rectangle(0,-15,6,166.8), new cjs.Rectangle(0,-16.7,6,170.1), new cjs.Rectangle(0,-18.3,6,173.5), new cjs.Rectangle(0,-19.9,6,176.8), new cjs.Rectangle(0,-21.6,6,180.2), new cjs.Rectangle(0,-23.3,6,183.5), new cjs.Rectangle(0,-25,6,186.8), new cjs.Rectangle(0,-26.6,6,190.2), new cjs.Rectangle(0,-28.3,6,193.5), new cjs.Rectangle(0,-30,6,196.9), new cjs.Rectangle(0,-31.6,6,200.2), new cjs.Rectangle(0,-33.3,6,203.5), new cjs.Rectangle(0,-97.9,6,332.7), new cjs.Rectangle(0,-95.8,6,328.4), new cjs.Rectangle(0,-93.6,6,324.1), new cjs.Rectangle(0,-91.5,6,319.8), new cjs.Rectangle(0,-89.3,6,315.5), new cjs.Rectangle(0,-87.1,6,311.2), new cjs.Rectangle(0,-85,6,306.9), new cjs.Rectangle(0,-82.8,6,302.5), new cjs.Rectangle(0,-80.7,6,298.3), new cjs.Rectangle(0,-78.5,6,294), new cjs.Rectangle(0,-76.3,6,289.6), new cjs.Rectangle(0,-74.1,6,285.3), new cjs.Rectangle(0,-72.1,6,281), new cjs.Rectangle(0,-69.9,6,276.7), new cjs.Rectangle(0,-67.7,6,272.4), new cjs.Rectangle(0,-65.6,6,268), new cjs.Rectangle(0,-63.4,6,263.8), new cjs.Rectangle(0,-61.3,6,259.4), new cjs.Rectangle(0,-59.1,6,255.2), new cjs.Rectangle(0,-57,6,250.9), new cjs.Rectangle(0,-54.8,6,246.6), new cjs.Rectangle(0,-52.6,6,242.2), new cjs.Rectangle(0,-50.5,6,237.9), new cjs.Rectangle(0,-48.4,6,233.6), new cjs.Rectangle(0,-46.2,6,229.3), new cjs.Rectangle(0,-44,6,225), new cjs.Rectangle(0,-41.9,6,220.7), new cjs.Rectangle(0,-39.8,6,216.4), new cjs.Rectangle(0,-37.6,6,212), new cjs.Rectangle(0,-35.5,6,207.7), new cjs.Rectangle(0,-33.3,6,203.4), new cjs.Rectangle(0,-31.1,6,199.1), new cjs.Rectangle(0,-29,6,194.8), new cjs.Rectangle(0,-26.9,6,190.5), new cjs.Rectangle(0,-24.8,6,186.2), new cjs.Rectangle(0,-22.6,6,181.9), new cjs.Rectangle(0,-20.4,6,177.5), new cjs.Rectangle(0,-18.3,6,173.3), new cjs.Rectangle(0,-16.1,6,168.9), new cjs.Rectangle(0,-14,6,164.6), new cjs.Rectangle(0,-11.8,6,160.3), new cjs.Rectangle(0,-9.6,6,156), new cjs.Rectangle(0,-7.5,6,151.7), new cjs.Rectangle(0,-5.3,6,147.4), new cjs.Rectangle(0,-3.2,6,143.1), new cjs.Rectangle(0,-1,6,138.8), new cjs.Rectangle(0,1.1,6,134.5), new cjs.Rectangle(0,3.3,6,130.1), new cjs.Rectangle(0,5.5,6,125.8), new cjs.Rectangle(0,7.6,6,121.5), new cjs.Rectangle(0,9.7,6,117.2), new cjs.Rectangle(0,11.9,6,112.9), new cjs.Rectangle(0,14.1,6,108.6), new cjs.Rectangle(0,16.2,6,104.3), new cjs.Rectangle(0,18.4,6,99.9), new cjs.Rectangle(0,20.6,6,95.6), new cjs.Rectangle(0,22.7,6,91.3), new cjs.Rectangle(0,24.8,6,87.1), new cjs.Rectangle(0,27,6,82.8), new cjs.Rectangle(0,29.2,6,78.4), new cjs.Rectangle(0,31.3,6,74.1), new cjs.Rectangle(0,33.4,6,69.8), rect=new cjs.Rectangle(0,48,6,40.7), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(0,0,6,136.7)];


(lib.Символ1копия2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_327 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(327).call(this.frame_327).wait(1));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_1__копия_2_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(144.1,49.3,1,1,0,0,0,144.1,49.3);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(328));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(75,6,138.3,86.7);
p.frameBounds = [rect, new cjs.Rectangle(74.5,5.8,138.1,87.2), new cjs.Rectangle(74,5.7,137.9,87.8), new cjs.Rectangle(73.4,5.5,137.7,88.3), new cjs.Rectangle(72.9,5.4,137.5,88.8), new cjs.Rectangle(72.4,5.2,137.3,89.3), new cjs.Rectangle(71.8,5.1,137.1,89.9), new cjs.Rectangle(71.3,4.9,136.9,90.4), new cjs.Rectangle(70.8,4.8,136.7,90.9), new cjs.Rectangle(70.2,4.7,136.5,91.4), new cjs.Rectangle(69.7,4.5,136.3,91.9), new cjs.Rectangle(69.2,4.4,136.1,92.4), new cjs.Rectangle(68.6,4.2,135.9,92.9), new cjs.Rectangle(68.1,4.1,135.7,93.5), new cjs.Rectangle(67.6,3.9,135.5,93.9), new cjs.Rectangle(67,3.8,135.4,94.5), new cjs.Rectangle(66.5,3.6,135.1,95), new cjs.Rectangle(66,3.5,135,95.5), new cjs.Rectangle(65.4,3.3,134.8,96.1), new cjs.Rectangle(64.9,3.2,134.5,96.6), new cjs.Rectangle(64.4,3,134.4,97.1), new cjs.Rectangle(63.9,2.9,134.1,97.6), new cjs.Rectangle(63.3,2.7,134,98.1), new cjs.Rectangle(62.8,2.6,133.8,98.7), new cjs.Rectangle(62.3,2.4,133.6,99.1), new cjs.Rectangle(61.7,2.3,133.4,99.7), new cjs.Rectangle(61.2,2.1,133.2,100.2), new cjs.Rectangle(60.7,2,133,100.7), new cjs.Rectangle(60.1,1.9,132.8,101.2), new cjs.Rectangle(59.6,1.7,132.6,101.8), new cjs.Rectangle(59.1,1.6,132.4,102.3), new cjs.Rectangle(58.5,1.4,132.2,102.8), new cjs.Rectangle(58,1.3,132,103.3), new cjs.Rectangle(57.5,1.1,131.8,103.8), new cjs.Rectangle(56.9,1,131.6,104.4), new cjs.Rectangle(56.4,0.8,131.4,104.9), new cjs.Rectangle(55.9,0.7,131.2,105.4), new cjs.Rectangle(55.3,0.5,131,105.9), new cjs.Rectangle(54.8,0.4,130.8,106.4), new cjs.Rectangle(54.3,0.2,130.6,107), new cjs.Rectangle(53.7,0.1,130.5,107.5), new cjs.Rectangle(53.2,-0.1,130.2,108), new cjs.Rectangle(52.7,-0.2,130,108.5), new cjs.Rectangle(52.1,-0.4,129.9,109.1), new cjs.Rectangle(51.6,-0.5,129.7,109.6), new cjs.Rectangle(51.1,-0.6,129.5,110.1), new cjs.Rectangle(50.5,-0.8,129.3,110.6), new cjs.Rectangle(50,-0.9,129.1,111.1), new cjs.Rectangle(49.5,-1.1,128.9,111.6), new cjs.Rectangle(49,-1.2,128.6,112.1), new cjs.Rectangle(48.4,-1.4,128.5,112.7), new cjs.Rectangle(47.9,-1.5,128.3,113.2), new cjs.Rectangle(47.4,-1.7,128.1,113.7), new cjs.Rectangle(46.8,-1.8,127.9,114.2), new cjs.Rectangle(46.3,-2,127.7,114.7), new cjs.Rectangle(45.8,-2.1,127.5,115.3), new cjs.Rectangle(45.2,-2.3,127.3,115.8), new cjs.Rectangle(44.7,-2.4,127.1,116.3), new cjs.Rectangle(44.2,-2.6,126.9,116.8), new cjs.Rectangle(43.6,-2.7,126.7,117.4), new cjs.Rectangle(43.1,-2.9,126.5,117.9), new cjs.Rectangle(42.6,-3,126.3,118.4), new cjs.Rectangle(42,-3.1,126.1,118.9), new cjs.Rectangle(41.5,-3.3,125.9,119.4), new cjs.Rectangle(41,-3.4,125.7,119.9), new cjs.Rectangle(40.4,-3.6,125.5,120.4), new cjs.Rectangle(39.9,-3.7,125.3,121), new cjs.Rectangle(39.4,-3.9,125.2,121.5), new cjs.Rectangle(38.8,-4,125,122), new cjs.Rectangle(38.3,-4.2,124.8,122.5), new cjs.Rectangle(37.8,-4.3,124.6,123), new cjs.Rectangle(37.2,-4.5,124.4,123.6), new cjs.Rectangle(36.7,-4.6,124.2,124.1), new cjs.Rectangle(36.2,-4.8,124,124.6), new cjs.Rectangle(35.7,-4.9,123.8,125.1), new cjs.Rectangle(35.1,-5.1,123.6,125.7), new cjs.Rectangle(34.6,-5.2,123.4,126.2), new cjs.Rectangle(34.1,-5.4,123.2,126.7), new cjs.Rectangle(33.5,-5.5,123,127.2), new cjs.Rectangle(33,-5.7,122.8,127.7), new cjs.Rectangle(32.5,-5.8,122.6,128.2), new cjs.Rectangle(31.9,-5.9,122.4,128.7), new cjs.Rectangle(31.4,-6.1,122.2,129.3), new cjs.Rectangle(30.9,-6.2,122,129.8), new cjs.Rectangle(30.3,-6.4,121.8,130.3), new cjs.Rectangle(29.8,-6.5,121.7,130.8), new cjs.Rectangle(29.3,-6.7,121.4,131.3), new cjs.Rectangle(28.7,-6.8,121.2,131.9), new cjs.Rectangle(28.2,-7,121,132.4), new cjs.Rectangle(27.7,-7.1,120.8,132.9), new cjs.Rectangle(27.1,-7.3,120.7,133.4), new cjs.Rectangle(26.6,-7.4,120.4,133.9), new cjs.Rectangle(26.1,-7.6,120.3,134.5), new cjs.Rectangle(25.5,-7.7,120.1,135), new cjs.Rectangle(25,-7.9,119.9,135.5), new cjs.Rectangle(24.5,-8,119.7,136), new cjs.Rectangle(23.9,-8.2,119.5,136.5), new cjs.Rectangle(23.4,-8.3,119.3,137), new cjs.Rectangle(22.9,-8.4,119.1,137.5), new cjs.Rectangle(22.3,-8.6,118.9,138), new cjs.Rectangle(21.8,-8.7,118.7,138.6), new cjs.Rectangle(21.3,-8.9,118.5,139.1), new cjs.Rectangle(20.8,-9,118.3,139.6), new cjs.Rectangle(20.2,-9.2,118.1,140.1), new cjs.Rectangle(19.7,-9.3,117.9,140.7), new cjs.Rectangle(19.2,-9.5,117.7,141.2), new cjs.Rectangle(18.6,-9.6,117.5,141.7), new cjs.Rectangle(18,-9,117.1,139.8), new cjs.Rectangle(17.3,-8.4,116.7,137.9), new cjs.Rectangle(16.7,-7.8,116.3,136), new cjs.Rectangle(16,-7.3,116,134.2), new cjs.Rectangle(15.4,-6.7,115.5,132.3), new cjs.Rectangle(14.8,-6.1,115.1,130.4), new cjs.Rectangle(14.1,-5.5,114.7,128.5), new cjs.Rectangle(13.5,-4.9,114.3,126.6), new cjs.Rectangle(12.8,-4.3,113.9,124.7), new cjs.Rectangle(12.2,-3.7,113.5,122.8), new cjs.Rectangle(11.5,-3.1,113.1,120.9), new cjs.Rectangle(10.9,-2.5,112.8,119.1), new cjs.Rectangle(10.3,-1.9,112.3,117.2), new cjs.Rectangle(9.6,-1.3,113.9,115.3), new cjs.Rectangle(9,-0.7,115.7,113.4), new cjs.Rectangle(8.3,-0.1,117.5,111.5), new cjs.Rectangle(7.7,0.5,119.3,109.6), new cjs.Rectangle(7,1.1,121.1,107.7), new cjs.Rectangle(6.4,1.6,122.9,105.9), new cjs.Rectangle(5.7,2.2,124.7,104), new cjs.Rectangle(5.1,2.8,126.5,102.1), new cjs.Rectangle(4.5,3.4,128.3,100.1), new cjs.Rectangle(3.8,4,130.1,98.3), new cjs.Rectangle(3.2,4.6,131.9,96.4), new cjs.Rectangle(2.5,5.2,133.7,94.5), new cjs.Rectangle(1.9,5.8,135.5,92.7), new cjs.Rectangle(1.2,6.4,137.3,90.8), new cjs.Rectangle(0.6,5.7,139.1,90.1), new cjs.Rectangle(0,4.8,140.9,89.7), new cjs.Rectangle(-0.7,3.9,142.7,89.3), new cjs.Rectangle(-1.3,3,144.5,88.9), new cjs.Rectangle(-2,2.1,146.3,88.5), new cjs.Rectangle(-2.6,1.2,148.1,88.1), new cjs.Rectangle(-3.3,0.3,149.9,87.8), new cjs.Rectangle(-3.9,-0.6,151.7,87.4), new cjs.Rectangle(-4.6,-1.5,153.5,87), new cjs.Rectangle(-5.2,-2.3,155.3,86.5), new cjs.Rectangle(-5.8,-3.2,157.1,86.1), new cjs.Rectangle(-6.5,-4.1,158.9,85.7), new cjs.Rectangle(-7.1,-5,160.7,85.3), new cjs.Rectangle(-7.8,-5.9,162.5,84.9), new cjs.Rectangle(-8.4,-6.8,164.3,84.6), new cjs.Rectangle(-9.1,-7.7,166.1,84.2), new cjs.Rectangle(-9.7,-8.6,167.9,83.8), new cjs.Rectangle(-10.4,-9.5,169.7,83.4), new cjs.Rectangle(-11,-10.4,171.5,82.9), new cjs.Rectangle(-11.6,-11.3,173.3,82.5), new cjs.Rectangle(-12.3,-12.2,175.1,82.1), new cjs.Rectangle(-12.9,-13.1,176.9,81.7), new cjs.Rectangle(-13.6,-14,178.7,81.3), new cjs.Rectangle(-14.2,-14.9,180.5,81), new cjs.Rectangle(-14.9,-15.8,182.3,80.6), new cjs.Rectangle(-15.5,-16.7,184.1,80.2), new cjs.Rectangle(-16.1,-17.5,185.9,79.7), new cjs.Rectangle(-16.8,-18.4,187.7,79.3), new cjs.Rectangle(-17.4,-19.3,189.5,78.9), new cjs.Rectangle(-18.1,-20.2,191.3,78.5), new cjs.Rectangle(-18.7,-21.1,193.1,78.1), new cjs.Rectangle(-19.4,-22,194.9,77.7), new cjs.Rectangle(-20,-22.9,196.7,77.3), new cjs.Rectangle(-20.7,-23.8,198.5,77), new cjs.Rectangle(-21.3,-24.7,200.3,76.5), new cjs.Rectangle(-21.9,-25.6,202.1,76.1), new cjs.Rectangle(-22.6,-26.5,203.9,75.7), new cjs.Rectangle(-23.2,-27.4,205.7,75.3), new cjs.Rectangle(-23.9,-28.3,207.5,74.9), new cjs.Rectangle(-24.5,-29.2,209.3,74.5), new cjs.Rectangle(-25.2,-30.1,211.1,74.1), new cjs.Rectangle(-25.8,-31,212.9,73.7), new cjs.Rectangle(-26.4,-31.8,214.7,73.3), new cjs.Rectangle(-27.1,-32.7,216.5,72.9), new cjs.Rectangle(-27.7,-33.6,218.3,72.5), new cjs.Rectangle(-28.4,-34.5,220.1,72.1), new cjs.Rectangle(-29,-35.4,221.9,71.7), new cjs.Rectangle(-28.3,-34.9,220.6,71.6), new cjs.Rectangle(-27.6,-34.4,219.3,71.4), new cjs.Rectangle(-26.9,-33.9,218,71.3), new cjs.Rectangle(-26.2,-33.3,216.7,71.2), new cjs.Rectangle(-25.5,-32.8,215.4,71), new cjs.Rectangle(-24.8,-32.3,214.1,70.9), new cjs.Rectangle(-24.1,-31.8,212.8,70.8), new cjs.Rectangle(-23.4,-31.3,211.5,70.6), new cjs.Rectangle(-22.7,-30.7,210.2,70.5), new cjs.Rectangle(-21.9,-30.2,208.8,70.4), new cjs.Rectangle(-21.2,-29.7,207.5,70.2), new cjs.Rectangle(-20.5,-29.2,206.2,70.1), new cjs.Rectangle(-19.8,-28.7,204.9,70), new cjs.Rectangle(-19.1,-28.1,203.6,69.8), new cjs.Rectangle(-18.4,-27.6,202.3,69.7), new cjs.Rectangle(-17.7,-27.1,201,69.6), new cjs.Rectangle(-17,-26.6,199.6,69.4), new cjs.Rectangle(-16.3,-26.1,198.3,69.3), new cjs.Rectangle(-15.6,-25.5,197,69.1), new cjs.Rectangle(-14.9,-25,195.7,69), new cjs.Rectangle(-14.2,-24.5,194.4,68.9), new cjs.Rectangle(-13.5,-24,193.1,68.7), new cjs.Rectangle(-12.7,-23.5,191.8,68.6), new cjs.Rectangle(-12,-23,190.5,68.5), new cjs.Rectangle(-11.3,-22.4,189.2,68.3), new cjs.Rectangle(-10.6,-21.9,187.9,68.2), new cjs.Rectangle(-9.9,-21.4,186.5,68), new cjs.Rectangle(-9.2,-20.9,185.3,67.9), new cjs.Rectangle(-8.5,-20.4,183.9,67.8), new cjs.Rectangle(-7.8,-19.8,182.6,67.6), new cjs.Rectangle(-7.1,-19.3,181.3,67.5), new cjs.Rectangle(-6.4,-18.8,180,67.4), new cjs.Rectangle(-5.7,-18.3,178.7,67.2), new cjs.Rectangle(-5,-17.8,177.4,67.1), new cjs.Rectangle(-4.3,-17.2,176.1,67), new cjs.Rectangle(-3.5,-16.7,174.8,66.8), new cjs.Rectangle(-2.8,-16.2,173.5,66.7), new cjs.Rectangle(-2.1,-15.7,172.2,66.6), new cjs.Rectangle(-1.4,-15.2,170.9,66.4), new cjs.Rectangle(-0.7,-14.6,169.6,66.3), new cjs.Rectangle(0,-14.1,168.3,66.2), new cjs.Rectangle(0.7,-13.6,166.9,66), new cjs.Rectangle(1.4,-13.1,165.6,65.9), new cjs.Rectangle(2.1,-12.6,164.3,65.8), new cjs.Rectangle(2.8,-12,163,65.6), new cjs.Rectangle(3.5,-11.5,161.7,65.5), new cjs.Rectangle(4.2,-11,160.4,65.3), new cjs.Rectangle(5,-10.5,159,65.2), new cjs.Rectangle(5.7,-10,157.7,65.1), new cjs.Rectangle(6.4,-9.4,156.4,64.9), new cjs.Rectangle(7.1,-8.9,155.1,64.8), new cjs.Rectangle(7.8,-8.4,153.8,64.6), new cjs.Rectangle(8.5,-7.9,152.5,64.5), new cjs.Rectangle(9.2,-7.4,151.2,64.4), new cjs.Rectangle(9.9,-6.8,149.9,64.2), new cjs.Rectangle(10.6,-6.3,148.6,64.1), new cjs.Rectangle(11.3,-5.8,147.3,64), new cjs.Rectangle(12,-5.3,146,63.8), new cjs.Rectangle(12.7,-4.8,144.7,63.7), new cjs.Rectangle(13.4,-4.2,143.4,63.5), new cjs.Rectangle(14.2,-3.7,142,63.4), new cjs.Rectangle(14.9,-3.2,140.7,63.3), new cjs.Rectangle(15.6,-2.7,139.4,63.1), new cjs.Rectangle(16.3,-2.2,138.1,63), new cjs.Rectangle(17,-1.6,136.8,62.9), new cjs.Rectangle(17.7,-1.1,135.5,62.7), new cjs.Rectangle(18.4,-0.6,134.2,62.6), new cjs.Rectangle(19.1,-0.1,132.9,62.5), new cjs.Rectangle(19.8,0.4,131.5,62.3), new cjs.Rectangle(20.5,1,130.3,62.2), new cjs.Rectangle(21.2,1.5,129,62.1), new cjs.Rectangle(21.9,2,127.7,61.9), new cjs.Rectangle(22.6,2.5,126.4,61.8), new cjs.Rectangle(23.4,3,125,61.7), new cjs.Rectangle(24.1,3.6,123.7,61.5), new cjs.Rectangle(24.8,4.1,122.4,61.4), new cjs.Rectangle(25.5,4.6,121.1,61.3), new cjs.Rectangle(26.2,5.1,119.8,61.1), new cjs.Rectangle(26.9,5.6,118.5,61), new cjs.Rectangle(27.6,6.2,117.1,60.8), new cjs.Rectangle(28.3,6.7,115.8,60.7), new cjs.Rectangle(29,7.2,116,60.6), new cjs.Rectangle(29.7,7.7,116.4,60.4), new cjs.Rectangle(30.4,8.2,116.7,60.3), new cjs.Rectangle(31.1,8.8,117.1,60.1), new cjs.Rectangle(31.8,9.3,117.4,60), new cjs.Rectangle(32.6,9.8,117.7,59.9), new cjs.Rectangle(33.3,10.3,118.1,59.7), new cjs.Rectangle(34,10.8,118.4,59.6), new cjs.Rectangle(34.7,11.4,118.8,59.5), new cjs.Rectangle(35.4,11.9,119.1,59.3), new cjs.Rectangle(36.1,12.4,119.5,59.2), new cjs.Rectangle(36.8,12.9,119.8,59.1), new cjs.Rectangle(37.5,13.4,120.1,58.9), new cjs.Rectangle(38.2,13.9,120.5,58.8), new cjs.Rectangle(38.9,14.5,120.8,58.6), new cjs.Rectangle(39.6,15,121.2,58.5), new cjs.Rectangle(40.3,15.4,121.5,58.5), new cjs.Rectangle(41,15.2,121.9,59.1), new cjs.Rectangle(41.8,15,122.2,59.6), new cjs.Rectangle(42.5,14.8,122.5,60.2), new cjs.Rectangle(43.2,14.6,122.9,60.8), new cjs.Rectangle(43.9,14.4,123.2,61.4), new cjs.Rectangle(44.6,14.3,123.6,61.9), new cjs.Rectangle(45.3,14.1,123.9,62.5), new cjs.Rectangle(46,13.9,124.2,63.1), new cjs.Rectangle(46.7,13.7,124.6,63.7), new cjs.Rectangle(47.4,13.5,124.9,64.3), new cjs.Rectangle(48.1,13.3,125.3,64.8), new cjs.Rectangle(48.8,13.1,125.6,65.4), new cjs.Rectangle(49.5,12.9,126,65.9), new cjs.Rectangle(50.3,12.7,126.3,66.5), new cjs.Rectangle(51,12.5,126.6,67.1), new cjs.Rectangle(51.7,12.3,127,67.7), new cjs.Rectangle(52.4,12.1,127.3,68.3), new cjs.Rectangle(53.1,11.9,127.7,68.9), new cjs.Rectangle(53.8,11.8,128,69.4), new cjs.Rectangle(54.5,11.6,128.4,70), new cjs.Rectangle(55.2,11.4,128.6,70.6), new cjs.Rectangle(55.9,11.2,129,71.1), new cjs.Rectangle(56.6,11,129.4,71.7), new cjs.Rectangle(57.3,10.8,129.7,72.3), new cjs.Rectangle(58,10.6,130.1,72.9), new cjs.Rectangle(58.7,10.4,130.4,73.4), new cjs.Rectangle(59.5,10.2,130.7,74), new cjs.Rectangle(60.2,10,131,74.6), new cjs.Rectangle(60.9,9.8,131.4,75.2), new cjs.Rectangle(61.6,9.6,131.8,75.8), new cjs.Rectangle(62.3,9.4,132.1,76.4), new cjs.Rectangle(63,9.2,132.5,77), new cjs.Rectangle(63.7,9.1,132.8,77.5), new cjs.Rectangle(64.4,8.9,133.1,78.1), new cjs.Rectangle(65.1,8.7,133.5,78.6), new cjs.Rectangle(65.8,8.5,133.8,79.2), new cjs.Rectangle(66.5,8.3,134.2,79.8), new cjs.Rectangle(67.2,8.1,134.5,80.4), new cjs.Rectangle(67.9,7.9,134.9,80.9), new cjs.Rectangle(68.7,7.7,135.2,81.5), new cjs.Rectangle(69.4,7.5,135.5,82.1), new cjs.Rectangle(70.1,7.3,135.9,82.7), new cjs.Rectangle(70.8,7.1,136.2,83.3), new cjs.Rectangle(71.5,6.9,136.6,83.9), new cjs.Rectangle(72.2,6.7,136.9,84.4), new cjs.Rectangle(72.9,6.6,137.2,85), new cjs.Rectangle(73.6,6.4,137.6,85.6), new cjs.Rectangle(74.3,6.2,137.9,86.1), new cjs.Rectangle(75,6,138.3,86.7)];


(lib.Символ1копия = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_327 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(327).call(this.frame_327).wait(1));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_1__копия_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(109.6,66.8,1,1,0,0,0,109.6,66.8);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(328));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(6,41,207.3,51.7);
p.frameBounds = [rect, new cjs.Rectangle(5.5,40.5,206.6,52.9), new cjs.Rectangle(5,39.9,206,54.1), new cjs.Rectangle(4.5,39.4,205.4,55.2), new cjs.Rectangle(3.9,38.9,204.8,56.5), new cjs.Rectangle(3.4,38.4,204.1,57.6), new cjs.Rectangle(2.9,37.8,203.5,58.8), new cjs.Rectangle(2.4,37.3,202.9,60), new cjs.Rectangle(1.8,36.8,202.3,61.1), new cjs.Rectangle(1.3,36.3,201.6,62.3), new cjs.Rectangle(0.8,35.8,201,63.5), new cjs.Rectangle(0.3,35.2,200.3,64.6), new cjs.Rectangle(-0.3,34.7,199.7,65.9), new cjs.Rectangle(-0.8,34.2,199.1,67), new cjs.Rectangle(-1.3,33.7,198.5,68.2), new cjs.Rectangle(-1.8,33.2,197.8,69.4), new cjs.Rectangle(-2.3,32.6,197.2,70.6), new cjs.Rectangle(-2.9,32.1,196.6,71.7), new cjs.Rectangle(-3.4,31.6,195.9,72.9), new cjs.Rectangle(-3.9,31.1,195.3,74.1), new cjs.Rectangle(-4.4,30.6,194.6,75.3), new cjs.Rectangle(-5,30,194.1,76.5), new cjs.Rectangle(-5.5,29.5,193.4,77.6), new cjs.Rectangle(-6,29,192.8,78.8), new cjs.Rectangle(-6.5,28.5,192.2,80), new cjs.Rectangle(-7.1,28,191.5,81.1), new cjs.Rectangle(-7.6,27.4,190.9,82.3), new cjs.Rectangle(-8.1,26.9,190.3,83.5), new cjs.Rectangle(-8.6,26.4,189.7,84.7), new cjs.Rectangle(-9.2,25.9,189,85.9), new cjs.Rectangle(-9.7,25.4,188.4,87), new cjs.Rectangle(-10.2,24.8,187.7,88.2), new cjs.Rectangle(-10.7,24.3,187.1,89.4), new cjs.Rectangle(-11.2,23.8,186.5,90.6), new cjs.Rectangle(-11.8,23.3,185.9,91.8), new cjs.Rectangle(-12.3,22.7,185.2,93), new cjs.Rectangle(-12.8,22.2,184.6,94.1), new cjs.Rectangle(-13.3,21.7,184,95.3), new cjs.Rectangle(-13.9,21.2,183.4,96.4), new cjs.Rectangle(-14.4,20.7,182.7,97.6), new cjs.Rectangle(-14.9,20.1,182.1,98.8), new cjs.Rectangle(-15.4,19.6,181.5,99.9), new cjs.Rectangle(-16,19.1,180.9,101.2), new cjs.Rectangle(-16.5,18.6,180.2,102.4), new cjs.Rectangle(-17,18.1,179.6,103.5), new cjs.Rectangle(-17.5,17.5,179,104.7), new cjs.Rectangle(-18,17,178.3,105.9), new cjs.Rectangle(-18.6,16.5,177.7,107.1), new cjs.Rectangle(-19.1,16,177,108.2), new cjs.Rectangle(-19.6,15.5,176.5,109.4), new cjs.Rectangle(-20.1,14.9,175.8,110.6), new cjs.Rectangle(-20.7,14.4,175.1,111.8), new cjs.Rectangle(-21.2,13.9,174.5,113), new cjs.Rectangle(-21.7,13.4,173.9,114.1), new cjs.Rectangle(-22.2,12.9,173.3,115.3), new cjs.Rectangle(-22.8,12.3,172.7,116.5), new cjs.Rectangle(-23.3,11.8,172,117.6), new cjs.Rectangle(-23.8,11.3,171.4,118.9), new cjs.Rectangle(-24.3,10.8,170.8,120), new cjs.Rectangle(-24.9,10.2,170.2,121.2), new cjs.Rectangle(-25.4,9.7,169.5,122.4), new cjs.Rectangle(-25.7,8.5,168,122), new cjs.Rectangle(-26,7.2,166.6,121.7), new cjs.Rectangle(-26.3,5.9,165.1,121.4), new cjs.Rectangle(-26.6,4.6,163.5,121.1), new cjs.Rectangle(-26.8,3.4,162,120.7), new cjs.Rectangle(-27.1,2.1,160.6,120.4), new cjs.Rectangle(-27.4,0.8,159,120.1), new cjs.Rectangle(-27.7,-0.4,157.6,119.8), new cjs.Rectangle(-28,-1.7,156.1,119.4), new cjs.Rectangle(-28.3,-3,154.6,119.1), new cjs.Rectangle(-28.6,-4.2,153.1,118.8), new cjs.Rectangle(-28.9,-5.5,151.6,118.5), new cjs.Rectangle(-29.2,-6.8,150,118.1), new cjs.Rectangle(-29.5,-8,148.6,117.8), new cjs.Rectangle(-29.8,-9.3,147.1,117.5), new cjs.Rectangle(-30.1,-10.6,145.6,117.1), new cjs.Rectangle(-30.4,-11.9,145.5,116.8), new cjs.Rectangle(-30.7,-13.1,146.3,116.5), new cjs.Rectangle(-31,-14.4,147,116.1), new cjs.Rectangle(-31.3,-15.7,147.8,115.8), new cjs.Rectangle(-31.6,-16.9,148.6,115.5), new cjs.Rectangle(-31.8,-18.2,149.3,115.1), new cjs.Rectangle(-32.1,-19.5,150,114.9), new cjs.Rectangle(-32.4,-20.7,150.8,114.5), new cjs.Rectangle(-32.7,-22,151.6,114.2), new cjs.Rectangle(-33,-23.3,152.3,113.9), new cjs.Rectangle(-33.3,-24.5,153.1,113.5), new cjs.Rectangle(-33.6,-25.8,153.8,113.2), new cjs.Rectangle(-33.9,-27.1,154.6,112.9), new cjs.Rectangle(-34.2,-28.3,155.3,112.5), new cjs.Rectangle(-34.5,-29.6,156.1,112.2), new cjs.Rectangle(-34.8,-30.9,156.8,111.9), new cjs.Rectangle(-35.1,-32.2,157.6,113), new cjs.Rectangle(-35.4,-33.4,158.3,115.2), new cjs.Rectangle(-35.7,-34.7,159.1,117.5), new cjs.Rectangle(-36,-36,159.9,119.8), new cjs.Rectangle(-36.3,-37.2,160.6,122.1), new cjs.Rectangle(-36.6,-38.5,161.4,124.4), new cjs.Rectangle(-36.8,-39.8,162.1,126.7), new cjs.Rectangle(-37.1,-41,162.8,128.9), new cjs.Rectangle(-37.4,-42.3,163.6,131.2), new cjs.Rectangle(-37.7,-43.6,164.4,133.5), new cjs.Rectangle(-38,-44.8,165.1,135.8), new cjs.Rectangle(-38.3,-46.1,165.9,138.1), new cjs.Rectangle(-38.6,-47.4,166.6,140.3), new cjs.Rectangle(-38.9,-48.7,167.4,142.6), new cjs.Rectangle(-39.2,-49.9,168.2,144.9), new cjs.Rectangle(-39.5,-51.2,168.9,147.2), new cjs.Rectangle(-39.8,-52.5,169.6,149.5), new cjs.Rectangle(-40.1,-53.7,170.4,151.7), new cjs.Rectangle(-40.4,-55,171.1,154.1), new cjs.Rectangle(-40.7,-56.3,171.9,156.3), new cjs.Rectangle(-41,-57.5,172.7,158.6), new cjs.Rectangle(-41.3,-58.8,173.4,160.9), new cjs.Rectangle(-41.6,-60.1,174.2,163.2), new cjs.Rectangle(-41.8,-61.3,174.9,165.4), new cjs.Rectangle(-42.1,-62.6,175.6,167.7), new cjs.Rectangle(-42.4,-63.9,176.4,170), new cjs.Rectangle(-42.7,-65.2,177.2,172.3), new cjs.Rectangle(-43,-66.4,177.9,174.6), new cjs.Rectangle(-42.8,-65.9,177.5,173.8), new cjs.Rectangle(-42.6,-65.4,177.2,172.9), new cjs.Rectangle(-42.3,-64.9,176.8,172.1), new cjs.Rectangle(-42.1,-64.4,176.4,171.3), new cjs.Rectangle(-41.8,-63.8,176,170.4), new cjs.Rectangle(-41.6,-63.3,175.6,169.6), new cjs.Rectangle(-41.4,-62.8,175.2,168.7), new cjs.Rectangle(-41.1,-62.3,174.8,167.9), new cjs.Rectangle(-40.9,-61.8,174.5,167.1), new cjs.Rectangle(-40.7,-61.2,174.1,166.2), new cjs.Rectangle(-40.4,-60.7,173.7,165.4), new cjs.Rectangle(-40.2,-60.2,173.3,164.5), new cjs.Rectangle(-39.9,-59.7,172.9,163.7), new cjs.Rectangle(-39.7,-59.2,172.6,162.9), new cjs.Rectangle(-39.5,-58.6,172.2,162.1), new cjs.Rectangle(-39.2,-58.1,171.8,161.2), new cjs.Rectangle(-39,-57.6,171.4,160.4), new cjs.Rectangle(-38.8,-57.1,171,159.6), new cjs.Rectangle(-38.5,-56.6,170.6,158.7), new cjs.Rectangle(-38.3,-56,170.2,157.9), new cjs.Rectangle(-38,-55.5,169.8,157.1), new cjs.Rectangle(-37.8,-55,169.5,156.3), new cjs.Rectangle(-37.6,-54.5,169,155.4), new cjs.Rectangle(-37.3,-54,168.7,154.6), new cjs.Rectangle(-37.1,-53.5,168.3,153.8), new cjs.Rectangle(-36.9,-52.9,168,152.9), new cjs.Rectangle(-36.6,-52.4,167.6,152.1), new cjs.Rectangle(-36.4,-51.9,167.2,151.2), new cjs.Rectangle(-36.2,-51.4,166.8,150.4), new cjs.Rectangle(-35.9,-50.9,166.4,149.6), new cjs.Rectangle(-35.7,-50.3,166,148.7), new cjs.Rectangle(-35.4,-49.8,165.6,147.9), new cjs.Rectangle(-35.2,-49.3,165.3,147.1), new cjs.Rectangle(-35,-48.8,164.9,146.2), new cjs.Rectangle(-34.7,-48.3,164.5,145.4), new cjs.Rectangle(-34.5,-47.7,164.1,144.5), new cjs.Rectangle(-34.3,-47.2,163.7,143.7), new cjs.Rectangle(-34,-46.7,163.3,142.9), new cjs.Rectangle(-33.8,-46.2,162.9,142.1), new cjs.Rectangle(-33.5,-45.7,162.5,141.2), new cjs.Rectangle(-33.3,-45.2,162.2,140.4), new cjs.Rectangle(-33.1,-44.6,161.8,139.6), new cjs.Rectangle(-32.8,-44.1,161.4,138.7), new cjs.Rectangle(-32.6,-43.6,161,137.9), new cjs.Rectangle(-32.4,-43.1,160.7,137.1), new cjs.Rectangle(-32.1,-42.6,160.3,136.2), new cjs.Rectangle(-31.9,-42,159.9,135.4), new cjs.Rectangle(-31.7,-41.5,159.5,134.6), new cjs.Rectangle(-31.4,-41,159.1,133.8), new cjs.Rectangle(-31.2,-40.5,158.7,132.9), new cjs.Rectangle(-30.9,-40,158.3,132.1), new cjs.Rectangle(-30.7,-39.4,158,131.2), new cjs.Rectangle(-30.5,-38.9,157.6,130.4), new cjs.Rectangle(-30.2,-38.4,157.2,129.6), new cjs.Rectangle(-30,-37.9,156.8,128.7), new cjs.Rectangle(-29.8,-37.4,156.4,127.9), new cjs.Rectangle(-29.5,-36.9,156,127.1), new cjs.Rectangle(-29.3,-36.3,155.6,126.2), new cjs.Rectangle(-29,-35.8,155.2,125.4), new cjs.Rectangle(-28.8,-35.3,154.9,124.5), new cjs.Rectangle(-28.6,-34.8,154.5,123.7), new cjs.Rectangle(-28.3,-34.3,154.1,122.9), new cjs.Rectangle(-28.1,-33.7,153.7,122), new cjs.Rectangle(-27.9,-33.2,153.4,121.2), new cjs.Rectangle(-27.6,-32.7,153,120.4), new cjs.Rectangle(-27.4,-32.2,152.6,119.6), new cjs.Rectangle(-27.1,-31.7,152.2,118.7), new cjs.Rectangle(-26.9,-31.1,151.8,117.9), new cjs.Rectangle(-26.7,-30.6,151.4,117.1), new cjs.Rectangle(-26.4,-30.1,151,116.2), new cjs.Rectangle(-26.2,-29.6,150.7,115.4), new cjs.Rectangle(-26,-29.1,150.3,114.6), new cjs.Rectangle(-25.7,-28.5,149.9,113.7), new cjs.Rectangle(-25.5,-28,149.5,112.9), new cjs.Rectangle(-25.3,-27.5,149.1,112.1), new cjs.Rectangle(-25,-27,148.7,111.2), new cjs.Rectangle(-24.8,-26.5,148.3,110.4), new cjs.Rectangle(-24.5,-26,148,109.6), new cjs.Rectangle(-24.3,-25.4,147.6,108.7), new cjs.Rectangle(-24.1,-24.9,147.2,107.9), new cjs.Rectangle(-23.8,-24.4,146.8,107), new cjs.Rectangle(-23.6,-23.9,146.4,106.2), new cjs.Rectangle(-23.4,-23.4,146.1,105.4), new cjs.Rectangle(-23.1,-22.8,145.7,104.5), new cjs.Rectangle(-22.9,-22.3,145.3,103.7), new cjs.Rectangle(-22.6,-21.8,144.9,102.9), new cjs.Rectangle(-22.4,-21.3,144.5,102), new cjs.Rectangle(-22.2,-20.8,144.1,101.2), new cjs.Rectangle(-21.9,-20.2,143.7,100.4), new cjs.Rectangle(-21.7,-19.7,143.3,99.5), new cjs.Rectangle(-21.5,-19.2,143,98.7), new cjs.Rectangle(-21.2,-18.7,142.6,97.9), new cjs.Rectangle(-21,-18.2,142.2,97.1), new cjs.Rectangle(-20.8,-17.7,141.8,96.2), new cjs.Rectangle(-20.5,-17.1,141.5,95.4), new cjs.Rectangle(-20.3,-16.6,141.1,94.6), new cjs.Rectangle(-20,-16.1,140.7,93.7), new cjs.Rectangle(-19.8,-15.6,140.3,92.9), new cjs.Rectangle(-19.6,-15.1,140.9,92.1), new cjs.Rectangle(-19.3,-14.5,141.5,91.2), new cjs.Rectangle(-19.1,-14,142.1,90.4), new cjs.Rectangle(-18.9,-13.5,142.7,89.6), new cjs.Rectangle(-18.6,-13,143.3,88.7), new cjs.Rectangle(-18.4,-12.5,143.9,87.9), new cjs.Rectangle(-18.1,-11.9,144.5,87), new cjs.Rectangle(-17.9,-11.4,145.2,86.2), new cjs.Rectangle(-17.7,-10.9,145.8,85.4), new cjs.Rectangle(-17.4,-10.4,146.4,84.5), new cjs.Rectangle(-17.2,-9.9,147,83.7), new cjs.Rectangle(-17,-9.4,147.6,82.9), new cjs.Rectangle(-16.7,-8.8,148.2,82), new cjs.Rectangle(-16.5,-8.3,148.8,81.2), new cjs.Rectangle(-16.2,-7.8,149.4,80.4), new cjs.Rectangle(-16,-7.3,150.1,79.5), new cjs.Rectangle(-15.8,-6.8,150.7,78.7), new cjs.Rectangle(-15.5,-6.2,151.3,77.9), new cjs.Rectangle(-15.3,-5.7,152,77.1), new cjs.Rectangle(-15.1,-5.2,152.5,76.2), new cjs.Rectangle(-14.8,-4.7,153.2,75.4), new cjs.Rectangle(-14.6,-4.2,153.8,74.6), new cjs.Rectangle(-14.4,-3.6,154.4,73.7), new cjs.Rectangle(-14.1,-3.1,155,72.9), new cjs.Rectangle(-13.9,-2.6,155.6,72.4), new cjs.Rectangle(-13.6,-2.1,156.2,72.1), new cjs.Rectangle(-13.4,-1.6,156.9,71.9), new cjs.Rectangle(-13.2,-1.1,157.5,71.7), new cjs.Rectangle(-12.9,-0.5,158,71.4), new cjs.Rectangle(-12.7,0,158.6,71.2), new cjs.Rectangle(-12.5,0.5,159.3,70.9), new cjs.Rectangle(-12.2,1,159.9,70.7), new cjs.Rectangle(-12,1.5,160.5,70.5), new cjs.Rectangle(-11.7,2.1,161.1,70.2), new cjs.Rectangle(-11.5,2.6,161.8,70), new cjs.Rectangle(-11.3,3.1,162.4,69.7), new cjs.Rectangle(-11,3.6,163,69.5), new cjs.Rectangle(-10.8,4.1,163.6,69.2), new cjs.Rectangle(-10.6,4.7,164.2,68.9), new cjs.Rectangle(-10.3,5.2,164.8,68.7), new cjs.Rectangle(-10.1,5.7,165.4,68.4), new cjs.Rectangle(-9.9,6.2,166.1,68.2), new cjs.Rectangle(-9.6,6.7,166.7,68), new cjs.Rectangle(-9.4,7.3,167.3,67.7), new cjs.Rectangle(-9.1,7.8,167.9,67.5), new cjs.Rectangle(-8.9,8.3,168.5,67.3), new cjs.Rectangle(-8.7,8.8,169.1,67), new cjs.Rectangle(-8.4,9.3,169.8,66.8), new cjs.Rectangle(-8.2,9.8,170.4,66.5), new cjs.Rectangle(-8,10.4,171,66.2), new cjs.Rectangle(-7.7,10.9,171.6,66), new cjs.Rectangle(-7.5,11.4,172.2,65.7), new cjs.Rectangle(-7.2,11.9,172.8,65.5), new cjs.Rectangle(-7,12.4,173.5,65.3), new cjs.Rectangle(-6.8,13,174.1,65), new cjs.Rectangle(-6.5,13.5,174.7,64.8), new cjs.Rectangle(-6.3,14,175.3,64.6), new cjs.Rectangle(-6.1,14.5,175.9,64.3), new cjs.Rectangle(-5.8,15,176.5,64.1), new cjs.Rectangle(-5.6,15.6,177.1,63.8), new cjs.Rectangle(-5.3,16.1,177.7,63.5), new cjs.Rectangle(-5.1,16.6,178.4,63.3), new cjs.Rectangle(-4.9,17.1,179,63), new cjs.Rectangle(-4.6,17.6,179.6,62.8), new cjs.Rectangle(-4.4,18.1,180.2,62.6), new cjs.Rectangle(-4.2,18.7,180.8,62.3), new cjs.Rectangle(-3.9,19.2,181.4,62.1), new cjs.Rectangle(-3.7,19.7,182,61.8), new cjs.Rectangle(-3.5,20.2,182.7,61.6), new cjs.Rectangle(-3.2,20.7,183.3,61.3), new cjs.Rectangle(-3,21.3,183.9,61.1), new cjs.Rectangle(-2.7,21.8,184.5,60.8), new cjs.Rectangle(-2.5,22.3,185.2,60.6), new cjs.Rectangle(-2.3,22.8,185.8,60.3), new cjs.Rectangle(-2,23.3,186.4,60.1), new cjs.Rectangle(-1.8,23.9,187,59.8), new cjs.Rectangle(-1.6,24.4,187.6,59.6), new cjs.Rectangle(-1.3,24.9,188.2,59.4), new cjs.Rectangle(-1.1,25.4,188.8,59.1), new cjs.Rectangle(-0.8,25.9,189.4,58.9), new cjs.Rectangle(-0.6,26.4,190.1,58.6), new cjs.Rectangle(-0.4,27,190.7,58.4), new cjs.Rectangle(-0.1,27.5,191.3,58.1), new cjs.Rectangle(0.1,28,191.9,57.9), new cjs.Rectangle(0.3,28.5,192.5,57.6), new cjs.Rectangle(0.6,29,193.1,57.4), new cjs.Rectangle(0.8,29.6,193.7,57.1), new cjs.Rectangle(1,30.1,194.4,56.9), new cjs.Rectangle(1.3,30.6,195,56.7), new cjs.Rectangle(1.5,31.1,195.6,56.4), new cjs.Rectangle(1.8,31.6,196.2,56.2), new cjs.Rectangle(2,32.2,196.8,55.9), new cjs.Rectangle(2.2,32.7,197.4,55.7), new cjs.Rectangle(2.5,33.2,198,55.4), new cjs.Rectangle(2.7,33.7,198.6,55.1), new cjs.Rectangle(2.9,34.2,199.3,54.9), new cjs.Rectangle(3.2,34.7,199.9,54.7), new cjs.Rectangle(3.4,35.3,200.5,54.4), new cjs.Rectangle(3.7,35.8,201.1,54.2), new cjs.Rectangle(3.9,36.3,201.8,53.9), new cjs.Rectangle(4.1,36.8,202.4,53.7), new cjs.Rectangle(4.4,37.3,203,53.5), new cjs.Rectangle(4.6,37.9,203.6,53.2), new cjs.Rectangle(4.8,38.4,204.2,53), new cjs.Rectangle(5.1,38.9,204.8,52.7), new cjs.Rectangle(5.3,39.4,205.4,52.5), new cjs.Rectangle(5.6,39.9,206,52.2), new cjs.Rectangle(5.8,40.5,206.7,52), new cjs.Rectangle(6,41,207.3,51.7)];


(lib.Символ1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_327 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(327).call(this.frame_327).wait(1));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_1_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(69.5,49.6,1,1,0,0,0,69.5,49.6);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 0
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(328));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-1,-1,141,101.1);
p.frameBounds = [rect, new cjs.Rectangle(-0.8,-0.8,139.5,99.5), new cjs.Rectangle(-0.6,-0.6,138.1,98), new cjs.Rectangle(-0.4,-0.4,136.7,96.4), new cjs.Rectangle(-0.2,-0.3,135.3,94.8), new cjs.Rectangle(0,-0.1,133.9,93.2), new cjs.Rectangle(0.2,0.1,132.5,91.7), new cjs.Rectangle(0.4,0.3,131,90.1), new cjs.Rectangle(0.6,0.5,129.6,88.5), new cjs.Rectangle(0.8,0.6,128.2,87), new cjs.Rectangle(1,0.8,126.7,85.4), new cjs.Rectangle(1.2,1,125.3,83.8), new cjs.Rectangle(1.3,1.2,123.9,82.2), new cjs.Rectangle(1.5,1.3,122.5,80.7), new cjs.Rectangle(1.7,1.5,121.1,79.1), new cjs.Rectangle(1.9,1.7,119.7,77.5), new cjs.Rectangle(2.1,1.9,118.2,75.9), new cjs.Rectangle(2.3,2.1,116.8,74.3), new cjs.Rectangle(2.5,2.2,115.4,72.8), new cjs.Rectangle(2.7,2.4,114,71.8), new cjs.Rectangle(2.9,2.6,112.6,72.6), new cjs.Rectangle(3.1,2.8,111.1,73.4), new cjs.Rectangle(3.3,2.9,109.7,74.1), new cjs.Rectangle(3.5,3.1,108.3,75), new cjs.Rectangle(3.7,3.3,106.9,75.7), new cjs.Rectangle(3.9,3.5,105.4,76.6), new cjs.Rectangle(4.1,3.7,104,77.3), new cjs.Rectangle(4.2,3.8,102.6,78.2), new cjs.Rectangle(4.4,4,101.2,78.9), new cjs.Rectangle(4.6,4.2,99.8,79.8), new cjs.Rectangle(4.8,4.4,98.4,80.5), new cjs.Rectangle(5,4.6,96.9,81.3), new cjs.Rectangle(5.2,4.7,95.5,82.1), new cjs.Rectangle(5.4,4.9,94.1,82.9), new cjs.Rectangle(5.6,5.1,92.7,83.7), new cjs.Rectangle(5.8,5.3,91.5,84.5), new cjs.Rectangle(6,5.4,93.1,85.3), new cjs.Rectangle(6.2,5.6,94.9,86.1), new cjs.Rectangle(6.4,5.8,96.5,86.9), new cjs.Rectangle(6.6,6,98.2,87.6), new cjs.Rectangle(6.8,6.2,99.9,88.4), new cjs.Rectangle(7,6.3,101.6,89.3), new cjs.Rectangle(7.1,6.5,103.3,90.1), new cjs.Rectangle(7.3,6.7,104.9,90.9), new cjs.Rectangle(7.5,6.9,106.6,91.7), new cjs.Rectangle(7.7,7.1,108.3,92.4), new cjs.Rectangle(7.9,7.2,110,93.2), new cjs.Rectangle(8.1,7.4,111.7,94), new cjs.Rectangle(8.3,7.6,113.3,94.8), new cjs.Rectangle(8.5,7.8,115,95.6), new cjs.Rectangle(8.7,7.9,116.7,96.4), new cjs.Rectangle(8.9,8.1,118.4,97.2), new cjs.Rectangle(9.1,8.3,120.1,98), new cjs.Rectangle(9.3,8.5,121.7,98.8), new cjs.Rectangle(9.5,8.7,123.4,99.6), new cjs.Rectangle(9.7,8.8,125.1,100.4), new cjs.Rectangle(9.9,9,126.8,101.2), new cjs.Rectangle(10,9.2,128.5,102), new cjs.Rectangle(10.2,9.4,130.2,102.8), new cjs.Rectangle(10.4,9.5,131.9,103.6), new cjs.Rectangle(10.6,9.7,133.5,104.4), new cjs.Rectangle(10.2,10.1,133.8,103.8), new cjs.Rectangle(9.9,10.5,134,103.1), new cjs.Rectangle(9.5,11,134.2,102.5), new cjs.Rectangle(9.1,11.4,134.4,101.9), new cjs.Rectangle(8.7,11.8,134.7,101.2), new cjs.Rectangle(8.4,12.2,134.8,100.6), new cjs.Rectangle(8,11.8,135.1,100.8), new cjs.Rectangle(7.6,11.5,135.3,100.9), new cjs.Rectangle(7.2,11.1,135.5,101), new cjs.Rectangle(6.8,10.7,135.8,101.2), new cjs.Rectangle(6.5,10.4,136,101.4), new cjs.Rectangle(6.1,10,136.2,101.5), new cjs.Rectangle(5.7,9.7,136.4,101.6), new cjs.Rectangle(5.3,9.3,136.6,101.8), new cjs.Rectangle(5,8.9,136.9,101.9), new cjs.Rectangle(4.6,8.6,137.1,102.1), new cjs.Rectangle(4.2,8.2,137.4,102.3), new cjs.Rectangle(3.8,7.8,137.5,102.4), new cjs.Rectangle(3.4,7.5,137.8,102.5), new cjs.Rectangle(3.1,7.1,138,102.7), new cjs.Rectangle(2.7,6.7,138.2,102.8), new cjs.Rectangle(2.3,6.4,138.4,103), new cjs.Rectangle(1.9,6,138.7,103.1), new cjs.Rectangle(1.5,5.7,138.9,103.2), new cjs.Rectangle(1.2,5.3,139.1,103.4), new cjs.Rectangle(0.8,4.9,139.4,103.6), new cjs.Rectangle(0.4,4.6,139.5,103.7), new cjs.Rectangle(0,4.2,139.8,103.8), new cjs.Rectangle(-0.3,3.8,140,104), new cjs.Rectangle(-0.7,3.5,140.3,104.2), new cjs.Rectangle(-1.1,3.1,140.5,104.3), new cjs.Rectangle(-1.5,2.7,140.7,104.5), new cjs.Rectangle(-1.9,2.4,140.9,104.6), new cjs.Rectangle(-2.2,2,141.1,104.7), new cjs.Rectangle(-2.6,1.7,141.4,104.9), new cjs.Rectangle(-3,1.3,141.6,105.1), new cjs.Rectangle(-3.4,0.9,141.8,105.2), new cjs.Rectangle(-3.8,0.6,142.1,105.3), new cjs.Rectangle(-4.1,0.2,142.3,105.5), new cjs.Rectangle(-4.5,-0.2,142.5,105.6), new cjs.Rectangle(-4.9,-0.5,142.7,105.8), new cjs.Rectangle(-5.3,-0.9,143,105.9), new cjs.Rectangle(-5.6,-1.2,143.1,106), new cjs.Rectangle(-6,-1.6,143.4,106.2), new cjs.Rectangle(-6.4,-2,143.6,106.4), new cjs.Rectangle(-6.8,-2.3,143.8,106.5), new cjs.Rectangle(-7.2,-2.7,144,106.7), new cjs.Rectangle(-7.5,-3.1,144.3,106.8), new cjs.Rectangle(-7.9,-3.4,144.5,106.9), new cjs.Rectangle(-8.3,-3.8,144.7,107.1), new cjs.Rectangle(-8.7,-4.2,145,107.3), new cjs.Rectangle(-9,-4.5,145.2,107.4), new cjs.Rectangle(-9.4,-4.9,145.4,107.5), new cjs.Rectangle(-9.8,-5.2,145.7,107.7), new cjs.Rectangle(-10.2,-5.6,145.8,107.9), new cjs.Rectangle(-10.6,-6,146,108), new cjs.Rectangle(-10.9,-6.3,146.3,108.1), new cjs.Rectangle(-11.3,-6.7,146.5,108.3), new cjs.Rectangle(-11.7,-7.1,146.7,108.4), new cjs.Rectangle(-12.1,-7.4,147,108.6), new cjs.Rectangle(-12,-6.9,146.4,107.9), new cjs.Rectangle(-12,-6.4,145.9,107.1), new cjs.Rectangle(-11.9,-5.9,145.3,106.4), new cjs.Rectangle(-11.9,-5.4,144.8,105.6), new cjs.Rectangle(-11.8,-4.9,144.2,104.9), new cjs.Rectangle(-11.8,-4.4,143.7,104.2), new cjs.Rectangle(-11.7,-3.9,143,103.5), new cjs.Rectangle(-11.6,-3.3,142.5,102.7), new cjs.Rectangle(-11.6,-2.8,142,101.9), new cjs.Rectangle(-11.5,-2.3,141.4,101.3), new cjs.Rectangle(-11.5,-1.8,140.9,100.6), new cjs.Rectangle(-11.4,-1.3,140.3,99.8), new cjs.Rectangle(-11.4,-0.8,139.8,99.1), new cjs.Rectangle(-11.3,-0.3,139.2,98.4), new cjs.Rectangle(-11.3,0.2,138.7,97.6), new cjs.Rectangle(-11.2,0.7,138.1,96.9), new cjs.Rectangle(-11.2,1.2,137.5,96.1), new cjs.Rectangle(-11.1,1.8,137,95.4), new cjs.Rectangle(-11.1,2.3,136.5,94.7), new cjs.Rectangle(-11,2.8,135.9,94), new cjs.Rectangle(-10.9,3.3,135.3,93.3), new cjs.Rectangle(-10.9,3.8,134.8,92.5), new cjs.Rectangle(-10.8,4.3,134.3,91.8), new cjs.Rectangle(-10.8,4.8,133.7,91.1), new cjs.Rectangle(-10.7,5.3,133.2,90.3), new cjs.Rectangle(-10.7,5.8,132.6,89.6), new cjs.Rectangle(-10.6,6.3,132.1,88.9), new cjs.Rectangle(-10.6,6.9,131.5,88.1), new cjs.Rectangle(-10.5,7.4,131,87.4), new cjs.Rectangle(-10.5,7.9,130.4,86.7), new cjs.Rectangle(-10.4,8.4,129.9,86), new cjs.Rectangle(-10.4,8.9,129.3,85.2), new cjs.Rectangle(-10.3,9.4,128.8,84.4), new cjs.Rectangle(-10.3,9.9,128.2,83.8), new cjs.Rectangle(-10.2,10.4,127.6,83), new cjs.Rectangle(-10.1,10.9,127.1,82.3), new cjs.Rectangle(-10.1,11.4,126.5,81.6), new cjs.Rectangle(-10,12,126,80.8), new cjs.Rectangle(-10,12.5,125.4,80.1), new cjs.Rectangle(-9.9,13,124.9,79.4), new cjs.Rectangle(-9.9,13.5,124.3,78.6), new cjs.Rectangle(-9.8,14,123.8,78), new cjs.Rectangle(-9.8,14.5,123.2,77.2), new cjs.Rectangle(-9.7,15,122.7,76.5), new cjs.Rectangle(-9.7,15.5,122.1,75.7), new cjs.Rectangle(-9.6,16,121.6,75), new cjs.Rectangle(-9.6,16.5,121,74.3), new cjs.Rectangle(-9.5,17.1,120.5,73.5), new cjs.Rectangle(-9.4,17.6,119.9,72.8), new cjs.Rectangle(-9.4,18.1,119.3,72.1), new cjs.Rectangle(-9.3,18.6,118.8,71.4), new cjs.Rectangle(-9.3,19.1,118.2,70.7), new cjs.Rectangle(-9.2,19.6,117.7,69.9), new cjs.Rectangle(-9.2,20.1,117.1,69.2), new cjs.Rectangle(-9.1,20.6,116.6,68.4), new cjs.Rectangle(-9.1,21.1,116,67.7), new cjs.Rectangle(-9,21.6,115.5,67), new cjs.Rectangle(-9,22.1,114.9,66.3), new cjs.Rectangle(-8.9,22.7,114.4,65.5), new cjs.Rectangle(-8.9,23.2,113.8,64.8), new cjs.Rectangle(-8.8,23.7,113.3,64.1), new cjs.Rectangle(-8.8,23.7,112.8,63.8), new cjs.Rectangle(-8.7,23.5,112.2,63.8), new cjs.Rectangle(-8.6,23.4,111.6,63.7), new cjs.Rectangle(-8.6,23.2,111.1,63.6), new cjs.Rectangle(-8.5,23,110.5,63.6), new cjs.Rectangle(-8.5,22.9,110,63.6), new cjs.Rectangle(-8.4,22.7,109.4,63.5), new cjs.Rectangle(-8.4,22.5,108.9,63.5), new cjs.Rectangle(-8.3,22.4,108.3,63.4), new cjs.Rectangle(-8.3,22.2,107.8,63.4), new cjs.Rectangle(-8.2,22,107.2,63.3), new cjs.Rectangle(-8.2,21.8,106.7,63.3), new cjs.Rectangle(-8.1,21.7,106.1,63.2), new cjs.Rectangle(-8.1,21.5,105.6,63.2), new cjs.Rectangle(-8,21.3,105,63.1), new cjs.Rectangle(-7.9,21.2,104.4,63.1), new cjs.Rectangle(-7.9,21,103.9,63), new cjs.Rectangle(-7.8,20.8,103.3,63), new cjs.Rectangle(-7.8,20.7,102.8,62.9), new cjs.Rectangle(-7.7,20.5,102.2,62.9), new cjs.Rectangle(-7.7,20.3,101.7,62.8), new cjs.Rectangle(-7.6,20.1,101.1,62.8), new cjs.Rectangle(-7.6,20,100.6,62.7), new cjs.Rectangle(-7.5,19.8,100,62.7), new cjs.Rectangle(-7.5,19.6,99.5,62.6), new cjs.Rectangle(-7.4,19.5,98.9,62.6), new cjs.Rectangle(-7.4,19.3,98.4,62.6), new cjs.Rectangle(-7.3,19.1,97.8,62.5), new cjs.Rectangle(-7.2,18.9,97.5,62.5), new cjs.Rectangle(-7.2,18.8,97.9,62.4), new cjs.Rectangle(-7.1,18.6,98.2,62.3), new cjs.Rectangle(-7.1,18.4,98.6,62.3), new cjs.Rectangle(-7,18.3,99,62.2), new cjs.Rectangle(-7,18.1,99.4,62.2), new cjs.Rectangle(-6.9,17.9,99.7,62.1), new cjs.Rectangle(-6.9,17.8,100.1,62.1), new cjs.Rectangle(-6.8,17.6,100.4,62.1), new cjs.Rectangle(-6.8,17.4,100.9,62), new cjs.Rectangle(-6.7,17.2,101.2,62), new cjs.Rectangle(-6.7,17.1,101.6,61.9), new cjs.Rectangle(-6.6,16.9,102,61.8), new cjs.Rectangle(-6.6,16.7,102.4,61.8), new cjs.Rectangle(-6.5,16.6,102.7,61.7), new cjs.Rectangle(-6.4,16.4,103.1,61.7), new cjs.Rectangle(-6.4,16.2,103.4,61.6), new cjs.Rectangle(-6.3,16.1,103.8,61.6), new cjs.Rectangle(-6.3,15.9,104.2,61.6), new cjs.Rectangle(-6.2,15.7,104.6,61.5), new cjs.Rectangle(-6.2,15.5,104.9,61.5), new cjs.Rectangle(-6.1,15.4,105.3,61.4), new cjs.Rectangle(-6.1,15.2,105.7,61.3), new cjs.Rectangle(-6,15,106.1,61.3), new cjs.Rectangle(-6,14.9,106.4,61.2), new cjs.Rectangle(-5.9,14.7,106.8,61.2), new cjs.Rectangle(-5.9,14.5,107.2,61.2), new cjs.Rectangle(-5.8,14.4,107.6,61.1), new cjs.Rectangle(-5.7,14.2,107.9,61.1), new cjs.Rectangle(-5.7,14,108.3,61), new cjs.Rectangle(-5.6,13.8,108.6,61), new cjs.Rectangle(-5.6,13.7,109,60.9), new cjs.Rectangle(-5.5,13.5,109.4,60.9), new cjs.Rectangle(-5.5,13.3,109.8,60.8), new cjs.Rectangle(-5.4,13.2,110.1,60.7), new cjs.Rectangle(-5.4,13,110.5,60.7), new cjs.Rectangle(-5.3,12.8,110.9,60.7), new cjs.Rectangle(-5.3,12.6,111.3,60.6), new cjs.Rectangle(-5.2,12.5,111.6,60.6), new cjs.Rectangle(-5.2,12.3,112,60.5), new cjs.Rectangle(-5.1,12.1,112.4,60.5), new cjs.Rectangle(-5.1,12,112.8,60.4), new cjs.Rectangle(-5,11.8,113.1,60.4), new cjs.Rectangle(-4.9,11.6,113.5,60.3), new cjs.Rectangle(-4.9,11.5,113.8,60.3), new cjs.Rectangle(-4.8,11.3,114.2,60.2), new cjs.Rectangle(-4.8,11.1,114.6,60.2), new cjs.Rectangle(-4.7,10.9,115,60.1), new cjs.Rectangle(-4.7,10.8,115.3,60.1), new cjs.Rectangle(-4.6,10.6,115.7,60), new cjs.Rectangle(-4.6,10.4,116.1,60), new cjs.Rectangle(-4.5,10.3,116.5,59.9), new cjs.Rectangle(-4.5,10.1,116.8,59.9), new cjs.Rectangle(-4.4,9.9,117.2,59.8), new cjs.Rectangle(-4.4,9.8,117.6,59.8), new cjs.Rectangle(-4.3,9.6,117.9,59.7), new cjs.Rectangle(-4.2,9.4,118.3,59.7), new cjs.Rectangle(-4.2,9.2,118.7,60.3), new cjs.Rectangle(-4.1,9.1,119,61), new cjs.Rectangle(-4.1,8.9,119.4,61.7), new cjs.Rectangle(-4,8.7,119.8,62.4), new cjs.Rectangle(-4,8.6,120.2,63), new cjs.Rectangle(-3.9,8.4,120.5,63.7), new cjs.Rectangle(-3.9,8.2,120.9,64.4), new cjs.Rectangle(-3.8,8.1,121.3,65), new cjs.Rectangle(-3.8,7.9,121.7,65.8), new cjs.Rectangle(-3.7,7.7,122,66.4), new cjs.Rectangle(-3.7,7.5,122.4,67.1), new cjs.Rectangle(-3.6,7.4,122.8,67.8), new cjs.Rectangle(-3.5,7.2,123.1,68.4), new cjs.Rectangle(-3.5,7,123.5,69.2), new cjs.Rectangle(-3.4,6.9,123.9,69.8), new cjs.Rectangle(-3.4,6.7,124.2,70.5), new cjs.Rectangle(-3.3,6.5,124.6,71.2), new cjs.Rectangle(-3.3,6.3,125,71.9), new cjs.Rectangle(-3.2,6.2,125.4,72.6), new cjs.Rectangle(-3.2,6,125.7,73.2), new cjs.Rectangle(-3.1,5.8,126.1,73.9), new cjs.Rectangle(-3.1,5.7,126.5,74.6), new cjs.Rectangle(-3,5.5,126.9,75.3), new cjs.Rectangle(-3,5.3,127.2,76), new cjs.Rectangle(-2.9,5.2,127.6,76.6), new cjs.Rectangle(-2.9,5,128,77.3), new cjs.Rectangle(-2.8,4.8,128.3,78), new cjs.Rectangle(-2.7,4.6,128.7,78.7), new cjs.Rectangle(-2.7,4.5,129,79.4), new cjs.Rectangle(-2.6,4.3,129.4,80), new cjs.Rectangle(-2.6,4.1,129.8,80.7), new cjs.Rectangle(-2.5,4,130.2,81.4), new cjs.Rectangle(-2.5,3.8,130.6,82.1), new cjs.Rectangle(-2.4,3.6,130.9,82.8), new cjs.Rectangle(-2.4,3.5,131.3,83.4), new cjs.Rectangle(-2.3,3.3,131.7,84.1), new cjs.Rectangle(-2.3,3.1,132.1,84.8), new cjs.Rectangle(-2.2,2.9,132.4,85.4), new cjs.Rectangle(-2.2,2.8,132.8,86.2), new cjs.Rectangle(-2.1,2.6,133.2,86.8), new cjs.Rectangle(-2,2.4,133.5,87.5), new cjs.Rectangle(-2,2.3,133.9,88.2), new cjs.Rectangle(-1.9,2.1,134.3,88.9), new cjs.Rectangle(-1.9,1.9,134.6,89.6), new cjs.Rectangle(-1.8,1.7,135,90.3), new cjs.Rectangle(-1.8,1.6,135.4,90.9), new cjs.Rectangle(-1.7,1.4,135.8,91.6), new cjs.Rectangle(-1.7,1.2,136.1,92.3), new cjs.Rectangle(-1.6,1.1,136.5,93), new cjs.Rectangle(-1.6,0.9,136.9,93.7), new cjs.Rectangle(-1.5,0.7,137.3,94.3), new cjs.Rectangle(-1.5,0.6,137.6,95), new cjs.Rectangle(-1.4,0.4,138,95.7), new cjs.Rectangle(-1.4,0.2,138.4,96.4), new cjs.Rectangle(-1.3,0,138.7,97.1), new cjs.Rectangle(-1.2,-0.1,139.1,97.7), new cjs.Rectangle(-1.2,-0.3,139.5,98.4), new cjs.Rectangle(-1.1,-0.5,139.8,99.1), new cjs.Rectangle(-1.1,-0.6,140.2,99.8), new cjs.Rectangle(-1,-0.8,140.6,100.4), new cjs.Rectangle(-1,-1,141,101.1)];


(lib.Символ_2__копия_4_Слой_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.instance = new lib.Символ4копия2();
	this.instance.parent = this;
	this.instance.setTransform(6.95,-185.55,0.3188,0.3188,0,0,0,23.1,16);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(127).to({_off:false},0).to({scaleX:1,scaleY:1},8).wait(62).to({regX:23.2,scaleX:0.2594,scaleY:0.2594,x:7,y:-185.5,alpha:0},8).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2__копия_3_Слой_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.instance = new lib.Символ4копия();
	this.instance.parent = this;
	this.instance.setTransform(6.9,-185.45,0.4876,0.4876,0,0,0,22.9,16);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(167).to({_off:false},0).to({regX:23.1,scaleX:1,scaleY:1,x:6.95,y:-185.55},8).wait(22).to({scaleX:0.425,scaleY:0.425,alpha:0},8).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Символ_2_Слой_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.instance = new lib.Символ4();
	this.instance.parent = this;
	this.instance.setTransform(9.2,-185.55,0.3313,0.3313,0,0,0,23.1,16);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(34).to({_off:false},0).to({scaleX:1,scaleY:1,x:6.95},8).wait(156).to({alpha:0},6).wait(1));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Слой_4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_4
	this.instance = new lib.Символ1копия2();
	this.instance.parent = this;
	this.instance.setTransform(865.25,551.95,1.4997,1.4997,-99.7893,0,0,115.9,61.3);
	this.instance.alpha = 0.1602;

	this.instance_1 = new lib.Символ1копия2();
	this.instance_1.parent = this;
	this.instance_1.setTransform(174.7,459.45,1.4997,1.4997,0,0,0,115.9,61.3);
	this.instance_1.alpha = 0.1602;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Слой_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_3
	this.instance = new lib.Символ1копия();
	this.instance.parent = this;
	this.instance.setTransform(761.4,340.3,1,1,0,0,0,93.9,70.9);
	this.instance.alpha = 0.3516;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Слой_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_2
	this.instance = new lib.Символ1();
	this.instance.parent = this;
	this.instance.setTransform(791.55,229.25,0.5072,0.5072,127.5167,0,0,69.5,49.5);
	this.instance.alpha = 0.3516;

	this.instance_1 = new lib.Символ1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(262.15,242.25,1,1,0,0,0,69.5,49.6);
	this.instance_1.alpha = 0.3516;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_35 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_35
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(225.8,251.2,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(30).to({_off:false},0).wait(175));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_34 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_34
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(780.65,5.5,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(118).to({_off:false},0).wait(87));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_33 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_33
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(757.8,5,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(114).to({_off:false},0).wait(91));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_32 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_32
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(737.4,9.8,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(110).to({_off:false},0).wait(95));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_31 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_31
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(717.45,23.1,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(107).to({_off:false},0).wait(98));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_29 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_29
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(700.6,40.3,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(104).to({_off:false},0).wait(101));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_28 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_28
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(684.95,77.3,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(100).to({_off:false},0).wait(105));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_27 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_27
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(671.7,104.05,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(97).to({_off:false},0).wait(108));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_26 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_26
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(657,127.8,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(94).to({_off:false},0).wait(111));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_25 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_25
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(638.7,141.7,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(91).to({_off:false},0).wait(114));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_24 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_24
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(617.8,152.1,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(88).to({_off:false},0).wait(117));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_23 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_23
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(596.75,160.6,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(85).to({_off:false},0).wait(120));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_22 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_22
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(574.45,161.6,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(82).to({_off:false},0).wait(123));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_21 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_21
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(554,157.85,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(79).to({_off:false},0).wait(126));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_20 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_20
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(528.75,147.7,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(76).to({_off:false},0).wait(129));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_19 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_19
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(505.7,136.6,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(72).to({_off:false},0).wait(133));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_18 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_18
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(482.65,130.15,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(68).to({_off:false},0).wait(137));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_17 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_17
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(454.8,125.4,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(63).to({_off:false},0).wait(142));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_16 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_16
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(424.55,129.7,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(59).to({_off:false},0).wait(146));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_15 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_15
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(395.75,150.2,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(55).to({_off:false},0).wait(150));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_14 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_14
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(370.25,186.05,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(51).to({_off:false},0).wait(154));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_13 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_13
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(346.95,218.8,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(47).to({_off:false},0).wait(158));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_12 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_12
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(320.25,244.8,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(43).to({_off:false},0).wait(162));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_11 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_11
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(287.1,259.6,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(39).to({_off:false},0).wait(166));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_10 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_10
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(257.2,258,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(35).to({_off:false},0).wait(170));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_9 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_9
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(191.4,241.6,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(25).to({_off:false},0).wait(180));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_8
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(156.6,238,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(20).to({_off:false},0).wait(185));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_7
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(121.6,251.2,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(15).to({_off:false},0).wait(190));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_6
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(93,286.4,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10).to({_off:false},0).wait(195));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_5
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(67.8,324.2,1,1,0,0,0,3,68.4);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(5).to({_off:false},0).wait(200));

}).prototype = p = new cjs.MovieClip();


(lib.Clip_Group_Слой_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_1
	this.instance = new lib.Символ3();
	this.instance.parent = this;
	this.instance.setTransform(43.4,341.6,1,1,0,0,0,3,68.4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(205));

}).prototype = p = new cjs.MovieClip();


(lib.Символ2копия4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_205 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(205).call(this.frame_205).wait(1));

	// Слой_4_obj_
	this.Слой_4 = new lib.Символ_2__копия_4_Слой_4();
	this.Слой_4.name = "Слой_4";
	this.Слой_4.parent = this;
	this.Слой_4.depth = 0;
	this.Слой_4.isAttachedToCamera = 0
	this.Слой_4.isAttachedToMask = 0
	this.Слой_4.layerDepth = 0
	this.Слой_4.layerIndex = 0
	this.Слой_4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_4).wait(206));

	// Слой_3_obj_
	this.Слой_3 = new lib.Символ_2__копия_4_Слой_3();
	this.Слой_3.name = "Слой_3";
	this.Слой_3.parent = this;
	this.Слой_3.depth = 0;
	this.Слой_3.isAttachedToCamera = 0
	this.Слой_3.isAttachedToMask = 0
	this.Слой_3.layerDepth = 0
	this.Слой_3.layerIndex = 1
	this.Слой_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_3).wait(206));

	// Слой_2_obj_
	this.Слой_2 = new lib.Символ_2__копия_4_Слой_2();
	this.Слой_2.name = "Слой_2";
	this.Слой_2.parent = this;
	this.Слой_2.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_2.depth = 0;
	this.Слой_2.isAttachedToCamera = 0
	this.Слой_2.isAttachedToMask = 0
	this.Слой_2.layerDepth = 0
	this.Слой_2.layerIndex = 2
	this.Слой_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_2).wait(206));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_2__копия_4_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 3
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(206));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-28.6,-28.6,75.5,75.5);
p.frameBounds = [rect, new cjs.Rectangle(-28.8,-28.8,75.9,75.9), new cjs.Rectangle(-29,-29,76.4,76.4), new cjs.Rectangle(-29.3,-29.3,76.8,76.8), new cjs.Rectangle(-29.5,-29.5,77.2,77.2), new cjs.Rectangle(-29.7,-29.7,77.6,77.6), new cjs.Rectangle(-29.9,-29.9,78.1,78.1), new cjs.Rectangle(-30.1,-30.1,78.5,78.5), new cjs.Rectangle(-30.3,-30.3,78.9,78.9), new cjs.Rectangle(-30.5,-30.5,79.3,79.3), new cjs.Rectangle(-30.7,-30.7,79.8,79.8), new cjs.Rectangle(-31,-31,80.2,80.2), new cjs.Rectangle(-31.2,-31.2,80.6,80.6), new cjs.Rectangle(-31.4,-31.4,81,81), new cjs.Rectangle(-31.6,-31.6,81.5,81.5), new cjs.Rectangle(-31.8,-31.8,81.9,81.9), new cjs.Rectangle(-32,-32,82.3,82.3), new cjs.Rectangle(-32.2,-32.2,82.7,82.7), new cjs.Rectangle(-32.4,-32.4,83.2,83.2), new cjs.Rectangle(-32.6,-32.6,83.6,83.6), new cjs.Rectangle(-32.9,-32.9,84,84), new cjs.Rectangle(-33.1,-33.1,84.4,84.4), new cjs.Rectangle(-33.3,-33.3,84.9,84.9), new cjs.Rectangle(-33.5,-33.5,85.3,85.3), new cjs.Rectangle(-33.7,-33.7,85.7,85.7), new cjs.Rectangle(-33.9,-33.9,86.1,86.1), new cjs.Rectangle(-34.1,-34.1,86.6,86.6), new cjs.Rectangle(-34.3,-34.3,87,87), new cjs.Rectangle(-34.5,-34.5,87.4,87.4), new cjs.Rectangle(-34.8,-34.8,87.8,87.8), new cjs.Rectangle(-35,-35,88.3,88.3), new cjs.Rectangle(-35.2,-35.2,88.7,88.7), new cjs.Rectangle(-35.4,-35.4,89.1,89.1), new cjs.Rectangle(-35.6,-35.6,89.5,89.5), new cjs.Rectangle(-35.8,-35.8,90,90), new cjs.Rectangle(-36,-36,90.4,90.4), new cjs.Rectangle(-36.2,-36.2,90.8,90.8), new cjs.Rectangle(-36.4,-36.4,91.2,91.2), new cjs.Rectangle(-36.7,-36.7,91.7,91.7), new cjs.Rectangle(-36.9,-36.9,92.1,92.1), new cjs.Rectangle(-37.1,-37.1,92.5,92.5), new cjs.Rectangle(-37.3,-37.3,92.9,92.9), new cjs.Rectangle(-37.5,-37.5,93.4,93.4), new cjs.Rectangle(-37.7,-37.7,93.8,93.8), new cjs.Rectangle(-37.9,-37.9,94.2,94.2), new cjs.Rectangle(-38.1,-38.1,94.6,94.6), new cjs.Rectangle(-38.4,-38.4,95.1,95.1), new cjs.Rectangle(-38.6,-38.6,95.5,95.5), new cjs.Rectangle(-38.8,-38.8,95.9,95.9), new cjs.Rectangle(-39,-39,96.3,96.3), new cjs.Rectangle(-39.2,-39.2,96.7,96.7), new cjs.Rectangle(-39.4,-39.4,97.2,97.2), new cjs.Rectangle(-39.6,-39.6,97.6,97.6), new cjs.Rectangle(-39.8,-39.8,98,98), new cjs.Rectangle(-40,-40,98.4,98.4), new cjs.Rectangle(-40.3,-40.3,98.9,98.9), new cjs.Rectangle(-40.5,-40.5,99.3,99.3), new cjs.Rectangle(-40.7,-40.7,99.7,99.7), new cjs.Rectangle(-40.9,-40.9,100.1,100.1), new cjs.Rectangle(-41.1,-41.1,100.6,100.6), new cjs.Rectangle(-41.3,-41.3,101,101), new cjs.Rectangle(-41.5,-41.5,101.4,101.4), new cjs.Rectangle(-41.7,-41.7,101.8,101.8), new cjs.Rectangle(-41.9,-41.9,102.2,102.2), new cjs.Rectangle(-42.2,-42.2,102.7,102.7), new cjs.Rectangle(-42.4,-42.4,103.1,103.1), new cjs.Rectangle(-42.6,-42.6,103.5,103.5), new cjs.Rectangle(-42.8,-42.8,103.9,103.9), new cjs.Rectangle(-43,-43,104.4,104.4), new cjs.Rectangle(-43.2,-43.2,104.8,104.8), new cjs.Rectangle(-43.4,-43.4,105.2,105.2), new cjs.Rectangle(-43.6,-43.6,105.6,105.6), new cjs.Rectangle(-43.8,-43.8,106,106), new cjs.Rectangle(-44.1,-44.1,106.5,106.5), new cjs.Rectangle(-44.3,-44.3,106.9,106.9), new cjs.Rectangle(-44.5,-44.5,107.3,107.3), new cjs.Rectangle(-44.7,-44.7,107.7,107.7), new cjs.Rectangle(-44.9,-44.9,108.2,108.2), new cjs.Rectangle(-45.1,-45.1,108.6,108.6), new cjs.Rectangle(-45.3,-45.3,109,109), new cjs.Rectangle(-45.5,-45.5,109.4,109.4), new cjs.Rectangle(-45.8,-45.8,109.9,109.9), new cjs.Rectangle(-46,-46,110.3,110.3), rect=new cjs.Rectangle(-46.2,-46.2,110.7,110.7), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(-46.2,-47.3,110.7,111.9), new cjs.Rectangle(-46.2,-51.1,110.7,115.6), new cjs.Rectangle(-46.2,-54.9,110.7,119.4), new cjs.Rectangle(-46.2,-58.6,110.7,123.2), new cjs.Rectangle(-46.2,-62.4,110.7,126.9), new cjs.Rectangle(-46.2,-66.2,110.7,130.7), new cjs.Rectangle(-46.2,-69.9,110.7,134.5), new cjs.Rectangle(-46.2,-73.7,110.7,138.2), new cjs.Rectangle(-46.2,-77.5,110.7,142), new cjs.Rectangle(-46.2,-81.2,110.7,145.8), new cjs.Rectangle(-46.2,-85,110.7,149.6), new cjs.Rectangle(-46.2,-88.8,110.7,153.3), new cjs.Rectangle(-46.2,-92.5,110.7,157.1), new cjs.Rectangle(-46.2,-96.3,110.7,160.9), new cjs.Rectangle(-46.2,-100.1,110.7,164.6), new cjs.Rectangle(-46.2,-103.9,110.7,168.4), new cjs.Rectangle(-46.2,-107.6,110.7,172.2), new cjs.Rectangle(-46.2,-111.4,110.7,175.9), new cjs.Rectangle(-46.2,-115.2,110.7,179.7), new cjs.Rectangle(-46.2,-118.9,110.7,183.5), new cjs.Rectangle(-46.2,-122.7,110.7,187.2), new cjs.Rectangle(-46.2,-126.5,110.7,191), new cjs.Rectangle(-46.2,-130.2,110.7,194.8), new cjs.Rectangle(-46.2,-134,110.7,198.6), new cjs.Rectangle(-46.2,-137.8,110.7,202.3), new cjs.Rectangle(-46.2,-141.5,110.7,206.1), new cjs.Rectangle(-46.2,-145.3,110.7,209.9), new cjs.Rectangle(-46.2,-149.1,110.7,213.6), new cjs.Rectangle(-46.2,-152.9,110.7,217.4), new cjs.Rectangle(-46.2,-190.6,110.7,255.2), new cjs.Rectangle(-46.2,-192,110.7,256.5), new cjs.Rectangle(-46.2,-193.4,110.7,257.9), new cjs.Rectangle(-46.2,-194.7,110.7,259.2), new cjs.Rectangle(-46.2,-196.1,110.7,260.6), new cjs.Rectangle(-46.2,-197.5,110.7,262), new cjs.Rectangle(-46.2,-198.8,110.7,263.3), new cjs.Rectangle(-46.2,-200.2,110.7,264.7), rect=new cjs.Rectangle(-46.2,-201.5,110.7,266.1), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(-44,-200,106.3,262.4), new cjs.Rectangle(-41.8,-198.6,101.9,258.7), new cjs.Rectangle(-39.6,-197.1,97.5,255), new cjs.Rectangle(-37.4,-195.6,93.1,251.3), new cjs.Rectangle(-35.2,-194.1,88.7,247.6), new cjs.Rectangle(-33,-192.6,84.3,243.9), new cjs.Rectangle(-30.8,-191.1,79.9,240.2), new cjs.Rectangle(-28.6,-189.6,75.5,236.5)];


(lib.Символ2копия3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_205 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(205).call(this.frame_205).wait(1));

	// Слой_4_obj_
	this.Слой_4 = new lib.Символ_2__копия_3_Слой_4();
	this.Слой_4.name = "Слой_4";
	this.Слой_4.parent = this;
	this.Слой_4.depth = 0;
	this.Слой_4.isAttachedToCamera = 0
	this.Слой_4.isAttachedToMask = 0
	this.Слой_4.layerDepth = 0
	this.Слой_4.layerIndex = 0
	this.Слой_4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_4).wait(206));

	// Слой_3_obj_
	this.Слой_3 = new lib.Символ_2__копия_3_Слой_3();
	this.Слой_3.name = "Слой_3";
	this.Слой_3.parent = this;
	this.Слой_3.depth = 0;
	this.Слой_3.isAttachedToCamera = 0
	this.Слой_3.isAttachedToMask = 0
	this.Слой_3.layerDepth = 0
	this.Слой_3.layerIndex = 1
	this.Слой_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_3).wait(206));

	// Слой_2_obj_
	this.Слой_2 = new lib.Символ_2__копия_3_Слой_2();
	this.Слой_2.name = "Слой_2";
	this.Слой_2.parent = this;
	this.Слой_2.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_2.depth = 0;
	this.Слой_2.isAttachedToCamera = 0
	this.Слой_2.isAttachedToMask = 0
	this.Слой_2.layerDepth = 0
	this.Слой_2.layerIndex = 2
	this.Слой_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_2).wait(206));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_2__копия_3_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 3
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(206));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-28.6,-28.6,75.5,75.5);
p.frameBounds = [rect, new cjs.Rectangle(-28.8,-28.8,75.8,75.8), new cjs.Rectangle(-28.9,-28.9,76.1,76.1), new cjs.Rectangle(-29.1,-29.1,76.4,76.4), new cjs.Rectangle(-29.2,-29.2,76.6,76.6), new cjs.Rectangle(-29.3,-29.3,76.9,76.9), new cjs.Rectangle(-29.5,-29.5,77.2,77.2), new cjs.Rectangle(-29.6,-29.6,77.5,77.5), new cjs.Rectangle(-29.8,-29.8,77.8,77.8), new cjs.Rectangle(-29.9,-29.9,78.1,78.1), new cjs.Rectangle(-30.1,-30.1,78.4,78.4), new cjs.Rectangle(-30.2,-30.2,78.7,78.7), new cjs.Rectangle(-30.3,-30.3,78.9,78.9), new cjs.Rectangle(-30.5,-30.5,79.2,79.2), new cjs.Rectangle(-30.6,-30.6,79.5,79.5), new cjs.Rectangle(-30.8,-30.8,79.8,79.8), new cjs.Rectangle(-30.9,-30.9,80.1,80.1), new cjs.Rectangle(-31.1,-31.1,80.4,80.4), new cjs.Rectangle(-31.2,-31.2,80.7,80.7), new cjs.Rectangle(-31.3,-31.3,81,81), new cjs.Rectangle(-31.5,-31.5,81.2,81.2), new cjs.Rectangle(-31.6,-31.6,81.5,81.5), new cjs.Rectangle(-31.8,-31.8,81.8,81.8), new cjs.Rectangle(-31.9,-31.9,82.1,82.1), new cjs.Rectangle(-32,-32,82.4,82.4), new cjs.Rectangle(-32.2,-32.2,82.7,82.7), new cjs.Rectangle(-32.3,-32.3,83,83), new cjs.Rectangle(-32.5,-32.5,83.2,83.2), new cjs.Rectangle(-32.6,-32.6,83.5,83.5), new cjs.Rectangle(-32.8,-32.8,83.8,83.8), new cjs.Rectangle(-32.9,-32.9,84.1,84.1), new cjs.Rectangle(-33,-33,84.4,84.4), new cjs.Rectangle(-33.2,-33.2,84.7,84.7), new cjs.Rectangle(-33.3,-33.3,85,85), new cjs.Rectangle(-33.5,-33.5,85.3,85.3), new cjs.Rectangle(-33.6,-33.6,85.5,85.5), new cjs.Rectangle(-33.8,-33.8,85.8,85.8), new cjs.Rectangle(-33.9,-33.9,86.1,86.1), new cjs.Rectangle(-34,-34,86.4,86.4), new cjs.Rectangle(-34.2,-34.2,86.7,86.7), new cjs.Rectangle(-34.3,-34.3,87,87), new cjs.Rectangle(-34.5,-34.5,87.3,87.3), new cjs.Rectangle(-34.6,-34.6,87.6,87.6), new cjs.Rectangle(-34.8,-34.8,87.8,87.8), new cjs.Rectangle(-34.9,-34.9,88.1,88.1), new cjs.Rectangle(-35,-35,88.4,88.4), new cjs.Rectangle(-35.2,-35.2,88.7,88.7), new cjs.Rectangle(-35.3,-35.3,89,89), new cjs.Rectangle(-35.5,-35.5,89.3,89.3), new cjs.Rectangle(-35.6,-35.6,89.6,89.6), new cjs.Rectangle(-35.8,-35.8,89.8,89.8), new cjs.Rectangle(-35.9,-35.9,90.1,90.1), new cjs.Rectangle(-36,-36,90.4,90.4), new cjs.Rectangle(-36.2,-36.2,90.7,90.7), new cjs.Rectangle(-36.3,-36.3,91,91), new cjs.Rectangle(-36.5,-36.5,91.3,91.3), new cjs.Rectangle(-36.6,-36.6,91.6,91.6), new cjs.Rectangle(-36.8,-36.8,91.9,91.9), new cjs.Rectangle(-36.9,-36.9,92.1,92.1), new cjs.Rectangle(-37,-37,92.4,92.4), new cjs.Rectangle(-37.2,-37.2,92.7,92.7), new cjs.Rectangle(-37.3,-37.3,93,93), new cjs.Rectangle(-37.5,-37.5,93.3,93.3), new cjs.Rectangle(-37.6,-37.6,93.6,93.6), new cjs.Rectangle(-37.8,-37.8,93.9,93.9), new cjs.Rectangle(-37.9,-37.9,94.1,94.1), new cjs.Rectangle(-38,-38,94.4,94.4), new cjs.Rectangle(-38.2,-38.2,94.7,94.7), new cjs.Rectangle(-38.3,-38.3,95,95), new cjs.Rectangle(-38.5,-38.5,95.3,95.3), new cjs.Rectangle(-38.6,-38.6,95.6,95.6), new cjs.Rectangle(-38.8,-38.8,95.9,95.9), new cjs.Rectangle(-38.9,-38.9,96.1,96.1), new cjs.Rectangle(-39,-39,96.4,96.4), new cjs.Rectangle(-39.2,-39.2,96.7,96.7), new cjs.Rectangle(-39.3,-39.3,97,97), new cjs.Rectangle(-39.5,-39.5,97.3,97.3), new cjs.Rectangle(-39.6,-39.6,97.6,97.6), new cjs.Rectangle(-39.8,-39.8,97.9,97.9), new cjs.Rectangle(-39.9,-39.9,98.1,98.1), new cjs.Rectangle(-40,-40,98.4,98.4), new cjs.Rectangle(-40.2,-40.2,98.7,98.7), new cjs.Rectangle(-40.3,-40.3,99,99), new cjs.Rectangle(-40.5,-40.5,99.3,99.3), new cjs.Rectangle(-40.6,-40.6,99.6,99.6), new cjs.Rectangle(-40.8,-40.8,99.9,99.9), new cjs.Rectangle(-40.9,-40.9,100.1,100.1), new cjs.Rectangle(-41,-41,100.4,100.4), new cjs.Rectangle(-41.2,-41.2,100.7,100.7), new cjs.Rectangle(-41.3,-41.3,101,101), new cjs.Rectangle(-41.5,-41.5,101.3,101.3), new cjs.Rectangle(-41.6,-41.6,101.6,101.6), new cjs.Rectangle(-41.8,-41.8,101.9,101.9), new cjs.Rectangle(-41.9,-41.9,102.1,102.1), new cjs.Rectangle(-42,-42,102.4,102.4), new cjs.Rectangle(-42.2,-42.2,102.7,102.7), new cjs.Rectangle(-42.3,-42.3,103,103), new cjs.Rectangle(-42.5,-42.5,103.3,103.3), new cjs.Rectangle(-42.6,-42.6,103.6,103.6), new cjs.Rectangle(-42.8,-42.8,103.9,103.9), new cjs.Rectangle(-42.9,-42.9,104.1,104.1), new cjs.Rectangle(-43,-43,104.4,104.4), new cjs.Rectangle(-43.2,-43.2,104.7,104.7), new cjs.Rectangle(-43.3,-43.3,105,105), new cjs.Rectangle(-43.5,-43.5,105.3,105.3), new cjs.Rectangle(-43.6,-43.6,105.6,105.6), new cjs.Rectangle(-43.7,-43.7,105.8,105.8), new cjs.Rectangle(-43.9,-43.9,106.1,106.1), new cjs.Rectangle(-44,-44,106.4,106.4), new cjs.Rectangle(-44.2,-44.2,106.7,106.7), new cjs.Rectangle(-44.3,-44.3,107,107), new cjs.Rectangle(-44.5,-44.5,107.3,107.3), new cjs.Rectangle(-44.6,-44.6,107.6,107.6), new cjs.Rectangle(-44.7,-44.7,107.8,107.8), new cjs.Rectangle(-44.9,-44.9,108.1,108.1), new cjs.Rectangle(-45,-45,108.4,108.4), new cjs.Rectangle(-45.2,-45.2,108.7,108.7), new cjs.Rectangle(-45.3,-45.3,109,109), new cjs.Rectangle(-45.5,-45.5,109.3,109.3), new cjs.Rectangle(-45.6,-45.6,109.6,109.6), new cjs.Rectangle(-45.7,-45.7,109.8,109.8), new cjs.Rectangle(-45.9,-45.9,110.1,110.1), new cjs.Rectangle(-46,-46,110.4,110.4), rect=new cjs.Rectangle(-46.2,-46.2,110.7,110.7), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(-46.2,-47.3,110.7,111.9), new cjs.Rectangle(-46.2,-51.1,110.7,115.6), new cjs.Rectangle(-46.2,-54.9,110.7,119.4), new cjs.Rectangle(-46.2,-58.6,110.7,123.2), new cjs.Rectangle(-46.2,-62.4,110.7,126.9), new cjs.Rectangle(-46.2,-66.2,110.7,130.7), new cjs.Rectangle(-46.2,-69.9,110.7,134.5), new cjs.Rectangle(-46.2,-73.7,110.7,138.2), new cjs.Rectangle(-46.2,-77.5,110.7,142), new cjs.Rectangle(-46.2,-81.2,110.7,145.8), new cjs.Rectangle(-46.2,-85,110.7,149.6), new cjs.Rectangle(-46.2,-88.8,110.7,153.3), new cjs.Rectangle(-46.2,-92.5,110.7,157.1), new cjs.Rectangle(-46.2,-96.3,110.7,160.9), new cjs.Rectangle(-46.2,-100.1,110.7,164.6), new cjs.Rectangle(-46.2,-103.9,110.7,168.4), new cjs.Rectangle(-46.2,-107.6,110.7,172.2), new cjs.Rectangle(-46.2,-111.4,110.7,175.9), new cjs.Rectangle(-46.2,-115.2,110.7,179.7), new cjs.Rectangle(-46.2,-118.9,110.7,183.5), new cjs.Rectangle(-46.2,-122.7,110.7,187.2), new cjs.Rectangle(-46.2,-126.5,110.7,191), new cjs.Rectangle(-46.2,-130.2,110.7,194.8), new cjs.Rectangle(-46.2,-134,110.7,198.6), new cjs.Rectangle(-46.2,-137.8,110.7,202.3), new cjs.Rectangle(-46.2,-141.5,110.7,206.1), new cjs.Rectangle(-46.2,-145.3,110.7,209.9), new cjs.Rectangle(-46.2,-149.1,110.7,213.6), new cjs.Rectangle(-46.2,-152.9,110.7,217.4), new cjs.Rectangle(-46.2,-193.2,110.7,257.8), new cjs.Rectangle(-46.2,-194.3,110.7,258.8), new cjs.Rectangle(-46.2,-195.3,110.7,259.8), new cjs.Rectangle(-46.2,-196.4,110.7,260.9), new cjs.Rectangle(-46.2,-197.4,110.7,261.9), new cjs.Rectangle(-46.2,-198.4,110.7,263), new cjs.Rectangle(-46.2,-199.5,110.7,264), new cjs.Rectangle(-46.2,-200.5,110.7,265.1), rect=new cjs.Rectangle(-46.2,-201.5,110.7,266.1), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(-44,-200.4,106.3,262.7), new cjs.Rectangle(-41.8,-199.2,101.9,259.4), new cjs.Rectangle(-39.6,-198.1,97.5,256), new cjs.Rectangle(-37.4,-196.9,93.1,252.7), new cjs.Rectangle(-35.2,-195.8,88.7,249.3), new cjs.Rectangle(-33,-194.6,84.3,245.9), new cjs.Rectangle(-30.8,-193.5,79.9,242.6), new cjs.Rectangle(-28.6,-192.3,75.5,239.2)];


(lib.Символ2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_204 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(204).call(this.frame_204).wait(1));

	// Слой_4_obj_
	this.Слой_4 = new lib.Символ_2_Слой_4();
	this.Слой_4.name = "Слой_4";
	this.Слой_4.parent = this;
	this.Слой_4.depth = 0;
	this.Слой_4.isAttachedToCamera = 0
	this.Слой_4.isAttachedToMask = 0
	this.Слой_4.layerDepth = 0
	this.Слой_4.layerIndex = 0
	this.Слой_4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_4).wait(205));

	// Слой_3_obj_
	this.Слой_3 = new lib.Символ_2_Слой_3();
	this.Слой_3.name = "Слой_3";
	this.Слой_3.parent = this;
	this.Слой_3.depth = 0;
	this.Слой_3.isAttachedToCamera = 0
	this.Слой_3.isAttachedToMask = 0
	this.Слой_3.layerDepth = 0
	this.Слой_3.layerIndex = 1
	this.Слой_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_3).wait(205));

	// Слой_2_obj_
	this.Слой_2 = new lib.Символ_2_Слой_2();
	this.Слой_2.name = "Слой_2";
	this.Слой_2.parent = this;
	this.Слой_2.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_2.depth = 0;
	this.Слой_2.isAttachedToCamera = 0
	this.Слой_2.isAttachedToMask = 0
	this.Слой_2.layerDepth = 0
	this.Слой_2.layerIndex = 2
	this.Слой_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_2).wait(205));

	// Слой_1_obj_
	this.Слой_1 = new lib.Символ_2_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(9.1,9.1,1,1,0,0,0,9.1,9.1);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 3
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(205));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(-28.6,-28.6,75.5,75.5);
p.frameBounds = [rect, new cjs.Rectangle(-29.2,-29.2,76.7,76.7), new cjs.Rectangle(-29.8,-29.8,77.9,77.9), new cjs.Rectangle(-30.4,-30.4,79.2,79.2), new cjs.Rectangle(-31,-31,80.4,80.4), new cjs.Rectangle(-31.7,-31.7,81.6,81.6), new cjs.Rectangle(-32.3,-32.3,82.8,82.8), new cjs.Rectangle(-32.9,-32.9,84,84), new cjs.Rectangle(-33.5,-33.5,85.2,85.2), new cjs.Rectangle(-34.1,-34.1,86.5,86.5), new cjs.Rectangle(-34.7,-34.7,87.7,87.7), new cjs.Rectangle(-35.3,-35.3,88.9,88.9), new cjs.Rectangle(-35.9,-35.9,90.1,90.1), new cjs.Rectangle(-36.5,-36.5,91.3,91.3), new cjs.Rectangle(-37.1,-37.1,92.5,92.5), new cjs.Rectangle(-37.7,-37.7,93.8,93.8), new cjs.Rectangle(-38.3,-38.3,95,95), new cjs.Rectangle(-38.9,-38.9,96.2,96.2), new cjs.Rectangle(-39.5,-39.5,97.4,97.4), new cjs.Rectangle(-40.1,-40.1,98.6,98.6), new cjs.Rectangle(-40.7,-40.7,99.8,99.8), new cjs.Rectangle(-41.3,-41.3,101,101), new cjs.Rectangle(-41.9,-43.5,102.2,103.8), new cjs.Rectangle(-42.5,-47.3,103.4,108.2), new cjs.Rectangle(-43.1,-51.1,104.6,112.6), new cjs.Rectangle(-43.8,-54.9,105.9,117), new cjs.Rectangle(-44.4,-58.6,107.1,121.3), new cjs.Rectangle(-45,-62.4,108.3,125.7), new cjs.Rectangle(-45.6,-66.2,109.5,130.1), new cjs.Rectangle(-46.2,-69.9,110.7,134.5), new cjs.Rectangle(-46.2,-73.7,110.7,138.2), new cjs.Rectangle(-46.2,-77.5,110.7,142), new cjs.Rectangle(-46.2,-81.2,110.7,145.8), new cjs.Rectangle(-46.2,-85,110.7,149.6), new cjs.Rectangle(-46.2,-191.2,110.7,255.7), new cjs.Rectangle(-46.2,-193.2,110.7,257.7), new cjs.Rectangle(-46.2,-194.5,110.7,259), new cjs.Rectangle(-46.2,-195.8,110.7,260.4), new cjs.Rectangle(-46.2,-197.1,110.7,261.7), new cjs.Rectangle(-46.2,-198.5,110.7,263.1), new cjs.Rectangle(-46.2,-199.9,110.7,264.4), new cjs.Rectangle(-46.2,-201.2,110.7,265.7), rect=new cjs.Rectangle(-46.2,-202.5,110.7,267.1), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(-43.2,-202.5,104.8,264.1), new cjs.Rectangle(-40.3,-202.5,99,261.2), new cjs.Rectangle(-37.4,-202.5,93.1,258.3), new cjs.Rectangle(-34.5,-202.5,87.3,255.3), new cjs.Rectangle(-31.6,-202.5,81.4,252.4), new cjs.Rectangle(-28.6,-202.5,75.5,249.4)];


(lib.Scene_1_Слой_8 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_8
	this.instance = new lib.Символ2копия4();
	this.instance.parent = this;
	this.instance.setTransform(741.8,499.05,0.8095,0.8095);

	this.instance_1 = new lib.Символ2копия3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(870.8,368.95,0.8519,0.8519,0,0,0,9.2,9.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.Scene_1_Слой_7 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Слой_7
	this.instance = new lib.Символ2();
	this.instance.parent = this;
	this.instance.setTransform(239,626.05,0.7103,0.7103);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119));

}).prototype = p = new cjs.MovieClip();


(lib.ClipGroup = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_204 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(204).call(this.frame_204).wait(1));

	// Слой_4 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_23 = new cjs.Graphics().p("EhBMAbPQAeAGApgMIBEgWQDNgvCMhLQBYguBJhQQA+hFA4hkQBMiHA9hgQBOh6BNhhQBRhlA3gyQBShMBaggQBugmCBAAQCBABCSAgQCSAgBsAjQBrAiCzA3QCzA3BJAKQBKAJBQgOQBQgPBIgcQBTghBRg4QBCguBPhGQB9hxCQjAQA+hUBUiIICKjfQAqhCAZgbQA9hOBDg4QBEg4BSgqQCDhACzgFQCOgECeAqQCAAiCOA6QBwAuCTBJQB7A8BrAgQB+AkB2ABQDQADCphOQCrhPCOiOQB2h2B1i3QA3hVA4iFQA8iXAghKQBzkNDXiRQCMheCngMQA2gEBoADQBeACAqAFQCeAVCaAgQAiADA4AQQBAASAZAEQicAJgqgFQgrgFhogPQhQgLg1gFQh5gMhjAAQhTAAhPAVQhJAThKAlQhCAihAA8QgyAwg5BJQhBBTg5CEQggBLg8CZQhLCyiCCrQg4BJgbAhQgxA5gsAoQhiBYhbA3QhrBBhwAeQiiAsiQgBQj5gCj3h+QiohXiIg1QiohBiagfQl2hIkAD1QgXAVgeAjIgyA7Ih8DIQhJB1g2BRQhSB7iACYQhyCJiUBxQijB/jlAgQhpAOh8gdQgbgHi9g7QkfhbjVgsQiQgeiegCQiegCiABcQiABbhEBlQhEBlhbCQQgpBBhPCFQhHByhDBHQg0A2hKAqQg7AghWAgQg8AWiYAlQiEAfgBADQgDgBgkAEIgDAAQgUAAACghg");
	var mask_graphics_140 = new cjs.Graphics().p("EhBMAbPQAeAGApgMIBEgWQDNgvCMhLQBYguBJhQQA+hFA4hkQBMiHA9hgQBOh6BNhhQBRhlA3gyQBShMBaggQBugmB9gBQCDgBCnAbQB1ATC4A2QAhAKDOBGQCSAxBgASQA6ALBTgLQBUgLBIgcQBTghBRg4QBCguBPhGQB9hxCQjAQA+hUBUiIICKjfQAqhCAZgbQA9hOBDg4QBEg4BSgqQCDhACzgFQCOgECeAqQCAAiCOA6QBwAuCTBJQB7A8BrAgQB+AkB2ABQDQADCphOQCrhPCOiOQB2h2B1i3QA3hVA4iFQA8iXAghKQBzkNDXiRQCMheCngMQA2gEBoADQBeACAqAFQCeAVCaAgQAiADA4AQQBAASAZAEQicAJgqgFQgrgFhogPQhQgLg1gFQh5gMhjAAQhTAAhPAVQhJAThKAlQhCAihAA8QgyAwg5BJQhBBTg5CEQggBLg8CZQhLCyiCCrQg4BJgbAhQgxA5gsAoQhiBYhbA3QhrBBhwAeQiiAsiQgBQj5gCj3h+QiohXiIg1QiohBiagfQl2hIkAD1QgXAVgeAjIgyA7Ih8DIQhJB1g2BRQhSB7iACYQhyCJiUBxQijB/jlAgQhpAOh8gdQgbgHi9g7QkfhbjVgsQiQgeiygDQiGgBiCBkQhmBQhfB3QhFBWhbCQQgpBBhPCFQhHByhDBHQg0A2hKAqQg7AghWAgQg8AWiYAlQiEAfgBADQgDgBgkAEIgDAAQgUAAACghg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(23).to({graphics:mask_graphics_23,x:417.3132,y:178.2941}).wait(117).to({graphics:mask_graphics_140,x:417.3132,y:178.2941}).wait(65));

	// Слой_3_obj_
	this.Слой_3 = new lib.Clip_Group_Слой_3();
	this.Слой_3.name = "Слой_3";
	this.Слой_3.parent = this;
	this.Слой_3.depth = 0;
	this.Слой_3.isAttachedToCamera = 0
	this.Слой_3.isAttachedToMask = 0
	this.Слой_3.layerDepth = 0
	this.Слой_3.layerIndex = 0
	this.Слой_3.maskLayerName = 0

	var maskedShapeInstanceList = [this.Слой_3];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.Слой_3).wait(205));

	// Слой_34_obj_
	this.Слой_34 = new lib.Clip_Group_Слой_34();
	this.Слой_34.name = "Слой_34";
	this.Слой_34.parent = this;
	this.Слой_34.depth = 0;
	this.Слой_34.isAttachedToCamera = 0
	this.Слой_34.isAttachedToMask = 0
	this.Слой_34.layerDepth = 0
	this.Слой_34.layerIndex = 1
	this.Слой_34.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_34).wait(205));

	// Слой_33_obj_
	this.Слой_33 = new lib.Clip_Group_Слой_33();
	this.Слой_33.name = "Слой_33";
	this.Слой_33.parent = this;
	this.Слой_33.depth = 0;
	this.Слой_33.isAttachedToCamera = 0
	this.Слой_33.isAttachedToMask = 0
	this.Слой_33.layerDepth = 0
	this.Слой_33.layerIndex = 2
	this.Слой_33.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_33).wait(205));

	// Слой_32_obj_
	this.Слой_32 = new lib.Clip_Group_Слой_32();
	this.Слой_32.name = "Слой_32";
	this.Слой_32.parent = this;
	this.Слой_32.depth = 0;
	this.Слой_32.isAttachedToCamera = 0
	this.Слой_32.isAttachedToMask = 0
	this.Слой_32.layerDepth = 0
	this.Слой_32.layerIndex = 3
	this.Слой_32.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_32).wait(205));

	// Слой_31_obj_
	this.Слой_31 = new lib.Clip_Group_Слой_31();
	this.Слой_31.name = "Слой_31";
	this.Слой_31.parent = this;
	this.Слой_31.depth = 0;
	this.Слой_31.isAttachedToCamera = 0
	this.Слой_31.isAttachedToMask = 0
	this.Слой_31.layerDepth = 0
	this.Слой_31.layerIndex = 4
	this.Слой_31.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_31).wait(205));

	// Слой_29_obj_
	this.Слой_29 = new lib.Clip_Group_Слой_29();
	this.Слой_29.name = "Слой_29";
	this.Слой_29.parent = this;
	this.Слой_29.depth = 0;
	this.Слой_29.isAttachedToCamera = 0
	this.Слой_29.isAttachedToMask = 0
	this.Слой_29.layerDepth = 0
	this.Слой_29.layerIndex = 5
	this.Слой_29.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_29).wait(205));

	// Слой_28_obj_
	this.Слой_28 = new lib.Clip_Group_Слой_28();
	this.Слой_28.name = "Слой_28";
	this.Слой_28.parent = this;
	this.Слой_28.depth = 0;
	this.Слой_28.isAttachedToCamera = 0
	this.Слой_28.isAttachedToMask = 0
	this.Слой_28.layerDepth = 0
	this.Слой_28.layerIndex = 6
	this.Слой_28.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_28).wait(205));

	// Слой_27_obj_
	this.Слой_27 = new lib.Clip_Group_Слой_27();
	this.Слой_27.name = "Слой_27";
	this.Слой_27.parent = this;
	this.Слой_27.depth = 0;
	this.Слой_27.isAttachedToCamera = 0
	this.Слой_27.isAttachedToMask = 0
	this.Слой_27.layerDepth = 0
	this.Слой_27.layerIndex = 7
	this.Слой_27.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_27).wait(205));

	// Слой_26_obj_
	this.Слой_26 = new lib.Clip_Group_Слой_26();
	this.Слой_26.name = "Слой_26";
	this.Слой_26.parent = this;
	this.Слой_26.depth = 0;
	this.Слой_26.isAttachedToCamera = 0
	this.Слой_26.isAttachedToMask = 0
	this.Слой_26.layerDepth = 0
	this.Слой_26.layerIndex = 8
	this.Слой_26.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_26).wait(205));

	// Слой_25_obj_
	this.Слой_25 = new lib.Clip_Group_Слой_25();
	this.Слой_25.name = "Слой_25";
	this.Слой_25.parent = this;
	this.Слой_25.depth = 0;
	this.Слой_25.isAttachedToCamera = 0
	this.Слой_25.isAttachedToMask = 0
	this.Слой_25.layerDepth = 0
	this.Слой_25.layerIndex = 9
	this.Слой_25.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_25).wait(205));

	// Слой_24_obj_
	this.Слой_24 = new lib.Clip_Group_Слой_24();
	this.Слой_24.name = "Слой_24";
	this.Слой_24.parent = this;
	this.Слой_24.depth = 0;
	this.Слой_24.isAttachedToCamera = 0
	this.Слой_24.isAttachedToMask = 0
	this.Слой_24.layerDepth = 0
	this.Слой_24.layerIndex = 10
	this.Слой_24.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_24).wait(205));

	// Слой_23_obj_
	this.Слой_23 = new lib.Clip_Group_Слой_23();
	this.Слой_23.name = "Слой_23";
	this.Слой_23.parent = this;
	this.Слой_23.depth = 0;
	this.Слой_23.isAttachedToCamera = 0
	this.Слой_23.isAttachedToMask = 0
	this.Слой_23.layerDepth = 0
	this.Слой_23.layerIndex = 11
	this.Слой_23.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_23).wait(205));

	// Слой_22_obj_
	this.Слой_22 = new lib.Clip_Group_Слой_22();
	this.Слой_22.name = "Слой_22";
	this.Слой_22.parent = this;
	this.Слой_22.depth = 0;
	this.Слой_22.isAttachedToCamera = 0
	this.Слой_22.isAttachedToMask = 0
	this.Слой_22.layerDepth = 0
	this.Слой_22.layerIndex = 12
	this.Слой_22.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_22).wait(205));

	// Слой_21_obj_
	this.Слой_21 = new lib.Clip_Group_Слой_21();
	this.Слой_21.name = "Слой_21";
	this.Слой_21.parent = this;
	this.Слой_21.depth = 0;
	this.Слой_21.isAttachedToCamera = 0
	this.Слой_21.isAttachedToMask = 0
	this.Слой_21.layerDepth = 0
	this.Слой_21.layerIndex = 13
	this.Слой_21.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_21).wait(205));

	// Слой_20_obj_
	this.Слой_20 = new lib.Clip_Group_Слой_20();
	this.Слой_20.name = "Слой_20";
	this.Слой_20.parent = this;
	this.Слой_20.depth = 0;
	this.Слой_20.isAttachedToCamera = 0
	this.Слой_20.isAttachedToMask = 0
	this.Слой_20.layerDepth = 0
	this.Слой_20.layerIndex = 14
	this.Слой_20.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_20).wait(205));

	// Слой_19_obj_
	this.Слой_19 = new lib.Clip_Group_Слой_19();
	this.Слой_19.name = "Слой_19";
	this.Слой_19.parent = this;
	this.Слой_19.depth = 0;
	this.Слой_19.isAttachedToCamera = 0
	this.Слой_19.isAttachedToMask = 0
	this.Слой_19.layerDepth = 0
	this.Слой_19.layerIndex = 15
	this.Слой_19.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_19).wait(205));

	// Слой_18_obj_
	this.Слой_18 = new lib.Clip_Group_Слой_18();
	this.Слой_18.name = "Слой_18";
	this.Слой_18.parent = this;
	this.Слой_18.depth = 0;
	this.Слой_18.isAttachedToCamera = 0
	this.Слой_18.isAttachedToMask = 0
	this.Слой_18.layerDepth = 0
	this.Слой_18.layerIndex = 16
	this.Слой_18.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_18).wait(205));

	// Слой_17_obj_
	this.Слой_17 = new lib.Clip_Group_Слой_17();
	this.Слой_17.name = "Слой_17";
	this.Слой_17.parent = this;
	this.Слой_17.depth = 0;
	this.Слой_17.isAttachedToCamera = 0
	this.Слой_17.isAttachedToMask = 0
	this.Слой_17.layerDepth = 0
	this.Слой_17.layerIndex = 17
	this.Слой_17.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_17).wait(205));

	// Слой_16_obj_
	this.Слой_16 = new lib.Clip_Group_Слой_16();
	this.Слой_16.name = "Слой_16";
	this.Слой_16.parent = this;
	this.Слой_16.depth = 0;
	this.Слой_16.isAttachedToCamera = 0
	this.Слой_16.isAttachedToMask = 0
	this.Слой_16.layerDepth = 0
	this.Слой_16.layerIndex = 18
	this.Слой_16.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_16).wait(205));

	// Слой_15_obj_
	this.Слой_15 = new lib.Clip_Group_Слой_15();
	this.Слой_15.name = "Слой_15";
	this.Слой_15.parent = this;
	this.Слой_15.depth = 0;
	this.Слой_15.isAttachedToCamera = 0
	this.Слой_15.isAttachedToMask = 0
	this.Слой_15.layerDepth = 0
	this.Слой_15.layerIndex = 19
	this.Слой_15.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_15).wait(205));

	// Слой_14_obj_
	this.Слой_14 = new lib.Clip_Group_Слой_14();
	this.Слой_14.name = "Слой_14";
	this.Слой_14.parent = this;
	this.Слой_14.depth = 0;
	this.Слой_14.isAttachedToCamera = 0
	this.Слой_14.isAttachedToMask = 0
	this.Слой_14.layerDepth = 0
	this.Слой_14.layerIndex = 20
	this.Слой_14.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_14).wait(205));

	// Слой_13_obj_
	this.Слой_13 = new lib.Clip_Group_Слой_13();
	this.Слой_13.name = "Слой_13";
	this.Слой_13.parent = this;
	this.Слой_13.depth = 0;
	this.Слой_13.isAttachedToCamera = 0
	this.Слой_13.isAttachedToMask = 0
	this.Слой_13.layerDepth = 0
	this.Слой_13.layerIndex = 21
	this.Слой_13.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_13).wait(205));

	// Слой_12_obj_
	this.Слой_12 = new lib.Clip_Group_Слой_12();
	this.Слой_12.name = "Слой_12";
	this.Слой_12.parent = this;
	this.Слой_12.depth = 0;
	this.Слой_12.isAttachedToCamera = 0
	this.Слой_12.isAttachedToMask = 0
	this.Слой_12.layerDepth = 0
	this.Слой_12.layerIndex = 22
	this.Слой_12.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_12).wait(205));

	// Слой_11_obj_
	this.Слой_11 = new lib.Clip_Group_Слой_11();
	this.Слой_11.name = "Слой_11";
	this.Слой_11.parent = this;
	this.Слой_11.depth = 0;
	this.Слой_11.isAttachedToCamera = 0
	this.Слой_11.isAttachedToMask = 0
	this.Слой_11.layerDepth = 0
	this.Слой_11.layerIndex = 23
	this.Слой_11.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_11).wait(205));

	// Слой_10_obj_
	this.Слой_10 = new lib.Clip_Group_Слой_10();
	this.Слой_10.name = "Слой_10";
	this.Слой_10.parent = this;
	this.Слой_10.depth = 0;
	this.Слой_10.isAttachedToCamera = 0
	this.Слой_10.isAttachedToMask = 0
	this.Слой_10.layerDepth = 0
	this.Слой_10.layerIndex = 24
	this.Слой_10.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_10).wait(205));

	// Слой_35_obj_
	this.Слой_35 = new lib.Clip_Group_Слой_35();
	this.Слой_35.name = "Слой_35";
	this.Слой_35.parent = this;
	this.Слой_35.depth = 0;
	this.Слой_35.isAttachedToCamera = 0
	this.Слой_35.isAttachedToMask = 0
	this.Слой_35.layerDepth = 0
	this.Слой_35.layerIndex = 25
	this.Слой_35.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_35).wait(205));

	// Слой_9_obj_
	this.Слой_9 = new lib.Clip_Group_Слой_9();
	this.Слой_9.name = "Слой_9";
	this.Слой_9.parent = this;
	this.Слой_9.depth = 0;
	this.Слой_9.isAttachedToCamera = 0
	this.Слой_9.isAttachedToMask = 0
	this.Слой_9.layerDepth = 0
	this.Слой_9.layerIndex = 26
	this.Слой_9.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_9).wait(205));

	// Слой_8_obj_
	this.Слой_8 = new lib.Clip_Group_Слой_8();
	this.Слой_8.name = "Слой_8";
	this.Слой_8.parent = this;
	this.Слой_8.depth = 0;
	this.Слой_8.isAttachedToCamera = 0
	this.Слой_8.isAttachedToMask = 0
	this.Слой_8.layerDepth = 0
	this.Слой_8.layerIndex = 27
	this.Слой_8.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_8).wait(205));

	// Слой_7_obj_
	this.Слой_7 = new lib.Clip_Group_Слой_7();
	this.Слой_7.name = "Слой_7";
	this.Слой_7.parent = this;
	this.Слой_7.depth = 0;
	this.Слой_7.isAttachedToCamera = 0
	this.Слой_7.isAttachedToMask = 0
	this.Слой_7.layerDepth = 0
	this.Слой_7.layerIndex = 28
	this.Слой_7.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_7).wait(205));

	// Слой_6_obj_
	this.Слой_6 = new lib.Clip_Group_Слой_6();
	this.Слой_6.name = "Слой_6";
	this.Слой_6.parent = this;
	this.Слой_6.depth = 0;
	this.Слой_6.isAttachedToCamera = 0
	this.Слой_6.isAttachedToMask = 0
	this.Слой_6.layerDepth = 0
	this.Слой_6.layerIndex = 29
	this.Слой_6.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_6).wait(205));

	// Слой_5_obj_
	this.Слой_5 = new lib.Clip_Group_Слой_5();
	this.Слой_5.name = "Слой_5";
	this.Слой_5.parent = this;
	this.Слой_5.depth = 0;
	this.Слой_5.isAttachedToCamera = 0
	this.Слой_5.isAttachedToMask = 0
	this.Слой_5.layerDepth = 0
	this.Слой_5.layerIndex = 30
	this.Слой_5.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_5).wait(205));

	// Слой_1_obj_
	this.Слой_1 = new lib.Clip_Group_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(43.4,341.6,1,1,0,0,0,43.4,341.6);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 31
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(205));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(40.4,273.2,6,136.7);
p.frameBounds = [rect, rect, rect, rect, rect, rect=new cjs.Rectangle(40.4,255.8,30.4,154.1), rect, rect, rect, rect, rect=new cjs.Rectangle(40.4,218,55.6,191.9), rect, rect, rect, rect, rect=new cjs.Rectangle(40.4,182.8,84.2,227.1), rect, rect, rect, rect, rect=new cjs.Rectangle(40.4,169.6,119.2,240.3), rect, rect, rect=new cjs.Rectangle(0,169.6,159.6,240.3), rect, rect=new cjs.Rectangle(0,169.6,194.4,240.3), rect, rect, rect, new cjs.Rectangle(3.3,169.6,191.2,240.3), new cjs.Rectangle(8.5,169.6,220.4,240.3), new cjs.Rectangle(13.7,169.6,215.2,240.3), new cjs.Rectangle(18.9,169.6,209.9,240.3), new cjs.Rectangle(24.1,169.6,204.7,240.3), new cjs.Rectangle(29.3,169.6,199.5,240.3), new cjs.Rectangle(34.5,169.6,225.7,240.3), new cjs.Rectangle(39.7,169.6,220.5,240.3), rect=new cjs.Rectangle(40.4,169.6,219.8,240.3), rect, rect=new cjs.Rectangle(40.4,169.6,249.7,240.3), rect, rect, rect, rect=new cjs.Rectangle(40.4,169.6,282.9,240.3), rect, rect, rect, rect=new cjs.Rectangle(40.4,150.4,309.6,259.5), rect, rect, rect, rect=new cjs.Rectangle(40.4,117.7,332.9,292.3), rect, rect, rect, rect=new cjs.Rectangle(40.4,81.8,358.4,328.1), rect, rect, rect, rect=new cjs.Rectangle(40.4,61.3,387.2,348.6), rect, rect, rect, rect=new cjs.Rectangle(40.4,57,417.4,352.9), rect, rect, rect, rect, rect=new cjs.Rectangle(40.4,57,445.3,352.9), rect, rect, rect, rect=new cjs.Rectangle(40.4,57,468.3,352.9), rect, rect, rect, rect=new cjs.Rectangle(40.4,57,491.4,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,516.6,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,537.1,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,559.4,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,580.4,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,601.3,352.9), rect, rect, rect=new cjs.Rectangle(40.4,57,619.6,352.9), rect, rect, rect=new cjs.Rectangle(40.4,35.7,634.3,374.3), rect, rect, rect=new cjs.Rectangle(40.4,8.9,647.6,401), rect, rect, rect, rect=new cjs.Rectangle(40.4,-28.1,663.2,438), rect, rect, rect=new cjs.Rectangle(40.4,-45.3,680.1,455.2), rect, rect, rect=new cjs.Rectangle(40.4,-58.6,700,468.5), rect, rect, rect, rect=new cjs.Rectangle(40.4,-63.4,720.4,473.3), rect, rect, rect, rect=new cjs.Rectangle(40.4,-63.4,743.3,473.3), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, new cjs.Rectangle(40.4,-63.4,746.7,473.3), new cjs.Rectangle(40.4,-63.4,753,473.3), new cjs.Rectangle(40.4,-63.4,759.4,473.3), new cjs.Rectangle(40.4,-63.4,765.7,473.3), new cjs.Rectangle(40.4,-63.4,772.1,473.3), new cjs.Rectangle(40.4,-63.4,778.5,473.3), new cjs.Rectangle(40.4,-63.4,784.9,473.3), new cjs.Rectangle(40.4,-63.4,791.2,473.3), rect=new cjs.Rectangle(40.4,-63.4,794.3,473.3), rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect];


(lib.Scene_1_Layer_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.ClipGroup();
	this.instance.parent = this;
	this.instance.setTransform(570.55,523.25,1,1,0,0,0,417.3,177.9);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(119));

}).prototype = p = new cjs.MovieClip();


// stage content:
(lib._1_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	this.___GetDepth___ = function(obj) {
		var depth = obj.depth;
		var cameraObj = this.___camera___instance;
		if(cameraObj && cameraObj.depth && obj.isAttachedToCamera)
		{
			depth += depth + cameraObj.depth;
		}
		return depth;
		}
	this.___needSorting___ = function() {
		for (var i = 0; i < this.getNumChildren() - 1; i++)
		{
			var prevDepth = this.___GetDepth___(this.getChildAt(i));
			var nextDepth = this.___GetDepth___(this.getChildAt(i + 1));
			if (prevDepth < nextDepth)
				return true;
		}
		return false;
	}
	this.___sortFunction___ = function(obj1, obj2) {
		return (this.exportRoot.___GetDepth___(obj2) - this.exportRoot.___GetDepth___(obj1));
	}
	this.on('tick', function (event){
		var curTimeline = event.currentTarget;
		if (curTimeline.___needSorting___()){
			this.sortChildren(curTimeline.___sortFunction___);
		}
	});

	// timeline functions:
	this.frame_118 = function() {
		this.___loopingOver___ = true;
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(118).call(this.frame_118).wait(1));

	// Layer_1_obj_
	this.Layer_1 = new lib.Scene_1_Layer_1();
	this.Layer_1.name = "Layer_1";
	this.Layer_1.parent = this;
	this.Layer_1.setTransform(361.9,550.3,1,1,0,0,0,361.9,550.3);
	this.Layer_1.depth = 0;
	this.Layer_1.isAttachedToCamera = 0
	this.Layer_1.isAttachedToMask = 0
	this.Layer_1.layerDepth = 0
	this.Layer_1.layerIndex = 0
	this.Layer_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Layer_1).wait(119));

	// Слой_8_obj_
	this.Слой_8 = new lib.Scene_1_Слой_8();
	this.Слой_8.name = "Слой_8";
	this.Слой_8.parent = this;
	this.Слой_8.setTransform(810.7,436.9,1,1,0,0,0,810.7,436.9);
	this.Слой_8.depth = 0;
	this.Слой_8.isAttachedToCamera = 0
	this.Слой_8.isAttachedToMask = 0
	this.Слой_8.layerDepth = 0
	this.Слой_8.layerIndex = 1
	this.Слой_8.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_8).wait(119));

	// Слой_7_obj_
	this.Слой_7 = new lib.Scene_1_Слой_7();
	this.Слой_7.name = "Слой_7";
	this.Слой_7.parent = this;
	this.Слой_7.setTransform(245.5,632.5,1,1,0,0,0,245.5,632.5);
	this.Слой_7.depth = 0;
	this.Слой_7.isAttachedToCamera = 0
	this.Слой_7.isAttachedToMask = 0
	this.Слой_7.layerDepth = 0
	this.Слой_7.layerIndex = 2
	this.Слой_7.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_7).wait(119));

	// Слой_3_obj_
	this.Слой_3 = new lib.Scene_1_Слой_3();
	this.Слой_3.name = "Слой_3";
	this.Слой_3.parent = this;
	this.Слой_3.setTransform(777.1,336.2,1,1,0,0,0,777.1,336.2);
	this.Слой_3.depth = 0;
	this.Слой_3.isAttachedToCamera = 0
	this.Слой_3.isAttachedToMask = 0
	this.Слой_3.layerDepth = 0
	this.Слой_3.layerIndex = 3
	this.Слой_3.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_3).wait(119));

	// Слой_4_obj_
	this.Слой_4 = new lib.Scene_1_Слой_4();
	this.Слой_4.name = "Слой_4";
	this.Слой_4.parent = this;
	this.Слой_4.setTransform(517.7,501.4,1,1,0,0,0,517.7,501.4);
	this.Слой_4.depth = 0;
	this.Слой_4.isAttachedToCamera = 0
	this.Слой_4.isAttachedToMask = 0
	this.Слой_4.layerDepth = 0
	this.Слой_4.layerIndex = 4
	this.Слой_4.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_4).wait(119));

	// Слой_2_obj_
	this.Слой_2 = new lib.Scene_1_Слой_2();
	this.Слой_2.name = "Слой_2";
	this.Слой_2.parent = this;
	this.Слой_2.setTransform(512.6,239,1,1,0,0,0,512.6,239);
	this.Слой_2.depth = 0;
	this.Слой_2.isAttachedToCamera = 0
	this.Слой_2.isAttachedToMask = 0
	this.Слой_2.layerDepth = 0
	this.Слой_2.layerIndex = 5
	this.Слой_2.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_2).wait(119));

	// Слой_1_obj_
	this.Слой_1 = new lib.Scene_1_Слой_1();
	this.Слой_1.name = "Слой_1";
	this.Слой_1.parent = this;
	this.Слой_1.setTransform(950,429,1,1,0,0,0,950,429);
	this.Слой_1.depth = 0;
	this.Слой_1.isAttachedToCamera = 0
	this.Слой_1.isAttachedToMask = 0
	this.Слой_1.layerDepth = 0
	this.Слой_1.layerIndex = 6
	this.Слой_1.maskLayerName = 0

	this.timeline.addTween(cjs.Tween.get(this.Слой_1).wait(119));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = rect = new cjs.Rectangle(950,429,1900,858);
p.frameBounds = [rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect, rect];
// library properties:
lib.properties = {
	id: 'B31DA7AAD36D414BACCED920EDD6A901',
	width: 1900,
	height: 858,
	fps: 28,
	color: "#000099",
	opacity: 0.00,
	manifest: [
		{src:"assets/images/_1.jpg", id:"_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B31DA7AAD36D414BACCED920EDD6A901'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


// Layer depth API : 

AdobeAn.Layer = new function() {
	this.getLayerZDepth = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth; else 0;";
		return eval(script);
	}
	this.setLayerZDepth = function(timeline, layerName, zDepth)
	{
		const MAX_zDepth = 10000;
		const MIN_zDepth = -5000;
		if(zDepth > MAX_zDepth)
			zDepth = MAX_zDepth;
		else if(zDepth < MIN_zDepth)
			zDepth = MIN_zDepth;
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline." + layerName + ".depth = " + zDepth + ";";
		eval(script);
	}
	this.removeLayer = function(timeline, layerName)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		var script = "if(timeline." + layerName + ") timeline.removeChild(timeline." + layerName + ");";
		eval(script);
	}
	this.addNewLayer = function(timeline, layerName, zDepth)
	{
		if(layerName === "Camera")
		layerName = "___camera___instance";
		zDepth = typeof zDepth !== 'undefined' ? zDepth : 0;
		var layer = new createjs.MovieClip();
		layer.name = layerName;
		layer.depth = zDepth;
		layer.layerIndex = 0;
		timeline.addChild(layer);
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;

var canvas, stage, exportRoot, anim_container, dom_overlay_container, fnStartAnimation;
function init() {
	canvas = document.getElementById("canvas");
	anim_container = document.getElementById("animation_container");
	dom_overlay_container = document.getElementById("dom_overlay_container");
	var comp=AdobeAn.getComposition("B31DA7AAD36D414BACCED920EDD6A901");
	var lib=comp.getLibrary();
	var loader = new createjs.LoadQueue(false);
	loader.addEventListener("fileload", function(evt){handleFileLoad(evt,comp)});
	loader.addEventListener("complete", function(evt){handleComplete(evt,comp)});
	var lib=comp.getLibrary();
	loader.loadManifest(lib.properties.manifest);
}
function handleFileLoad(evt, comp) {
	var images=comp.getImages();	
	if (evt && (evt.item.type == "image")) { images[evt.item.id] = evt.result; }	
}
function handleComplete(evt,comp) {
	//This function is always called, irrespective of the content. You can use the variable "stage" after it is created in token create_stage.
	var lib=comp.getLibrary();
	var ss=comp.getSpriteSheet();
	var queue = evt.target;
	var ssMetadata = lib.ssMetadata;
	for(i=0; i<ssMetadata.length; i++) {
		ss[ssMetadata[i].name] = new createjs.SpriteSheet( {"images": [queue.getResult(ssMetadata[i].name)], "frames": ssMetadata[i].frames} )
	}
	exportRoot = new lib._1_1();
	stage = new lib.Stage(canvas);	
	//Registers the "tick" event listener.
	fnStartAnimation = function() {
		stage.addChild(exportRoot);
		createjs.Ticker.setFPS(lib.properties.fps);
		createjs.Ticker.addEventListener("tick", stage)
		stage.addEventListener("tick", handleTick)
		function getProjectionMatrix(container, totalDepth) {
			var focalLength = 528.25;
			var projectionCenter = { x : lib.properties.width/2, y : lib.properties.height/2 };
			var scale = (totalDepth + focalLength)/focalLength;
			var scaleMat = new createjs.Matrix2D;
			scaleMat.a = 1/scale;
			scaleMat.d = 1/scale;
			var projMat = new createjs.Matrix2D;
			projMat.tx = -projectionCenter.x;
			projMat.ty = -projectionCenter.y;
			projMat = projMat.prependMatrix(scaleMat);
			projMat.tx += projectionCenter.x;
			projMat.ty += projectionCenter.y;
			return projMat;
		}
		function handleTick(event) {
			var cameraInstance = exportRoot.___camera___instance;
			if(cameraInstance !== undefined && cameraInstance.pinToObject !== undefined)
			{
				cameraInstance.x = cameraInstance.pinToObject.x + cameraInstance.pinToObject.pinOffsetX;
				cameraInstance.y = cameraInstance.pinToObject.y + cameraInstance.pinToObject.pinOffsetY;
				if(cameraInstance.pinToObject.parent !== undefined && cameraInstance.pinToObject.parent.depth !== undefined)
				cameraInstance.depth = cameraInstance.pinToObject.parent.depth + cameraInstance.pinToObject.pinOffsetZ;
			}
			applyLayerZDepth(exportRoot);
		}
		function applyLayerZDepth(parent)
		{
			var cameraInstance = parent.___camera___instance;
			var focalLength = 528.25;
			var projectionCenter = { 'x' : 0, 'y' : 0};
			if(parent === exportRoot)
			{
				var stageCenter = { 'x' : lib.properties.width/2, 'y' : lib.properties.height/2 };
				projectionCenter.x = stageCenter.x;
				projectionCenter.y = stageCenter.y;
			}
			for(child in parent.children)
			{
				var layerObj = parent.children[child];
				if(layerObj == cameraInstance)
					continue;
				applyLayerZDepth(layerObj, cameraInstance);
				if(layerObj.layerDepth === undefined)
					continue;
				if(layerObj.currentFrame != layerObj.parent.currentFrame)
				{
					layerObj.gotoAndPlay(layerObj.parent.currentFrame);
				}
				var matToApply = new createjs.Matrix2D;
				var cameraMat = new createjs.Matrix2D;
				var totalDepth = layerObj.layerDepth ? layerObj.layerDepth : 0;
				var cameraDepth = 0;
				if(cameraInstance && !layerObj.isAttachedToCamera)
				{
					var mat = cameraInstance.getMatrix();
					mat.tx -= projectionCenter.x;
					mat.ty -= projectionCenter.y;
					cameraMat = mat.invert();
					cameraMat.prependTransform(projectionCenter.x, projectionCenter.y, 1, 1, 0, 0, 0, 0, 0);
					cameraMat.appendTransform(-projectionCenter.x, -projectionCenter.y, 1, 1, 0, 0, 0, 0, 0);
					if(cameraInstance.depth)
						cameraDepth = cameraInstance.depth;
				}
				if(layerObj.depth)
				{
					totalDepth = layerObj.depth;
				}
				//Offset by camera depth
				totalDepth -= cameraDepth;
				if(totalDepth < -focalLength)
				{
					matToApply.a = 0;
					matToApply.d = 0;
				}
				else
				{
					if(layerObj.layerDepth)
					{
						var sizeLockedMat = getProjectionMatrix(parent, layerObj.layerDepth);
						if(sizeLockedMat)
						{
							sizeLockedMat.invert();
							matToApply.prependMatrix(sizeLockedMat);
						}
					}
					matToApply.prependMatrix(cameraMat);
					var projMat = getProjectionMatrix(parent, totalDepth);
					if(projMat)
					{
						matToApply.prependMatrix(projMat);
					}
				}
				layerObj.transformMatrix = matToApply;
			}
		}
	}	    
	//Code to support hidpi screens and responsive scaling.
	function makeResponsive(isResp, respDim, isScale, scaleType) {		
		var lastW, lastH, lastS=1;		
		window.addEventListener('resize', resizeCanvas);		
		resizeCanvas();		
		function resizeCanvas() {			
			var w = lib.properties.width, h = lib.properties.height;			
			var iw = window.innerWidth, ih=window.innerHeight;			
			var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
			if(isResp) {                
				if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
					sRatio = lastS;                
				}				
				else if(!isScale) {					
					if(iw<w || ih<h)						
						sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==1) {					
					sRatio = Math.min(xRatio, yRatio);				
				}				
				else if(scaleType==2) {					
					sRatio = Math.max(xRatio, yRatio);				
				}			
			}			
			canvas.width = w*pRatio*sRatio;			
			canvas.height = h*pRatio*sRatio;
			canvas.style.width = dom_overlay_container.style.width = anim_container.style.width =  w*sRatio+'px';				
			canvas.style.height = anim_container.style.height = dom_overlay_container.style.height = h*sRatio+'px';
			stage.scaleX = pRatio*sRatio;			
			stage.scaleY = pRatio*sRatio;			
			lastW = iw; lastH = ih; lastS = sRatio;            
			stage.tickOnUpdate = false;            
			stage.update();            
			stage.tickOnUpdate = true;		
		}
	}
	makeResponsive(false,'both',false,1);	
	AdobeAn.compositionLoaded(lib.properties.id);
	fnStartAnimation();
}


window.onload = function(){
	init();
}